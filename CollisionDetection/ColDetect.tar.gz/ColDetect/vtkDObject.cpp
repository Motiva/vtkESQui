/*
 ******************************************************************************
 * Title: CDObject
 * Project: ColDetection Library
 ******************************************************************************
 * File: CDObject.cpp
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-02-03
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * ColDetection Object
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#include "vtkDObject.h"
vtkCxxRevisionMacro(vtkDObject, "$Revision: 0.1 $");
vtkDObject::vtkDObject(void)
{
  mesh = new vtkMesh();

	// Para la liberacion de la memoria
	trans = 0;
}

vtkDObject::~vtkDObject(void)
{
	mesh->Delete();
}

void vtkDObject::beginObject(unsigned nbFacets, 
			   unsigned nbVertexes)
{
  this->mesh -> nbVertexes = nbVertexes;
  this->mesh -> _vertexes = new vtkVector3f[mesh -> nbVertexes];

  this->mesh -> nbFacets = nbFacets;
  this->mesh -> _facets = new vtkVector3ui[mesh -> nbFacets];
}

void vtkDObject::SetVertexes(double** Vertexes)
{
  for (unsigned i = 0 ; i < mesh -> nbVertexes ; i++) {
    (mesh -> _vertexes)[i] = 
      vtkVector3f(Vertexes[i][0], Vertexes[i][1], Vertexes[i][2]);
  }
}

void vtkDObject::SetVertexes(double* Vertexes)
{
  for (unsigned i = 0 ; i < mesh -> nbVertexes ; i++)
    mesh -> _vertexes[i] = vtkVector3f(Vertexes[i*3+0],
					 Vertexes[i*3+1], 
					 Vertexes[i*3+2]);
}

void vtkDObject::GetVertexes(unsigned face, unsigned* Vertexes)
{
	Vertexes[0]=(mesh -> _facets)[face].a;
	Vertexes[1]=(mesh -> _facets)[face].b;
	Vertexes[2]=(mesh -> _facets)[face].c;
}

void vtkDObject::CoordsVertexes(unsigned vertex, float* coord)
{
	vtkVector3f vertice;

	// Obtiene el vertice que nos interesa
	// Obtains the vertex in that we are interested
	vtkVector3f::copy(vertice, (mesh -> _vertexes)[vertex]);

	// Aplica la matriz de transformacion para obtener
	// las coordenadas absolutas del vertice

	// Applies the transformation matrix to obtain the absolute coordinates of the vertex
	transform(vertice, *trans);

	// Asigna los valores al parametro de salida
	// Assigns the values to the exit parameter 
	coord[0]=static_cast<float>(vertice.x);
	coord[1]=static_cast<float>(vertice.y);
	coord[2]=static_cast<float>(vertice.z);
	/*coord[0]=(mesh -> _vertexes)[vertex].x;
	coord[1]=(mesh -> _vertexes)[vertex].y;
	coord[2]=(mesh -> _vertexes)[vertex].z;*/
}

//Función que devuelve las coordenadas relativas de los vértices
//
void vtkDObject::RelativeCoordsVertexes(unsigned vertex, float* coord){
	coord[0]=(mesh -> _vertexes)[vertex].x;
	coord[1]=(mesh -> _vertexes)[vertex].y;
	coord[2]=(mesh -> _vertexes)[vertex].z;
}//End coordVerticesAbsolutos


void vtkDObject::addTriangle(unsigned idFace,
			   const unsigned v1,
			   const unsigned v2,
			   const unsigned v3)	   
{
  (this->mesh -> _facets)[idFace].a = v1;
  (this->mesh -> _facets)[idFace].b = v2;
  (this->mesh -> _facets)[idFace].c = v3;
}

void vtkDObject::computeIntermediateStructure(void)
{
  this->mesh -> computeFacetRing();
  this->mesh -> computeFacetsOfVertices();
  this->mesh -> computeVertexNeighbors();
}

double** vtkDObject::getTransformationMatrix(){
	return this->trans;
}

void vtkDObject::SetTransformationMatrix(double* trans[16])
{
	if(this->trans)
	{
		char i;
		for(i=0; i<16; i++)
		{
			(*(this->trans))[i]=(*trans)[i];
		}
		delete[] (*trans);
		delete[] trans;
	}
	else
	{
		this->trans=trans;
	}

}

void vtkDObject::UpdateVertex(unsigned idVertex,
			    double x,
			    double y,
			    double z)
{
  // Set the new coordinate of the vertex idVertex
  vtkVector3f::setXYZ((mesh -> _vertexes)[idVertex], x, y, z);


  unsigned i;
  for (i = 0 ; i < (mesh -> _facetsOfVertices)[idVertex].size() ; i++) {
    // Change these facets need to be updated
    (* (mesh -> accessFacetBBT))[(mesh -> _facetsOfVertices)[idVertex][i]] ->
      changed = true;
    mesh -> initDeformSon -> 
      push_back((* (mesh -> 
		    accessFacetBBT))[(mesh -> _facetsOfVertices)[idVertex][i]]);
  }
  
}

/* CDObject.cpp ends here */
