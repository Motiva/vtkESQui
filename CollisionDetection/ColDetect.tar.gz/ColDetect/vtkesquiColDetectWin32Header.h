#ifndef __vtkesquiColDetectWin32Header_h
#define __vtkesquiColDetectWin32Header_h

#include "vtkESQUIConfigure.h"

#if defined(WIN32)&& !defined(VTKESQUI_STATIC)
  #if defined(vtkesquiColDetect_EXPORTS)
    #define VTK_ESQUI_COLDETECT_EXPORT __declspec(dllexport)
  #else
    #define VTK_ESQUI_COLDETECT_EXPORT __declspec( dllimport ) 
  #endif
#else
#define VTK_ESQUI_COLDETECT_EXPORT
#endif

#endif

