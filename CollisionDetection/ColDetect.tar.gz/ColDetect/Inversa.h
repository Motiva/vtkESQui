double Det2x2 (double a, double b, double c, double d) {
	return a*d - b*c;
}//fin Det2x2()


double Det3x3 (double a1, double a2, double a3,
			  double b1, double b2, double b3,
              double c1, double c2, double c3) {
	return 	a1 * Det2x2(b2, b3, c2, c3)
		-	b1 * Det2x2(a2, a3, c2, c3)
		+	c1 * Det2x2(a2, a3, b2, b3);		
}//fin Det3x3()

//double Determinante (double m[4][4]) {
double Determinante (double* m){
/*	double a1 = m[0][0];	double a2 = m[1][0];	double a3 = m[2][0];	double a4 = m[3][0];
	double b1 = m[0][1];	double b2 = m[1][1];	double b3 = m[2][1];	double b4 = m[3][1];
	double c1 = m[0][2];	double c2 = m[1][2];	double c3 = m[2][2];	double c4 = m[3][2];
	double d1 = m[0][3];	double d2 = m[1][3];	double d3 = m[2][3];	double d4 = m[3][3];*/
	double a1 = m[0];	double a2 = m[1];	double a3 = m[2];	double a4 = m[3];
	double b1 = m[4];	double b2 = m[5];	double b3 = m[6];	double b4 = m[7];
	double c1 = m[8];	double c2 = m[9];	double c3 = m[10];	double c4 = m[11];
	double d1 = m[12];	double d2 = m[13];	double d3 = m[14];	double d4 = m[15];

	return 	a1 * Det3x3(b2, b3, b4, c2, c3, c4, d2, d3, d4)
		- 	b1 * Det3x3(a2, a3, a4, c2, c3, c4, d2, d3, d4)
		+	c1 * Det3x3(a2, a3, a4, b2, b3, b4, d2, d3, d4)
		-	d1 * Det3x3(a2, a3, a4, b2, b3, b4, c2, c3, c4);
}//fin Determinante()

void Adjunta (double* retVal,double* m) {

	// Adjunta(x,y) = -1^(x+y) * a(y,x)
	// Donde a(i,j) es el determinante de la matriz 3x3 de m cuando
	// se eliminan la fila i y la columna j

	double a1 = m[0];	double a2 = m[1];	double a3 = m[2];	double a4 = m[3];
	double b1 = m[4];	double b2 = m[5];	double b3 = m[6];	double b4 = m[7];
	double c1 = m[8];	double c2 = m[9];	double c3 = m[10];	double c4 = m[11];
	double d1 = m[12];	double d2 = m[13];	double d3 = m[14];	double d4 = m[15];


	retVal[0]  =  Det3x3(b2, b3, b4, c2, c3, c4, d2, d3, d4);
	retVal[1]  = -Det3x3(a2, a3, a4, c2, c3, c4, d2, d3, d4);
	retVal[2]  =  Det3x3(a2, a3, a4, b2, b3, b4, d2, d3, d4);
	retVal[3]  = -Det3x3(a2, a3, a4, b2, b3, b4, c2, c3, c4);
	
	retVal[4]  = -Det3x3(b1, b3, b4, c1, c3, c4, d1, d3, d4);
	retVal[5]  =  Det3x3(a1, a3, a4, c1, c3, c4, d1, d3, d4);
	retVal[6]  = -Det3x3(a1, a3, a4, b1, b3, b4, d1, d3, d4);
	retVal[7]  =  Det3x3(a1, a3, a4, b1, b3, b4, c1, c3, c4);
	
	retVal[8]  =  Det3x3(b1, b2, b4, c1, c2, c4, d1, d2, d4);
	retVal[9]  = -Det3x3(a1, a2, a4, c1, c2, c4, d1, d2, d4);
	retVal[10] =  Det3x3(a1, a2, a4, b1, b2, b4, d1, d2, d4);
	retVal[11] = -Det3x3(a1, a2, a4, b1, b2, b4, c1, c2, c4);
	
	retVal[12] = -Det3x3(b1, b2, b3, c1, c2, c3, d1, d2, d3);
	retVal[13] =  Det3x3(a1, a2, a3, c1, c2, c3, d1, d2, d3);
	retVal[14] = -Det3x3(a1, a2, a3, b1, b2, b3, d1, d2, d3);
	retVal[15] =  Det3x3(a1, a2, a3, b1, b2, b3, c1, c2, c3);
}//fin Adjunta()

double calculaMatrizInversa(double* mDestino, double* mFuente){
	double det = Determinante(mFuente);
	if (det!=0){
		Adjunta(mDestino, mFuente);
		for (int i=0; i<16; i++){
				mDestino[i] /= det; 
		}
		return true;
	} else {
		return false;
		}
}//fin calculaMatrizInversa
