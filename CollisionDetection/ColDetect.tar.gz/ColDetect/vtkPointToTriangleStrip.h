
/************************************************************************************************

Esta clase calcula la envolvente convexa de una nube de puntos
y triangula sus caras. Esta nube de puntos corresponde a los 
vÃ©rtices de una caja de una herramienta en los instantes t-1 y t.
  
 ***********************************************************************************************/

#ifndef __vtkEnvolventeTriangulada_h
#define __vtkEnvolventeTriangulada_h

#ifdef _WIN32
#include <algorithm>
#include <math.h>
#else
#include <math.h>
#include <algo.h>
#endif
#include "vtkesquiColDetectWin32Header.h"
#include "vtkObject.h"
//#include "Macros.h"
#define UMBRALMOVIMIENTO 0.1f
// Estructura para almacenar la informacion del vertice de la envolvente de movimiento
//! Store the information of the vertex of the movement surrounding.
typedef struct SurroundingVertex{
	// Componente absoluta x 
	//! Absolute component x
	float	x;				
	// Componente absoluta y
	//! Absolute component y
	float	y;				
	// Componente absoluta z
	//! Absolute component z
	float	z;				
	// Puntero a posible array de componentes relativas. MEMORIA DINÁMICA
	//! Pointer to possible array of relative components. DYNAMICAL MEMORY
	float*	Relativexyz;	

	//! Las siguientes variables indican si las coordenadas del vértice son máximas o mínimas.
	/*! Los valores asignados serán:
		* 0: La coordenada es mínima
		* 1: La coordenada es máxima
		* 2: La coordenada no es ni mínima ni máxima
	*/

	//! The following variables indicate if the coordinates of the vertex are maximum or minimal.
	/*! The assigned values will be:
		* 0: The coordinate is minimal
		* 1: The coordinate is maximal
		* 2 The coordinate is not minimal or maximal
	*/
	int		rolX;						
	int		rolY;
	int		rolZ;
	
	// Bandera que indica si el vértice forma parte de la envolvente
	//! Flag that indicates if the vertex forms a part of the surrounding.
	bool	SurroundingFlag;	
}SurroundingVertex;

// Clase para manejar la Envolvente del Movimiento usada en la deteccion de colisiones
//! Class to handle the Surrounding of the Movement used in the detection of collisions 
class VTK_ESQUI_COLDETECT_EXPORT vtkPointToTriangleStrip: public vtkObject
{

public:
	vtkTypeRevisionMacro(vtkPointToTriangleStrip, vtkObject);
	static vtkPointToTriangleStrip *New() {return new vtkPointToTriangleStrip;};
	const char *GetClassName() {return "vtkPointToTriangleStrip";};
	
	//========== CONSTRUCTOR & DESTRUCTOR=====================================
	vtkPointToTriangleStrip();
	~vtkPointToTriangleStrip();

	//    Vector de desplazamiento relativo. Cada posiciÃ³n corresponde a:
	/*
			* m_vRelativeDisplacement[0]: Desplazamiento en x
			* m_vRelativeDisplacement[1]: Desplazamiento en y
			* m_vRelativeDisplacement[2]: Desplazamiento en z
			 y se calcula como (coord en t)-(coord en t-1). Los valores serÃ¡n:
			* 0 : No ha habido desplazamiento
			* +d: Desplazamiento positivo
			* -d: Desplazamiento negativo
	*/

	//! Vector of relative displacement. Every position corresponds to:
	/*!
			* m_vRelativeDisplacement[0]: displacement in x
			* m_vRelativeDisplacement[1]: displacement in y
			* m_vRelativeDisplacement[2]: displacement in z
			And it is calculated like (coord in t) - (coord in t-1). The values are:
			* 0 : There has not been displacement
			* +d: Positive displacement
			* -d: Negative displacement
	*/

	float m_vRelativeDisplacement[3];
	//	 Matriz que en cada posiciÃ³n contiene una estructura SurroundingVertex
	/*
			* En la fila 0 estarÃ¡n los vÃ©rtices de la caja en el instante t-1
			* En la fila 1 estarÃ¡n los vÃ©rtices de la caja en el instante t
			* Las columnas corresponden a la struct SurroundingVertex. 
				# Posicion 0 a 3: cara de la caja con z mÃ­nima
				# Posicion 4 a 7: cara de la caja con z mÃ¡xima
	*/

	//! Matrix that in every position contains a structure SurroundingVertex
	/*
		* The row 0 contains the vertexes of the box in the instant t-1 
		* The row 1 contains the vertexes of the box in the instant t 
		* The columns correspond to the SurroundingVertex struct. 
			* Position 0 to 3: face of the box with z minimun
			* Position 4 to 7: face of the box with z maximun 	
	*/
	SurroundingVertex m_mVertices[2][8];
	





	//========== Access functions ============================================================

	//   Funcion que construye la envolvente convexa de dos prismas rectangulares

	//! Constructs the surrounding convex of two rectangular prisms

	void BuildSurrounding(double* vInitialVertexes, double* vFinalVertexes,double* vMovement,	
												 double* mTransformation,
												 double *vSurroundingVertexes);

	// Calcula la matriz inversa de la matriz de transformacion de la caja t-1
	//! Calculates the inverse matrix of the  transformation matrix of the box t-1
	void setInverseTransformationMatrix(float *mTransformation);

	// Crear la matriz de vertices de forma que estan ordenados de menor a mayor componente z.
	// Solo es necesario calcularlo para la caja en t-1 ya que en t serÃ¡n los mismo puntos

	//! Creates the matrix of Vertexes arranged as minor to major component z.
	//! Only it is necessary to calculate it for the box in t-1 since in t points will be them same
	void setMVertexes(float* vAnt, float* vAct);

	// Crea la lista de vÃ©rtices de la envolvente
	//! Creates the list of vertexes of the surrounding
	void setSurroundingVertexes();

	// Devuelve la matriz inversa de transformacion de la caja
	//! Returns the inverse matrix of transformation of the box
	float* getInverseTransformationMatrix() {return 0;}

	// Almacena los vertices de la envolvente en el vector vEnvolvente
	//! Stores the Vertexes of the surrounding one in the vEnvolvente vector
	void ObtainVSurrounding(float* vEnvolvente);

	//******** DEBUG FUNCTIONS ********

	// Devuelve el tiempo que tarda en triangular
	//! Returns the time that is late in to triangulate
	double	getTriangulationTime();	

	// Devuelve el tiempo que tarda en calcular la envolvente
	//! Returns the time it takes in calculating the surrounding
	double	getSurroundingTime();		

	// Devuelve el numero de vertices que forman la envolvente
	//! Returns the number of Vertexes that form the surrounding
	int		getSurroundingSize();		


private:

	//========== MEMBER VARIABLES ==============================================================

	//--- Matriz que en cada posiciÃ³n contiene una estructura SurroundingVertex
	//---	* En la fila 0 estarÃ¡n los vÃ©rtices de la caja en el instante t-1
	//---	* En la fila 1 estarÃ¡n los vÃ©rtices de la caja en el instante t
	//---	* Las columnas corresponden a la struct SurroundingVertex. 
	//---		# Posicion 0 a 3: cara de la caja con z mÃ­nima
	//---		# Posicion 4 a 7: cara de la caja con z mÃ¡xima
//	SurroundingVertex m_mVertices[2][8];



	// Matriz inversa de transformacion de la caja.
	/*
		La matriz de transformacin A de la caja es un float matriz[16] almacenado en
		vtkGeometricModel y que representa el giro y desplazamiento de los vertices
		de la caja desde el sistema de coordenadas local a la misma (con origen el 
		centro de la caja) al sistema de coordenadas global. Con lo que:
		* (1/A)Â·verticeGlobal[i] = verticeLocal[i]
	*/
	//! Inverse transformation matrix of the box.
	/*
		The transformation matrix of the box is a float matrix [16] stored in 
		vtkGeometricModel and that represents the draft and displacement of the Vertexes 
		of the box from the local system of coordinates to the same one (with origin 
		in the center of the box) to the global system of coordinates. With what:
		  * (1/A) Â · verticeGlobal [i] = verticeLocal [i] 	*/
	float m_mInverseTransformation[16];


	// Vector de coordenadas x relativas
	//! Vector of relative x coordinates 
	float m_coordX[8];

	// Vector de coordenadas y relativas
	//! Vector of relative y coordinates 
	float m_coordY[8];

	// Numero de vértices que forman la envolvente convexa
	//! Number of vertexes that form the convex surrounding
	int m_numSurroundingVertexes;

	//******** DEBUG ATRIBUTES ********

	// Tiempo que tarda en triangular
	//! Contains the time taken to triangulate
	double m_ttrian;						

	// Tiempo que tarda en calcular la envolvente
	//! Contains the time taken to calculate the surrounding
	double m_tenv;							


	//========== OPERATION FUNCTIONS =========================================================

	// Calcular las coordenadas relativas de la cara que minimiza z de cada caja
	//! Calculates the relative coordinates of the face that minimizes z of every box
	void applyInverseMatrixTransformation() {};

	// Ordena los vectores de modo que la coordenada z vaya de menor a mayor
	/* 
		Ordena los vectores de modo que la coordenada z vaya de menor a mayor
		con lo que las 4 primeras posiciones formarÃ¡n la cara de la caja que minimiza z y las
		4 siguientes la cara de la caja que maximiza z de forma local
	*/

	//! Arranges the vectors so that the coordinate z goes from minor to major
	/*! 
		Arranges the vectors so that the coordinate z goes from minor to major
		with what the first 4 positions will form the face of the box that minimizes z and the 
		4 following ones the face of the box that maximizes z of local form 
	*/
	void setPosZAxis(float* vAnt, int* vPosOrdenadas); 

	// Funcion que ordena las posiciones de vAnt de menor a mayor coordenada z
	//! Function that arranges the positions of vAnt from minor to major coordinate z
	void Swap(int j, int* vPosOrdenadas, float* vAnt); 

	// Calcula las coordenadas relativas de los 8 vertices con z minima
	//! Calculates the relative coordinates of 8 Vertexes with z minimun
	void setRelativeXYZ();

	// Comprobar sobre quÃ© ejes se ha producido un desplazamiento entre las cajas
	//! Verify on what axes a displacement has been produced between the boxes
	void setRelativeDisplacement();

	// Activa los flags de los vertices de m_matrizVertices que tienen,al menos,una coordenada
	/*
		Activa los flags de los vertices de m_matrizVertices que tienen,al menos,una coordenada
	    (abcisa, ordenada o cota) extrema(mÃ¡xima o mÃ­nima) con la excepciÃ³n de que para la cota
	    nos quedamos sÃ³lo con los mÃ­n(los mÃ¡x estarÃ¡n en la cara trasera de la otra caja)
	    sobre los ejes relativos. Estos puntos, junto con los correspondientes de la cara 
		trasera seran los que formen la envolvente convexa.
	*/
	
	//! Activates the flags of the vertex of m_matrizVertices that have, at least, a coordinate
	/*
		Activates the flags of the Vertexes of m_matrizVertices that have, at least, a coordinate 
		(X,Y or Z) carried to extremes (maximal or minimal) with the exception of which for the Z  
		we remain only with minimal (the maximal will be in the back face of another box) on the relative axes. 
		These points, together with the correspondents of the back face will form the surrounding 
		convex.
	*/
	void ActivateSurroundingFlags();

	// Activa los flags de la envolvente debidos a que la coordenada X sea max o min
	//! Activates the flags of the surrounding if the coordinate X is max or min
	void setMaxMinX();

	// Activa los flags de la envolvente debidos a que la coordenada Y sea max o min
	//! Activates the flags of the surrounding if the coordinate Y is max or min 
	void setMaxMinY();

	// Activa los flags de la envolvente debidos a que la coordenada Z sea max o min
	//! Activates the flags of the surrounding if the coordinate Z is max or min 
	void setMaxMinZ();

};//class EnvolventeTriangulada
#endif
