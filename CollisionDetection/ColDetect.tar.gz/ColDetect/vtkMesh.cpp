/*
 ******************************************************************************
 * Title: Mesh
 * Project: ColDetection Library
 ******************************************************************************
 * File: Mesh.cpp
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-02-18
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Mesh Body
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#include "vtkMesh.h"
#include "vtkVector3f.h"
vtkCxxRevisionMacro(vtkMesh, "$Revision: 0.1 $");

vtkMesh::vtkMesh(void) 
{
  initDeformSon = new std::vector<BoundingBoxTree*>;
}

vtkMesh::~vtkMesh(void)
{
  delete[] _vertexes;
  delete[] _facets;

  delete[] _neighborsOfFacets;
  delete[] _facetsOfVertices;
  delete[] _neighborsOfVertices;

  delete initDeformSon;
}

void vtkMesh::computeFacetRing(void)
{
  _neighborsOfFacets = new std::vector<unsigned>[nbFacets];
  
  for (unsigned i = 0 ; i < nbFacets ; i++) {
  
    unsigned& a = _facets[i].a;
    unsigned& b = _facets[i].b;
    unsigned& c = _facets[i].c;

    for (unsigned j = 0 ; j < nbFacets ; j++) {
      if (i == j) continue;
      
      unsigned& aa = _facets[j].a;
      unsigned& bb = _facets[j].b;
      unsigned& cc = _facets[j].c;
      
      if (((a == aa || a == bb || a == cc) &&
	  (b == aa || b == bb || b == cc)) ||
	  ((a == aa || a == bb || a == cc) &&
	  (c == aa || c == bb || c == cc) )||
	  ((b == aa || b == bb || b == cc) &&
	  (c == aa || c == bb || c == cc)))
	_neighborsOfFacets[i].push_back(j);
	    }
  }
  
}

void vtkMesh::computeVertexNeighbors(void)
{
  _neighborsOfVertices = new std::vector<unsigned>[nbVertexes];

  // First, compute the list of edges for each vertex using alArray
  // facilities
  
  std::vector<std::vector<unsigned> > edgesOfVerticesTemp;

  // Edges of current vertex (i.e index of Vertexes theses edges are
  // pointing to)
  std::vector<unsigned> edges;
 
  for (unsigned vertexIndex = 0 ;
       vertexIndex < nbVertexes ;
       vertexIndex++) {
    
    std::vector<unsigned>& facetsOfVerticesTemp = _facetsOfVertices[vertexIndex];
    
    edges.clear();
    
    for (unsigned facetIndex = 0 ; 
	 facetIndex < facetsOfVerticesTemp.size() ;
	 facetIndex++) {
      
      vtkVector3ui& facet = _facets[facetsOfVerticesTemp[facetIndex]];
      
      if ((facet.a != vertexIndex) && (index(edges, facet.a) == -1)) {
	edges.push_back(facet.a);
	_neighborsOfVertices[vertexIndex].push_back(facet.a);
      }
      if ((facet.b != vertexIndex) && (index(edges, facet.b) == -1)) {
	edges.push_back(facet.b);
	_neighborsOfVertices[vertexIndex].push_back(facet.b);
      }
      if ((facet.c != vertexIndex) && (index(edges, facet.c) == -1)) {
	edges.push_back(facet.c);
	_neighborsOfVertices[vertexIndex].push_back(facet.c);
      }
    }
    
    edgesOfVerticesTemp.push_back(edges);
  }
  
}

void vtkMesh::computeFacetsOfVertices(void)
{
  this->_facetsOfVertices = new std::vector<unsigned>[nbVertexes];
  
  for (unsigned i = 0 ; i < nbFacets ; i++) {

    // get vertex indices of current facet
    unsigned& aInd = this->_facets[i].a;
    unsigned& bInd = this->_facets[i].b;
    unsigned& cInd = this->_facets[i].c;

    // store vertex -> facet link
    this->_facetsOfVertices[aInd].push_back(i);
    this->_facetsOfVertices[bInd].push_back(i);
    this->_facetsOfVertices[cInd].push_back(i);
  }
  
}

/* Mesh.cpp ends here */
