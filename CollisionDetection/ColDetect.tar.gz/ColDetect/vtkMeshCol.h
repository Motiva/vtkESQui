/*
 ******************************************************************************
 * Title: MeshCol
 * Project: ColDetection Library
 ******************************************************************************
 * File: MeshCol.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-13
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Collision detection of 2 general mesh
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef MESHCOL_H
#define MESHCOL_H

#include "vtkHBBInteraction.h"
#include "vtkDObject.h"
//#include "Macros.h"
#include "vtkesquiColDetectWin32Header.h"
 
//! Local structure to store collision facets.
struct CollisionPair
{
  unsigned F1;
  unsigned F2;
  planeEq P1;
  planeEq P2;
};

 
//! Class MeshCol. Performs collision detection between 2 mesh .

class VTK_ESQUI_COLDETECT_EXPORT vtkMeshCol: public vtkHBBInteraction 
{
public:
  //BTX
  std::vector<unsigned> CS1;
  std::vector<unsigned> CS2;
  //ETX
private:
  //! Pointer to Vertexes of A  
  vtkVector3f* _ptsA; 
  //! Pointer to Vertexes of B  
  vtkVector3f* _ptsB; 
  //! Pointer to facets of A    
  const vtkVector3ui* _triA; 
  //! Pointer to facets of B    
  const vtkVector3ui* _triB; 
//BTX
  std::vector<unsigned> IB1;
  std::vector<unsigned> OB1;
  std::vector<unsigned> IB2;
  std::vector<unsigned> OB2;

  std::vector<CollisionPair> collisionFacets;
//ETX
  //! Collision volume of object A
  double colVolA; 
  //! Collision volume of object B
  double colVolB; 
  //! Collision volume Center Of Mass of object A
  vtkVector3f colComA; 
//BTX
  const std::vector<unsigned>* neighborsA;
  const std::vector<unsigned>* neighborsB;
//ETX
  bool collision;
  
  bool searchSurface;

public:
  vtkTypeRevisionMacro(vtkMeshCol, vtkHBBInteraction);
  static vtkMeshCol *New() {return new vtkMeshCol;};
  const char *GetClassName() {return "vtkMeshCol";};
  vtkMeshCol() {};
  vtkMeshCol(vtkDObject* obj1,
	  vtkDObject* obj2,
	  bool search);
  
  ~vtkMeshCol(void);
  
  
  //! Check collision between two objects.
  //BTX
  void getCollisionInfo(std::vector<CollisionPair>& collisionInfo);
  //ETX
   
//!Check collision between leaf facets.
  bool VerifyCollision(void);
  
private:  
  
  //! Triangle triangle intersection test routine.
  bool facetFacetCollisionTest(const vtkVector3f& a0,
			       const vtkVector3f& a1,
			       const vtkVector3f& a2,
			       const vtkVector3f& b0, 
			       const vtkVector3f& b1,
			       const vtkVector3f& b2, 
			       const vtkVector3f& n1,
			       const vtkVector3f& n2);
  
   
   //! Search for all contact 
  /*!
     Search for all contact  elements by first constructing the inner 
     and outer boundary.
     Then localize recursively from the inner boundary list.
  */
  void search(void);
  
   
   //!Construct the contact surface from the inner boundary list.
   
   /*!
		The variable seed will be the starting point.	  
   */
  //BTX
  void contactSurface(unsigned seed,
		      const std::vector<unsigned>* neighbors, 
		      std::vector<unsigned>& CS,
		      std::vector<unsigned>& OB);
 
  
   //! Calculate the volume of penetration and the center of mass of this volume. Force will be applied at this point.
  void collisionVolume(double& colVol,
		       vtkVector3f& colCom,
		       const vtkVector3f* pts,
		       const vtkVector3ui* tri,
		       std::vector<unsigned>& CS);
  
//ETX
};

#endif /* ifndef MESHCOL_H */

/* MeshCol.h ends here */
