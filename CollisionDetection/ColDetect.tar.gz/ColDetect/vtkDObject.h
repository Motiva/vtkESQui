/*
 ******************************************************************************
 * Title: CDObject
 * Project: ColDetection Library
 ******************************************************************************
 * File: CDObject.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-02-03
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * ColDetection Object, Internal Representation of Mesh and Geometry
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */
#ifndef __vtkDObject_h
#define __vtkDObject_h

#include "tools.h" 
#include "Matrix4f.h" 
#include "vtkMesh.h"
#include "vtkObject.h"
#include "Macros.h"
#include "vtkesquiColDetectWin32Header.h"

enum objectState {
  CREATED, NEWOBJECT, ADD_TRIANGLE
};

//! Objects for collision Detection
class VTK_ESQUI_COLDETECT_EXPORT vtkDObject: public vtkObject
{
public:
  //! Mesh represented by the Object
  vtkMesh* mesh;
  
  //! Current transformation matrix of the object
  double** trans;

  objectState state;

public:  
  vtkTypeRevisionMacro(vtkDObject, vtkObject);
  static vtkDObject *New() {return new vtkDObject;};
  const char *GetClassName() {return "vtkDObject";};
  //! Constructor
  vtkDObject(void);
  
  ~vtkDObject(void);
  
  void beginObject(unsigned nbFacets, unsigned nbVertexes);

  //! Set verts of object
  void SetVertexes(double** Vertexes);
  //! Set verts of object
  void SetVertexes(double* Vertexes);
 //BTX
  //! Get verts of object
  void GetVertexes(unsigned face, unsigned* Vertexes);
//ETX	
	void CoordsVertexes(unsigned vertex, float* coord);

	//! Returns relative coords to verts
	void RelativeCoordsVertexes(unsigned vertex, float* coord);

  //! Add Triangle
  void addTriangle(unsigned idFace,
		   const unsigned v1,
		   const unsigned v2,
		   const unsigned v3);

  //! Compute Intermediate Structure
  void computeIntermediateStructure(void);
  //! Gets Transformation matrix
  double** getTransformationMatrix();
  //! Set Transformation matrix
  void SetTransformationMatrix(double* trans[16]);
  //! Update the vertex
  void UpdateVertex(unsigned idVertex,
		    double x,
		    double y,
		    double z);
  
};

#endif /* ifndef CDOBJECT_H */

/* CDObject.h ends here */
