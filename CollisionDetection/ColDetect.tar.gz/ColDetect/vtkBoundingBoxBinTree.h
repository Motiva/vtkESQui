/*
 ******************************************************************************
 * Title: BoundingBoxBinTree
 * Project: ColDetection Library
 ******************************************************************************
 * File: BoundingBoxBinTree.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-02-18
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Bounding Box Binary Tree
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef BOUNDINGBOXBINTREE_H
#define BOUNDINGBOXBINTREE_H

#include "tools.h"
//#include "Macros.h"
#include "vtkMesh.h"
#include "vtkVector3f.h"
#include "vtkObject.h"
#include "vtkesquiColDetectWin32Header.h"

#define BBBT_MIN_DIAG 0.0000001
#define BBBT_ALPHA 0.3

 
//! Simple bounding box.
 
class VTK_ESQUI_COLDETECT_EXPORT vtkBoundingBoxBinTree: public vtkObject
{

public:
  vtkTypeRevisionMacro(vtkBoundingBoxBinTree, vtkObject);
  static vtkBoundingBoxBinTree *New() {return new vtkBoundingBoxBinTree;};
  const char *GetClassName() {return "vtkBoundingBoxBinTree";};
  
  vtkBoundingBoxBinTree() {};
  vtkBoundingBoxBinTree(vtkMesh* mesh);
   ~vtkBoundingBoxBinTree();
  
  //! Combine 2 bounding boxes to get another bounding box.
  static void combineBox(const BoundingBox& box1,
			 const BoundingBox& box2,
			 BoundingBox& boxRes);
  
  //! Build bounding box from Vertexes.
  static void constructBox(vtkVector3f* points,
			   unsigned nbVert,
			   BoundingBox& bboxRes);
//BTX
  //! Get The root BboxBinTree 
  BoundingBoxTree* getRootTree() {return _theTree;}

  //! Get the number of nodes. 
  unsigned getNodes() const {return _nodes;}

  //! Get the number of leafs. 
  unsigned getLeafs() const {return _leafs;}
  //ETX
private:
  //! Build Leaf Box for each facet.
  void buildLeaf();

  //! Build the hierarchy.
  void buildTree();

  //! Calculate lost volume when 2 boxes are combined.
  double lostVolume(const BoundingBox& box1, 
		    const BoundingBox& box2);
  
  // Print a Tree ; just for debug
//   void printTree(BoundingBoxTree* tree, unsigned n);

  // Print a Box ; just for debug
//   void printBox(BoundingBox* box);

  vtkBoundingBoxBinTree(const vtkBoundingBoxBinTree &) {}; //Not Implemented
  void operator=(const vtkBoundingBoxBinTree &){};// Not Implemented
//BTX
  unsigned _nodes;
  unsigned _leafs;
//ETX

  BoundingBoxTree* _theTree;

  vtkMesh* _theMesh;
//BTX
  std::vector<BoundingBoxTree*>* _theAccessFacetBBT;
  
  std::vector<BoundingBoxTree*>* svPTree;
  std::vector<BoundingBoxNode*>* svPNode;
  std::vector<BoundingBox*>*     svPBBox;
//ETX
};
#endif
