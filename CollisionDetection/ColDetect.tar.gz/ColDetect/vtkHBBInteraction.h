/*
 ******************************************************************************
 * Title: HBBInteraction
 * Project: ColDetection Library
 ******************************************************************************
 * File: HBBInteraction.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-13
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Hierarchical Bounding Box Interaction
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef HBBINTERACTION_H
#define HBBINTERACTION_H

#include "tools.h"
#include "vtkBoundingBoxBinTree.h"
#include "Matrix4f.h"
#include "vtkDObject.h"
#include "vtkObject.h"
#include "Macros.h"
#include "vtkesquiColDetectWin32Header.h"

//! Structure to memorise leaf collision
struct HBBCollision 
{
  BoundingBoxTree* leafA;
  BoundingBoxTree* leafB;
};

 
//! Class alHbbInteraction. Performs collision checking and distance computation between Hierarchical Bounding Boxs .

class VTK_ESQUI_COLDETECT_EXPORT vtkHBBInteraction: public vtkObject
{

public:
  vtkTypeRevisionMacro(vtkHBBInteraction, vtkObject);
  static vtkHBBInteraction *New() {return new vtkHBBInteraction;};
  const char *GetClassName() {return "vtkHBBInteraction";};
  

protected:
  double** transA;
  double** transB;
  //BTX
  //! Simple vector of leaf collidion detected
  std::vector<HBBCollision> svColl;
//ETX
  //! Ring structure for a box topology
  static int HBBRING[40];
  vtkHBBInteraction() {};
  vtkHBBInteraction(vtkDObject* obj1, vtkDObject* obj2);
  
  ~vtkHBBInteraction(void);
    
  //! Main routine to check collision . The standard SEPARATING AXIS TEST is used.
  bool checkCollision(void);

private:
   
  //!Descend the binary tree to get all collision boxes.
  BoundingBoxTree* _bboxTA;
  BoundingBoxTree* _bboxTB;
  void recurCheckCollision(void);
  
  void recurCheckCollisionSAT(BoundingBoxTree* bboxTA,
			      BoundingBoxTree* bboxTB);

  
  //! Use the SAT test for box box intersection check.
  bool checkBBoxCollision(BoundingBoxTree* bboxTA,
			  BoundingBoxTree* bboxTB);

};

#endif /* ifndef HBBINTERACTION_H */

/* HBBInteraction.h ends here */
