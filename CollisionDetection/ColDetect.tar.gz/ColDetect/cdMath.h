/*
 ******************************************************************************
 * Title: cdMath
 * Project: ColDetection Library
 ******************************************************************************
 * File: cdMath.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-08
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Math Tools Library
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef CDMATH_H
#define CDMATH_H
#ifdef _WIN32
#include <cmath>
#include <cfloat>
#else
#include <cmath.h>
#include <cfloat.h>
#endif

#define MAX_REAL DBL_MAX
#define MIN_REAL DBL_MIN
#define EPSILON  (1E-6)
#define ZERO     0.0
#define HALF     0.5
#define ONE      1.0

#define ABS(x)               (fabs(x))
#define IS_ALMOST_ZERO(x)    (ABS(x) < EPSILON)
#define MIN(x,y)             ((x) < (y) ? (x) : (y))
#define MAX(x,y)             ((x) > (y) ? (x) : (y))

#include "vtkVector3f.h"
// Simple 3D vector of unsigned integers.
struct vtkVector3ui
{
  unsigned a, b, c; 
  inline const unsigned& operator[](unsigned i) const;
};

const unsigned& vtkVector3ui::operator[](unsigned i) const
{
  return * (& a + i);
}



#endif /* ifndef CDMATH_H */

/* cdMath.h ends here */
