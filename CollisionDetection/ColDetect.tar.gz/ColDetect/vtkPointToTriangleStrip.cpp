#include "vtkPointToTriangleStrip.h"
#include "MathGlobal.h"

using namespace MG;
vtkCxxRevisionMacro(vtkPointToTriangleStrip, "$Revision: 0.1 $");
//La asignacion de Vertexes en la envolvente de 8 vertices es independiente
//de la direccion en que se haya movido la caja.

//The assignment of Vertexes in the surrounding of 8 Vertexes is independent from the direction in which the box has moved.
static const int Surrounding8Vertexes[3][3][3]={{{5,7,-1},{1,3,-1},{-1,-1,-1}},
													{{4,6,-1},{0,2,-1},{-1,-1,-1}},
													{{-1,-1,-1},{-1,-1,-1},{-1,-1,-1}}};

static const int Surrounding12VertexesXY[3][3][3]={{{8,11,-1},{-1,-1,-1},{2,5,-1}},
													{{-1,-1,-1},{0,3,-1},{6,9,-1}},
													{{7,10,-1},{1,4,-1},{-1,-1,-1}}};

static const int Surrounding12VertexesXLessY[3][3][3]={{{-1,-1,-1},{2,5,-1},{8,11,-1}},
													{{6,9,-1},{-1,-1,-1},{0,3,-1}},
													{{7,10,-1},{1,4,-1},{-1,-1,-1}}};

static const int Surrounding12VertexesXZ[3][3][3]={{{8,-1,2},{11,-1,5},{-1,-1,-1}},
													{{-1,0,6},{-1,3,9},{-1,-1,-1}},
													{{7,1,-1},{10,4,-1},{-1,-1,-1}}};

static const int Surrounding12VertexesXLessZ[3][3][3]={{{-1,0,1},{-1,3,4},{-1,-1,-1}},
													{{8,-1,7},{11,-1,10},{-1,-1,-1}},
													{{2,6,-1},{5,9,-1},{-1,-1,-1}}};


static const int Surrounding12VertexesYZ[3][3][3]={{{11,-1,10},{-1,3,4},{5,9,-1}},
													{{8,-1,7},{-1,0,1},{6,6,-1}},
													{{-1,-1,-1},{-1,-1,-1},{-1,-1,-1}}};

static const int Surrounding12VertexesYLessZ[3][3][3]={{{-1,9,10},{5,-1,4},{11,3,-1}},
													{{-1,6,7},{2,-1,1},{8,0,-1}},
													{{-1,-1,-1},{-1,-1,-1},{-1,-1,-1}}};

static const int Surrounding14VertexesXYZ[3][3][3]={{{11,-1,13},{-1,-1,-1},{8,-1,9}},
														{{-1,-1,-1},{-1,2,0},{-1,5,4}},
														{{10,-1,12},{-1,3,1},{7,6,-1}}};

static const int Surrounding14VertexesXYLessZ[3][3][3] = {{{-1,2,0},{-1,-1,-1},{-1,5,4}},
														{{-1,-1,-1},{11,-1,13},{8,-1,9}},
														{{-1,3,1},{10,-1,12},{7,6,-1}}};


static const int Surrounding14VertexesXLessYZ[3][3][3] = {{{-1,-1,-1},{2,-1,0},{5,-1,4}},
														{{-1,11,13},{-1,-1,-1},{-1,8,9}},
														{{-1,10,12},{3,-1,1},{6,7,-1}}};

static const int Surrounding14VertexesLessXYZ[3][3][3] = {{{-1,-1,-1},{-1,11,13},{-1,8,9}},
														{{2,-1,0},{-1,-1,-1},{5,-1,4}},
														{{3,-1,1},{-1,10,12},{6,7,-1}}};


//========== CONSTRUCTOR & DESTRUCTOR ==========================================

//--- Initialization of member variables 
vtkPointToTriangleStrip::vtkPointToTriangleStrip(){
	for (int i=0; i<3; i++)			{ m_vRelativeDisplacement[i] = false; }
	m_numSurroundingVertexes = 0;
	m_ttrian = 0;
	m_tenv  = 0;
}//End CEnvolventeTriangulada()

//--- Liberation of memory
vtkPointToTriangleStrip::~vtkPointToTriangleStrip(){
}//End ~CEnvolventeTriangulada()




void vtkPointToTriangleStrip::BuildSurrounding(double* vInitialVertexes,
												double* vFinalVertexes,
												double* vMovement,
												 double* mTransformation,
												 double *vSurroundingVertexes){
	//vector de vertices: junto los dos vectores de vertices en uno:

	//Vector of Vertexes: join both vectors of Vertexes in one
	double vVertices[48];//3*8*2
	
 	for(unsigned i=0; i<24; i++)
	{		
		vVertices[i]=vInitialVertexes[i];
		vVertices[i+24]=vFinalVertexes[i];
	}
	
	//Ahora tendria que encontrar los maximos y minimos en xyz
	//Find the maximus and minimus

	double maximos[3]={-1000, -1000, -1000}; //maximus in X Y Z
	double minimos[3]={1000, 1000, 1000}; //minimus in X Y Z
	unsigned vVerticesMaxMin[48];//16*3.. Vector that indicates if one of its componentes is
								// maximus(1), minimus(0) o nothing(2)

	for(unsigned i=0; i<16/*8*2*/; i++)
	{
		for(unsigned j=0; j<3; j++)
		{
			if(vVertices[3*i+j]>=maximos[j])
			{
				maximos[j]=vVertices[3*i+j];
			}
			if(vVertices[3*i+j]<=minimos[j])
			{
				minimos[j]=vVertices[3*i+j];
			}
		}
	}

	double tol=0.00001;  

	for(unsigned i=0; i<16/*8*2*/; i++)
	{
		for(unsigned j=0; j<3; j++)
		{
			if(fabs(vVertices[3*i+j]-maximos[j])<tol)
			{
				vVerticesMaxMin[3*i+j]=1;
			}
			else if(fabs(vVertices[3*i+j]-minimos[j])<tol)
			{
				vVerticesMaxMin[3*i+j]=0;
			}
			else 
			{
				vVerticesMaxMin[3*i+j]=2;
			}
		}
	}
	// Asigno los vertices de la envolvente en funcion del numero de ejes en los que se haya movido:
	//Assign the Vertexes of the surrounding depending on the number of axes in which it has moved:
	
int numVertices;

	// movimiento solo en un eje (Z, Y o X)
	// movement only in an axis (Z, Y or X)
	if((fabs(vMovement[0])<UMBRALMOVIMIENTO && fabs(vMovement[1])<UMBRALMOVIMIENTO) ||
		(fabs(vMovement[0])<UMBRALMOVIMIENTO && fabs(vMovement[2])<UMBRALMOVIMIENTO) ||
		(fabs(vMovement[1])<UMBRALMOVIMIENTO && fabs(vMovement[2])<UMBRALMOVIMIENTO) ) 
	{
		numVertices=8;
		for(unsigned i=0; i<16; i++)
		{
			int indiceVerticeEnvolvente=Surrounding8Vertexes[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
			if(indiceVerticeEnvolvente!=-1)
			{
				vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
				vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
				vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
			}
		}

	}
	//Movimientos en 2 ejes.
	// Movements in 2 axes
	else if(fabs(vMovement[0])<UMBRALMOVIMIENTO) //Movement in YZ
	{
		numVertices=12;

		if((vMovement[1]>0 && vMovement[2]>0) || (vMovement[1]<0 && vMovement[2]<0)) //(Y,Z) o (-y,-z)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding12VertexesYZ[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}
		else // (-y,z) o (z,-y)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding12VertexesYLessZ[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		
		}

	}
	else if(fabs(vMovement[1])<UMBRALMOVIMIENTO) //Movement in XZ
	{
		numVertices=12;

	
		if((vMovement[0]>0 && vMovement[2]>0) || (vMovement[0]<0 && vMovement[2]<0)) //(x,Z) o (-x,-z)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding12VertexesXZ[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];	
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}
		else //(-x,z) o (x, -z)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding12VertexesXLessZ[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];	
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}

	}
	else if(fabs(vMovement[2])<UMBRALMOVIMIENTO) //Movement in XY
	{
		numVertices=12;

		if((vMovement[0]>0 && vMovement[1]>0) || (vMovement[0]<0 && vMovement[2]<0)) //(x,y) o (-x,-y)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding12VertexesXY[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}
		else // (-x,y) o (x,-y)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding12VertexesXLessY[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}


	}
	else // Movement in XYZ
	{
		numVertices=14;

		if((vMovement[0]>0 && vMovement[1]>0 && vMovement[2]>0) ||
			 (vMovement[0]<0 && vMovement[1]<0 && vMovement[2]<0)) //(x,y,z) o (-x,-y,-z)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding14VertexesXYZ[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}
		else if((vMovement[0]>0 && vMovement[1]>0 && vMovement[2]<0) ||
			 (vMovement[0]<0 && vMovement[1]<0 && vMovement[2]>0)) //(x,y,-z) o (-x,-y,z)
	
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding14VertexesXYLessZ[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}
		else if((vMovement[0]>0 && vMovement[1]<0 && vMovement[2]>0) ||
			 (vMovement[0]<0 && vMovement[1]>0 && vMovement[2]<0)) //(x,-y,z) o (-x,y,-z)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding14VertexesXLessYZ[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}
		else if((vMovement[0]>0 && vMovement[1]<0 && vMovement[2]<0) ||
			 (vMovement[0]<0 && vMovement[1]>0 && vMovement[2]>0)) //(x,-y,-z) o (-x,y,z)
		{
			for(unsigned i=0; i<16; i++)
			{
				int indiceVerticeEnvolvente=Surrounding14VertexesLessXYZ[vVerticesMaxMin[3*i] ][vVerticesMaxMin[3*i+1]][vVerticesMaxMin[3*i+2]];
				if(indiceVerticeEnvolvente!=-1)
				{
					vSurroundingVertexes[indiceVerticeEnvolvente*3]=vVertices[i*3];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+1]=vVertices[i*3+1];
					vSurroundingVertexes[indiceVerticeEnvolvente*3+2]=vVertices[i*3+2];
				}
			}
		}
	
	}

	// Una vez construida la envolvente en coordenadas locales se multiplica por la matriz de transformacion
	// para que se corresponda con la posicion y giro de la herramienta.

	//Once constructed the surrounding in local coordinates, multiplies for the transformation matrix in order that it fits with the position and draft of the tool.

	for(int i=0; i<numVertices; i++)
	{
		double vVerticesEnvolventeLocal[3];
		vVerticesEnvolventeLocal[0]=vSurroundingVertexes[i*3];
		vVerticesEnvolventeLocal[1]=vSurroundingVertexes[i*3+1];
		vVerticesEnvolventeLocal[2]=vSurroundingVertexes[i*3+2];
			
		vSurroundingVertexes[i*3] = mTransformation[0] * vVerticesEnvolventeLocal[0] + 
								   mTransformation[4] * vVerticesEnvolventeLocal[1] + 
								   mTransformation[8] * vVerticesEnvolventeLocal[2] + 
								   mTransformation[12];
		vSurroundingVertexes[i*3+1] =mTransformation[1] * vVerticesEnvolventeLocal[0] + 
									mTransformation[5] * vVerticesEnvolventeLocal[1]+ 
									mTransformation[9] * vVerticesEnvolventeLocal[2] + 
								    mTransformation[13];
		vSurroundingVertexes[i*3+2] =mTransformation[2] * vVerticesEnvolventeLocal[0] + 
									  mTransformation[6] * vVerticesEnvolventeLocal[1] + 
									  mTransformation[10]* vVerticesEnvolventeLocal[2] + 
									  mTransformation[14];
		
	}

}//End BuildSurrounding()*/




//--- Calcula la matriz inversa de la matriz de transformaciÃ³n de la caja t-1

// Calculates the inverse matrix of the transformation matrix of the box t-1
void vtkPointToTriangleStrip::setInverseTransformationMatrix(float* mTransformation){

}//End setVTransformacion


//--- create the matrix of vertexes so that they are arranged of minor to major component z.
//--- Only it is necessary to calculate it for the box in t-1 since in t points will be them same
void vtkPointToTriangleStrip::setMVertexes(float* vAnt, float* vAct){

	//GLOBALS!!!

//			Puede que sean necesario calcular el plano que se va a seleccionar en funciÃ³n del
//			vector de movimiento (en lugar de escoger los puntos que minimicen z por defecto) ya
//			que si la herramienta se mueve con un Ã¡ngulo de 45Âº sÃ³lo saldrÃ¡n 2 puntos en cada
//			caja que minimicen z, no 4.

//			It is possible that it is necessary to calculate the plane that is going to be selected
//			depending on the vector of movement (instead of choosing the points that they minimize 
//			z by default)  since if the tool moves with an angle of 45 º only 2 points will go out 
//			in every box that they minimize z, not 4.


	// vPosOrdenadas serÃ¡ un vector que contendrÃ¡ las posiciones de vAnt y vAct para las cuales 
	// z es mÃ­nima:
	// * vPosOrdenadas[0] a vPosOrdenadas[3]: Pos de vAnt&vAct que forman la cara con z local mÃ­n
	// * vPosOrdenadas[4] a vPosOrdenadas[7]: Pos de vAnt&vAct que forman la cara con z local mÃ¡x
	// * vPosOrdenadas[i] corresponde a vPosOrdenadas[i+4] con 0<=i<=3 en la cara opuesta

	// vPosOrdenadas: It is a vector that will contain the positions of vAnt and vAct for which 
	// z is maximun:
	// * vPosOrdenadas[0] to vPosOrdenadas[3]: Pos of vAnt&vAct witch forms the face with local z minimun
	// * vPosOrdenadas[4] to vPosOrdenadas[7]: Pos of vAnt&vAct witch forms the face with local z maximun
	// * vPosOrdenadas[i] corresponds to vPosOrdenadas[i+4] with 0<=i<=3 in the opposite face


	int* vPosOrdenadas = new int[8];
	setPosZAxis(vAnt, vPosOrdenadas);	//  Set vPosOrdenadas
	for (unsigned j=0; j<8; j++){
		m_mVertices[0][j].x = vAnt[vPosOrdenadas[j]-2];
		m_mVertices[0][j].y = vAnt[vPosOrdenadas[j]-1];
		m_mVertices[0][j].z = vAnt[vPosOrdenadas[j]];
		m_mVertices[0][j].SurroundingFlag = false;
		// Los roles de las coordenadas se inicializan a 2, que significa que no son mÃ¡x ni mÃ­n
		// The roles of the coordinates inicializan to 2, which means that they are not max or min 
		m_mVertices[0][j].rolX = m_mVertices[0][j].rolY = m_mVertices[0][j].rolZ = 2;
		// Si es la cara mÃ­n en z de la caja reservamos memoria para almacenar las 
		// coordenadas de los vÃ©rtices respecto al eje relativo que vamos a calcular.

		//If it is the face min in z of the box we reserve memory to store the coordinates of the 
		//vertexes with regard to the relative axis that we are going to calculate.
		if (j<4)	{ m_mVertices[0][j].Relativexyz = new float[3]; }
		else		{ m_mVertices[0][j].Relativexyz = NULL; }
	}//end for
	for (unsigned j=0; j<8; j++){
		m_mVertices[1][j].x = vAct[vPosOrdenadas[j]-2];
		m_mVertices[1][j].y = vAct[vPosOrdenadas[j]-1];
		m_mVertices[1][j].z = vAct[vPosOrdenadas[j]];
		m_mVertices[1][j].SurroundingFlag = false;
		// Los roles de las coordenadas se inicializan a 2, que significa que no son mÃ¡x ni mÃ­n

		// The roles of the coordinates inicializan to 2, which means that they are not max or min 
		m_mVertices[1][j].rolX = m_mVertices[1][j].rolY = m_mVertices[1][j].rolZ = 2;

		// Si es la cara mÃ­n en z de la caja reservamos memoria para almacenar las 
		// coordenadas de los vÃ©rtices respecto al eje relativo que vamos a calcular.

		//If it is the face min in z of the box we reserve memory to store the coordinates of the 
		//vertexes with regard to the relative axis that we are going to calculate.
		if (j<4)	{ m_mVertices[1][j].Relativexyz = new float[3]; }
		else		{ m_mVertices[1][j].Relativexyz = NULL; }
	}//fin for
	
	//Liberación de recursos
	//Liberation of resources 
	delete[] vPosOrdenadas;
}//End setMVertexes()





//--- Crea la lista de vÃ©rtices de la envolvente

// Creates the list of vertexes of the surrounding
void vtkPointToTriangleStrip::setSurroundingVertexes(){

	//1. Establecer las coordenadas relativas de los vertices de m_matrizVertices que minimicen z

	// 1. Set the relative coordinates of the Vertexes of m_matrizVertices that minimize z 

		setRelativeXYZ();

	//2. Comprobar sobre quÃ© ejes se ha producido un desplazamiento entre las dos cajas
	// 2. Verify on what axes a displacement has been produced between both boxes 
		 setRelativeDisplacement();

	//3. Seleccionar los puntos que tienen, al menos, una coordenada (abcisa, ordenada o cota)
	//	 extrema (mÃ¡xima o mÃ­nima) con la excepciÃ³n de que para la cota nos quedamos sÃ³lo con 
	//	 los mÃ­nimos (los mÃ¡ximos estarÃ¡n en la cara trasera de la otra caja) sobre los ejes
	//	 relativos. Estos puntos, junto con los correspondientes de la cara â€œtraseraâ€� serÃ¡n los
	//	 que formen parte de la Envolvente convexa.
		 ActivateSurroundingFlags();
	//4. Crear un nuevo CModeloHerramienta y aÃ±adir los triÃ¡ngulos:
	//   - Los de los vÃ©rtices de cada herramienta local estÃ¡n triangulados
	//   - Unir los vÃ©rtices que tengan 4Âª dimensiÃ³n distinta y sean correspondientes en t-1 y t

}//fin setSurroundingVertexes()





//========== FUNCIONES DE OPERACIÃ“N =============================================================

//--- FunciÃ³n para ordenar los vectores de modo que la coordenada z vaya de menor a mayor
//--- con lo que las 4 primeras posiciones formarÃ¡n la cara de la caja que minimiza z y las
//--- 4 siguientes la cara de la caja que maximiza z de forma local
void vtkPointToTriangleStrip::setPosZAxis(float* vAnt, int* vPosOrdenadas){
	
	//Objetivo: Encontrar las caras con z mÃ­n y mÃ¡x de la caja en t-1. En t serÃ¡n los mismos
	vPosOrdenadas[7] = 2; //En la posiciÃ³n 2 de vAnt estÃ¡ la primera coordenada z del vector
	int j=6;
	for(int i=5; i<24; i=i+3){
		vPosOrdenadas[j] = i;
		Swap(j, vPosOrdenadas, vAnt);
		j--;
	}//fin for
}//fin ordenaVector()


//--- FunciÃ³n que ordena las posiciones de vAnt de menor a mayor coordenada z
void vtkPointToTriangleStrip::Swap(int j, int* vPosOrdenadas, float* vAnt){
	while (j!=7){
		if (vAnt[vPosOrdenadas[j]]>vAnt[vPosOrdenadas[j+1]]){
			int aux = vPosOrdenadas[j];
			vPosOrdenadas[j] = vPosOrdenadas[j+1];
			vPosOrdenadas[j+1] = aux;
			j++;
		}else{
			break;
		}//fin if
	}//fin while
}//fin Swap()



//--- Calcula las coordenadas relativas de los 8 vÃ©rtices de m_matrizVertices con z mÃ­nima
//--- (los 4 de la caja en t-1 y los 4 de la caja en t)
void vtkPointToTriangleStrip::setRelativeXYZ(){
	//Calcular las coordenadas relativas de la cara que minimiza z de cada caja
	//Se consigue aplicando la matriz de inversa de transformaciÃ³n a dichas coordenadas

	float* vAbsoluto = new float[4];		// Vector auxiliar para almacenar xyz absolutas
	int i;									// Itera sobre las filas de m_mVertices
	int	j;									// Itera sobre las columnas de m_mVertices
	int	k;									// Itera sobre el vector de vÃ©rtices relativos
	int m;								//Itera sobre los vectores de coordeandas relativas
	
	//La cuarta dimensiÃ³n de los vectores es necesaria para poder multiplicar por la matriz
	//de transformaciÃ³n
	m=0;
	vAbsoluto[3] = 1;							
	for (i=0; i<2; i++){
		for (j=0; j<4; j++){
			vAbsoluto[0] = m_mVertices[i][j].x;
			vAbsoluto[1] = m_mVertices[i][j].y;
			vAbsoluto[2] = m_mVertices[i][j].z;
			// MultiplicaciÃ³n del vector absoluto por la matriz de transformaciÃ³n
			// Almacena el resultado en m_mVertices[i][j].Relativexyz
			MG::multPM(vAbsoluto, m_mInverseTransformation, m_mVertices[i][j].Relativexyz);
			// Se hace un redondeo hacia el entero mÃ¡s prÃ³ximo para evitar errores en comparaciones
			// OJO!!: EL CAST RETRASA UN EGG, BUSCAR UNA FUNCIÃ“N DE REDONDEO
			for (k=0; k<3; k++){
				if (m_mVertices[i][j].Relativexyz[k]<0){
					m_mVertices[i][j].Relativexyz[k] = (float)((int)(m_mVertices[i][j].Relativexyz[k]-0.5f));
				}//fin if
				if (m_mVertices[i][j].Relativexyz[k]>0){
					m_mVertices[i][j].Relativexyz[k] = (float)((int)(m_mVertices[i][j].Relativexyz[k]+0.5f));
				}//fin if
			}//fin for
			m_coordX[m] = m_mVertices[i][j].Relativexyz[0]; //Almaceno la coordenada x
			m_coordY[m] = m_mVertices[i][j].Relativexyz[1]; //Almaceno la coordenada y	
			m++;
		}//fin for
	}//fin for
	//LiberaciÃ³n de recursos
	delete[] vAbsoluto;
}//fin setRelativeXYZ()




//--- Activa una bandera en los ejes en los que se haya producido desplazamiento
void vtkPointToTriangleStrip::setRelativeDisplacement(){
	//Comprobar sobre quÃ© ejes se ha producido desplazamiento. Basta con calcularlo para un vÃ©rtice
	float d;	//Variable que almacena el desplazamiento que se ha producido en uno de los ejes
	for (int coord=0; coord<3; coord++){
		d = (m_mVertices[1][0].Relativexyz[coord] - m_mVertices[0][0].Relativexyz[coord]);
		m_vRelativeDisplacement[coord] = d;
	}//fin for
}//fin calculaDesplazamientoRelativo()


//--- Activa los flags de los vÃ©rtices de m_mVertices que tienen, al menos, una coordenada
//--- (abcisa, ordenada o cota) extrema (mÃ¡xima o mÃ­nima) con la excepciÃ³n de que para la cota
//--- nos quedamos sÃ³lo con los mÃ­nimos (los mÃ¡ximos estarÃ¡n en la cara trasera de la otra caja)
//--- sobre los ejes relativos. Estos puntos, junto con los correspondientes de la cara â€œtraseraâ€�
//--- serÃ¡n los que formen la envolvente convexa.
void vtkPointToTriangleStrip::ActivateSurroundingFlags(){
		if (m_vRelativeDisplacement[2]!=0) setMaxMinZ();
		if (m_vRelativeDisplacement[1]!=0) setMaxMinY();
		if (m_vRelativeDisplacement[0]!=0) setMaxMinX();
}//fin ActivateSurroundingFlags()



//--- Activa los flags de la envolvente debidos a que la coordenada Z sea mÃ¡x o mÃ­n
void vtkPointToTriangleStrip::setMaxMinZ(){

	int i,j;

	//m_vRelativeDisplacement[2] es: (coordZ en t) - (coordZ en t-1)
	for (i=0; i<2; i++){
		for(j=0; j<4; j++){
			if (m_vRelativeDisplacement[2]>0){	
			//Si la caja en el instante t-1 tiene la cara z mÃ­nima
				if(i==0){ //Tiene z mÃ­nima en t-1
					if (!m_mVertices[0][j].SurroundingFlag){
						m_mVertices[0][j].SurroundingFlag   = true;
						m_mVertices[0][j].rolZ   = 0;
						m_numSurroundingVertexes++;
					}//fin if
				}
				else{  //Tiene z mÃ¡xima en t
					if(!m_mVertices[1][j+4].SurroundingFlag){
						m_mVertices[1][j+4].SurroundingFlag = true; 
						m_mVertices[1][j+4].rolZ   = 1;
						m_numSurroundingVertexes++;
					}//fin if
				}
			}else{	
			//Si la caja en el instante t tiene la cara z mÃ­nima: m_vRelativeDisplacement[2]<0
				if(i==0){  //Tiene z mÃ¡xima en t-1
					if(!m_mVertices[0][j+4].SurroundingFlag){
						m_mVertices[0][j+4].SurroundingFlag = true;
						m_mVertices[0][j+4].rolZ   = 1;
						m_numSurroundingVertexes++;
					}//fin if
				}//fin if
				else{  //Tiene z mÃ­nima en t
					if (!m_mVertices[1][j].SurroundingFlag){
						m_mVertices[1][j].SurroundingFlag   = true;
						m_mVertices[1][j].rolZ = 0;
						m_numSurroundingVertexes++;
					}//fin if
				}//fin if
			}//fin if
		}//fin for
	}//fin for
}//fin setMaxMinZ()


//--- Activa los flags de la envolvente debidos a que la coordenada Y sea mÃ¡x o mÃ­n
void vtkPointToTriangleStrip::setMaxMinY(){

		int i,j;

		//Se ordena el vector coordY de menor a mayor
		std::sort(m_coordY, m_coordY + 8);

		for (i=0; i<2; i++){
			for(j=0; j<4; j++){
				if ((m_mVertices[i][j].Relativexyz[1]==m_coordY[0])|| //	Si tiene y mÃ­nima o
					(m_mVertices[i][j].Relativexyz[1]==m_coordY[7])){ //			 y mÃ¡xima
						// Este vÃ©rtice forma parte de la envolvente
						if(!m_mVertices[i][j].SurroundingFlag){
							m_mVertices[i][j].SurroundingFlag= true;
							m_numSurroundingVertexes++;
						}//fin if
						// Y el vÃ©rtice correspondiente de la cara trasera tambiÃ©n
						if(!m_mVertices[i][j+4].SurroundingFlag){
							m_mVertices[i][j+4].SurroundingFlag= true;
							m_numSurroundingVertexes++;
						}//fin if
						if (m_mVertices[i][j].Relativexyz[1]==m_coordY[0]) { // Si tiene y mÃ­nima
							m_mVertices[i][j].rolY = 0;		// Cara delantera. La coord es mÃ­nima
							m_mVertices[i][j+4].rolY = 0;	// Cara trasera. La coord es mÃ­nima
						}//fin if
						if (m_mVertices[i][j].Relativexyz[1]==m_coordY[7]) { // Si tiene y mÃ¡xima
							m_mVertices[i][j].rolY = 1;		// Cara delantera. La coord es mÃ¡xima
							m_mVertices[i][j+4].rolY = 1;	// Cara trasera. La coord es mÃ¡xima
						}//fin if
				}//fin if
			}//fin for
		}//fin for
}//fin setMaxMinY()


//--- Activa los flags de la envolvente debidos a que la coordenada X sea mÃ¡x o mÃ­n
void vtkPointToTriangleStrip::setMaxMinX(){

		int i,j;

		//Se ordena el vector coordY de menor a mayor
		std::sort(m_coordX, m_coordX + 8);

		for (i=0; i<2; i++){
			for(j=0; j<4; j++){
				if ((m_mVertices[i][j].Relativexyz[0]==m_coordX[0])|| //	Si tiene x mÃ­nima o
					(m_mVertices[i][j].Relativexyz[0]==m_coordX[7])){ //			 x mÃ¡xima
						// Este vÃ©rtice forma parte de la envolvente
						if(!m_mVertices[i][j].SurroundingFlag){
							m_mVertices[i][j].SurroundingFlag= true;
							m_numSurroundingVertexes++;
						}//fin if
						// Y el vÃ©rtice correspondiente de la cara trasera tambiÃ©n
						if(!m_mVertices[i][j+4].SurroundingFlag){
							m_mVertices[i][j+4].SurroundingFlag= true;
							m_numSurroundingVertexes++;
						}//fin if
						if (m_mVertices[i][j].Relativexyz[0]==m_coordX[0]) { // Si tiene x mÃ­nima
							m_mVertices[i][j].rolX = 0;		// Cara delantera. La coord es mÃ­nima
							m_mVertices[i][j+4].rolX = 0;	// Cara trasera. La coord es mÃ­nima
						}//fin if
						if (m_mVertices[i][j].Relativexyz[0]==m_coordX[7]) { // Si tiene x mÃ¡xima
							m_mVertices[i][j].rolX = 1;		// Cara delantera. La coord es mÃ¡xima
							m_mVertices[i][j+4].rolX = 1;	// Cara trasera. La coord es mÃ¡xima
						}//fin if
				}//fin if
			}//fin for
		}//fin for
}//fin setMaxMinX()

//--- Almacena los vÃ©rtices de la envolvente en el vector vEnvolvente
void vtkPointToTriangleStrip::ObtainVSurrounding(float* vEnvolvente){
	
	int k=0;
	//vEnvolvente = new float[m_numSurroundingVertexes];
	for (int i=0; i<2; i++){
		for (int j=0; j<8; j++){
			if (m_mVertices[i][j].SurroundingFlag){
				vEnvolvente[k]   = m_mVertices[i][j].x;
				vEnvolvente[k+1] = m_mVertices[i][j].y;
				vEnvolvente[k+2] = m_mVertices[i][j].z;
				k=k+3;
			}//fin if
		}//fin for
	}//fin for
}//fin ObtainVSurrounding

//*********** FUNCIONES DE DEPURACIÃ“N ***********************************************************
double vtkPointToTriangleStrip::getTriangulationTime(){
	return m_ttrian;
}
double vtkPointToTriangleStrip::getSurroundingTime(){
	return m_tenv;
}
int vtkPointToTriangleStrip::getSurroundingSize(){
	return m_numSurroundingVertexes;
}
