////////////////////////
// Fichero MathGlobal.h
////////////////////////
// Contiene algunas funciones matemáticas globales de ayuda para el simulador
//
// Contains some global mathematical functions useful for the simulator
// Version 1.0b
////////////////////////

#ifndef _OSCARMATHGLOBAL_v10B_
#define _OSCARMATHGLOBAL_v10B_

#include "vtkesquiColDetectWin32Header.h"

// #pragma once
//BTX
namespace MG	// MathGlobal
{
//ETX	
	void VTK_ESQUI_COLDETECT_EXPORT quaternion2Dir(float* q,float* vDir);
	void VTK_ESQUI_COLDETECT_EXPORT mult(float* v1,float* v2,float* vResult);
	float VTK_ESQUI_COLDETECT_EXPORT dot(float* v1,float* v2);
	void VTK_ESQUI_COLDETECT_EXPORT multVM(float* vect,float* matrix,float* vResult);
	void VTK_ESQUI_COLDETECT_EXPORT multPM(float* vect,float* matrix,float* vResult);
	
	void VTK_ESQUI_COLDETECT_EXPORT normalize(float* v);
	void VTK_ESQUI_COLDETECT_EXPORT sub(float* v1,float* v2,float* vRes);
	float VTK_ESQUI_COLDETECT_EXPORT length(float* v);

//BTX
}// Del Namespace
//ETX
#endif
