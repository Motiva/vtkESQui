/*
 ******************************************************************************
 * Title: tools
 * Project: ColDetection Library
 ******************************************************************************
 * File: tools.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-03
 * Last update: 2003-05-20
 ******************************************************************************
 * Description:
 * Tools Definition
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef TOOLS_H
#define TOOLS_H

// Standard C Includes
#include <cstdlib>

// STL Includes

#ifndef _WIN32
#include <stdio.h>
//#include <iostream.h>
#include <vector.h>
#else
#include <stdio.h>
//#include <iostream>
#include <vector>
#endif


#undef DEBUG
#define DEBUG

#ifdef DEBUG
#  define SPY(str) cerr << __FILE__ << ": " << __LINE__ << ": " << str << endl
#else
#  define SPY(str)
#endif /* ifdef DEBUG
*/

#include "vtkVector3f.h"


/**
 * Returns the index of the present item El (-1 other wise) in the
 * vector V
 */


template <class T> int index(const std::vector<T> V, const T& El)
{
  for (unsigned n = 0 ; n < V.size() ; n++)
    if (V[n] == El) return n;
  return -1;
}

#endif /* ifndef TOOLS_H */

/* tools.h ends here */
