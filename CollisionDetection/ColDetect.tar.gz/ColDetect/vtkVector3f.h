/*
 ******************************************************************************
 * Title: vtkVector3f
 * Project: ColDetection Library
 ******************************************************************************
 * File: vtkVector3f.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-08
 * Last update: 2003-05-20
 ******************************************************************************
 * Description:
 * Vector 3f & Plane Equation
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef __vtkVector3f_h
#define __vtkVector3f_h

#include "tools.h"
#include "vtkObject.h"

#ifdef _WIN32
#include <cmath>
#include <cfloat>
#include "vtkesquiColDetectWin32Header.h"
#else
#include <math.h>
#include <float.h>
#endif

#define MAX_REAL DBL_MAX
#define MIN_REAL DBL_MIN
#define EPSILON  (1E-6)
#define ZERO     0.0
#define HALF     0.5
#define ONE      1.0

#define ABS(x)               (fabs(x))
#define IS_ALMOST_ZERO(x)    (ABS(x) < EPSILON)
#define MIN(x,y)             ((x) < (y) ? (x) : (y))
#define MAX(x,y)             ((x) > (y) ? (x) : (y))
// #include "vtkPlaneeq.h"
//! Plane Equation
struct vtkVector3ui
{
  unsigned a, b, c; 
  inline const unsigned& operator[](unsigned i) const;
};
//! Vector 3f 
struct vtkVector3f //: public vtkObject
{

public:
 //BTX
  double x;
  double y;
  double z;
  //! Default constructor
  inline vtkVector3f(void): x(ZERO), y(ZERO), z(ZERO)
  {}

  //! Construct from 1 double
  inline vtkVector3f(double a)
    : x(a), y(a), z(a)
  {}

  //! Construct from 3 doubles
  inline vtkVector3f(double a, double b, double c)
    : x(a), y(b), z(c)
  {}

  //! Construct from an array of 3 doubles
  inline vtkVector3f(const double* t) 
    : x(t[0]), y(t[1]), z(t[2])
  {}

//   inline friend std::ostream& operator<<(std::ostream& out, const vtkVector3f& v);
//ETX
  inline bool operator==(const vtkVector3f& v) const;

  inline bool operator!=(const vtkVector3f& v) const;

  inline vtkVector3f& operator=(const vtkVector3f& v);

  inline vtkVector3f& operator=(double k);

  //! Dot product operator.
  inline double operator*(const vtkVector3f& v) const;

  inline vtkVector3f& operator+=(const vtkVector3f& vec);

  inline vtkVector3f& operator-=(const vtkVector3f& vec);

  //! Increment each component by k.
  inline vtkVector3f& operator+=(double k);

  //! Decrement each component by k.
  inline vtkVector3f& operator-=(double k);

  //! Multiply each component by k.
  inline vtkVector3f& operator*=(double k);

  //! Divide each component by k.
  inline vtkVector3f& operator/=(double k);

  inline vtkVector3f operator-(void) const;

  inline vtkVector3f operator*(const double k) const;

  inline vtkVector3f operator/(const double k) const;

  //! Cross product operator.
  inline vtkVector3f operator^(const vtkVector3f& v) const;

  inline friend vtkVector3f operator+(const vtkVector3f& v1, const vtkVector3f& v2);

  inline friend vtkVector3f operator-(const vtkVector3f& v1, const vtkVector3f& v2);

  inline friend vtkVector3f operator*(const double k, const vtkVector3f& v);

  //! Set components to zero.
  inline void zero(void);

  //! True if vector is null.
  inline bool isNull(void);

  //! Return the square norm.
  inline double norm2(void);

  //! Return the norm.
  inline double norm(void) const;

  //! Normalize the vector and return its old length.
  inline double normalize(void);

  //! Test quasi-equality.
  inline bool almostEqual(const vtkVector3f& v);

  //! Test if near zero.
  inline bool isAlmostNull(void);

  //! Modify from three doubles.
  inline void setCoordinates(double xx, double yy, double zz);

  //! Modify from vector.
  /*!
	We do not use a copy constructor since it would force us to write one for each child class.
  */
  inline void setCoordinates(const vtkVector3f& v);

  //! Copy the current coordinates into three doubles.
  inline void getCoordinates(double& xx, double& yy, double& zz);

  //! Cross product. this := u * v.
  inline void crossProduct(const vtkVector3f& u, const vtkVector3f& v);

  //! Do this= u + t * (v - u).
  inline void interpolate(double t, const vtkVector3f& u, const vtkVector3f& v);

  //! Compute the normal vector of a triangle.
  /*!
	  a, b and c are the coordinates of the 3 Vertexes: this = (a - b) ^ (b - c)
  */
  inline void makeTriNormal(const vtkVector3f& a,
			    const vtkVector3f& b,
			    const vtkVector3f& c);

  //! Compute the normal vector of a triangle.
  /*!
	  t is a pointer on 3 vectors that contains the coordinates of the 3 Vertexes.
      this = (t[0]-t[1])^(t[1]-t[2])a, b and c are the coordinates of the 3 Vertexes: this = (a - b) ^ (b - c)
  */	
  inline void makeTriNormal(const vtkVector3f* t);

  /**
   * 
   * this = v - n*(v.n)
   */
  //! Orthogonal projection of v on a line whose direction is n.
  inline void project(const vtkVector3f& v, const vtkVector3f& n);
  
  
  //!Compute the distance between the 2 vtkVector3f
  inline double distance(const vtkVector3f& v) const;

  //! C-style methods
  inline static void copy(vtkVector3f& dst, const vtkVector3f& org);
  //! C-style methods
  inline static void makeTriNormal(vtkVector3f& dst,
				   const vtkVector3f& a,
				   const vtkVector3f& b,
				   const vtkVector3f& c);

  //! C-style methods
  inline static void setXYZ(vtkVector3f& dst, double xx, double yy, double zz);
//   void SetXYZ(double x, double y, double z);
};


//Las definiciones van aqui porque se trantan de funciones inline.
// Operators
// vtkCxxRevisionMacro(vtkVector3f, "$Revision: 0.1 $");
const unsigned& vtkVector3ui::operator[](unsigned i) const
{
  return * (& a + i);
}

// std::ostream& operator<<(std::ostream& out, const vtkVector3f& v)
// {
//   return out << "(" << v.x << ", " << v.y << ", " << v.z << ")";
// }

bool vtkVector3f::operator==(const vtkVector3f& v) const
{
  return (x == v.x && y == v.y && z == v.z);
}

vtkVector3f& vtkVector3f::operator=(double k)
{
  x = k;
  y = k;
  z = k;
  return * this;
}

bool vtkVector3f::operator!=(const vtkVector3f& v) const
{
  return (x != v.x || y != v.y || z != v.z);
}

vtkVector3f& vtkVector3f::operator=(const vtkVector3f& v)
{
  x = v.x;
  y = v.y;
  z = v.z;
  return * this;
}

double vtkVector3f::operator*(const vtkVector3f & v) const
{
  return x * v.x + y * v.y + z * v.z;
}

vtkVector3f & vtkVector3f::operator+=(const vtkVector3f & vec)
{
  x += vec.x;
  y += vec.y;
  z += vec.z;
  return * this;
}

vtkVector3f & vtkVector3f::operator+=(double k)
{
  x += k;
  y += k;
  z += k;
  return * this;
}

vtkVector3f & vtkVector3f::operator-=(const vtkVector3f & vec)
{
  x -= vec.x;
  y -= vec.y;
  z -= vec.z;
  return * this;
} 

vtkVector3f & vtkVector3f::operator-=(double k)
{
  x -= k;
  y -= k;
  z -= k;
  return * this;
} 

vtkVector3f & vtkVector3f::operator*=(double k)
{
  x *= k;
  y *= k;
  z *= k;
  return * this;
}

vtkVector3f & vtkVector3f::operator/=(double k)
{
  x /= k;
  y /= k;
  z /= k;
  return * this;
}

// Methods that return an object (not optimal)

vtkVector3f vtkVector3f::operator-(void) const 
{
  return vtkVector3f(-x, -y, -z);
}

vtkVector3f vtkVector3f::operator*(const double k) const 
{
  return vtkVector3f(k * x, k * y, k * z);
}

vtkVector3f vtkVector3f::operator/(const double k) const 
{
  return vtkVector3f(x / k, y / k, z / k);
}

vtkVector3f vtkVector3f::operator^(const vtkVector3f & v) const
{
  return vtkVector3f(y * v.z - z * v.y, z * v.x -v.z * x, x * v.y - y * v.x);
}

vtkVector3f operator+(const vtkVector3f & v1, const vtkVector3f & v2)
{
  vtkVector3f add = v1;
  add += v2;
  return add;
}

vtkVector3f operator-(const vtkVector3f & v1, const vtkVector3f & v2)
{
  vtkVector3f sub = v1;
  sub -= v2;
  return sub;
}

vtkVector3f operator*(const double k, const vtkVector3f & v)
{ 
  return v * k;
} 

// Methods

void vtkVector3f::zero(void)
{
  x = ZERO;
  y = ZERO;
  z = ZERO;
}

bool vtkVector3f::isNull(void)
{
  return (x == ZERO) && (y == ZERO) && (z == ZERO);
}

double vtkVector3f::norm2(void)
{
  return (x * x + y * y + z * z);
}

double vtkVector3f::norm(void) const
{
  return (double) sqrt(x * x + y * y + z * z);
}

double vtkVector3f::normalize(void)
{
  double n = norm();
  if (! IS_ALMOST_ZERO(n)) * this /= n;
  return n;
}

bool vtkVector3f::almostEqual(const vtkVector3f & v)
{
  return IS_ALMOST_ZERO(v.x - x) && IS_ALMOST_ZERO(v.y - y) && 
    IS_ALMOST_ZERO(v.z - z);
}

bool vtkVector3f::isAlmostNull(void)
{
  return IS_ALMOST_ZERO(x) && IS_ALMOST_ZERO(y) && IS_ALMOST_ZERO(z);
}

void vtkVector3f::setCoordinates(double xx, double yy, double zz)
{
  x = xx;
  y = yy;
  z = zz;
}

void vtkVector3f::setCoordinates(const vtkVector3f & v)
{
  setCoordinates(v.x, v.y, v.z);
}

void vtkVector3f::getCoordinates(double& xx, double& yy, double &zz)
{
  xx = x;
  yy = y;
  zz = z;
}

void vtkVector3f::crossProduct(const vtkVector3f & u, const vtkVector3f & v)
{
  x = u.y * v.z - u.z * v.y;
  y = u.z * v.x - u.x * v.z;
  z = u.x * v.y - u.y * v.x;
}

void vtkVector3f::interpolate(double t, const vtkVector3f & u, const vtkVector3f & v)
{
  x = u.x + t * (v.x - u.x);
  y = u.y + t * (v.y - u.y);
  z = u.z + t * (v.z - u.z);
}

void vtkVector3f::makeTriNormal(const vtkVector3f & a,
			     const vtkVector3f & b,
			     const vtkVector3f & c)
{
  vtkVector3f v1(a), v2(b);
  v1 -= b;
  v2 -= c;
  crossProduct(v1, v2);
}

void vtkVector3f::makeTriNormal(const vtkVector3f* t)
{
  vtkVector3f v1(t[0]), v2(t[1]);
  v1 -= t[1];
  v2 -= t[2];
  crossProduct(v1, v2);
}

void vtkVector3f::project(const vtkVector3f & v, const vtkVector3f & n)
{
  setCoordinates(n);
  * this *= - v * n;
  * this += v;
}

/**
 * Compute the distance between the 2 vtkVector3f
 */
double vtkVector3f::distance(const vtkVector3f& v) const 
{
  return (* this - v).norm();
}

// C-style methods

void vtkVector3f::copy(vtkVector3f& dst, const vtkVector3f& org)
{
  dst.x = org.x;
  dst.y = org.y;
  dst.z = org.z;
}  

void vtkVector3f::makeTriNormal(vtkVector3f& dst,
			     const vtkVector3f& a,
			     const vtkVector3f& b,
			     const vtkVector3f& c)
{
  vtkVector3f v1(a), v2(b);
  v1 -= b;
  v2 -= c;
  dst = v1 ^ v2;
}

void vtkVector3f::setXYZ(vtkVector3f& dst, double xx, double yy, double zz)
{
  dst.x = xx;
  dst.y = yy;
  dst.z = zz;
}

// Constants

// Null vector
static const vtkVector3f VECT_ZERO(ZERO, ZERO, ZERO);

// OX vector
static const vtkVector3f VECT_OX(ONE, ZERO, ZERO);

// OY vector
static const vtkVector3f VECT_OY(ZERO, ONE, ZERO);

// OZ vector
static const vtkVector3f VECT_OZ(ZERO, ZERO, ONE);

struct planeEq
{
  vtkVector3f n;
  double d;
};
// Compute the plane equation a.x + b.y + c.z = d, given 3
// points. n = (a,b,c).
inline void makePlaneEq(planeEq& p,
			const vtkVector3f& u,
			const vtkVector3f& v,
			const vtkVector3f& w)
{
  p.n.makeTriNormal(u, v, w);
  p.n.normalize();
  p.d = p.n * u;
}



/**
 * Compute the distance from a point u to a plane
 * (nx * x + ny * y + nz * z = d).
 * The normal vector n must be unit length.
 */
inline double dist2Plane(planeEq& p,
			 const vtkVector3f& u)
{
  return ((p.n * u) - p.d);
}

#endif /* ifndef VECTOR3F_H */

/* vtkVector3f.h ends here */
