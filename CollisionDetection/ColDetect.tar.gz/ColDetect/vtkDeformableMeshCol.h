/*
 ******************************************************************************
 * Title: DeformableMeshCol
 * Project: ColDetection Library
 ******************************************************************************
 * File: DeformableMeshCol.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-13
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Collision detection of 2 general deformable mesh
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef DEFORMABLEMESHCOL_H
#define DEFORMABLEMESHCOL_H

#ifdef _WIN32
#include <vector>
#include <iostream>
#else
#include <vector.h>
#include <iostream.h>
#endif

#include "vtkHBBInteraction.h"
#include "vtkDObject.h"
#include "vtkMeshCol.h"
#include "vtkBoundingBoxBinTree.h"
#include "Macros.h"
#include "vtkesquiColDetectWin32Header.h"

//using namespace std;

struct ShearPlanes
{
	unsigned CS;
	std::vector<planeEq> planos;
};
//!Class DeformableMeshCol. Performs collision detection between 2 general deformable mesh. 

class VTK_ESQUI_COLDETECT_EXPORT vtkDeformableMeshCol: public vtkHBBInteraction 
{

public:
  //BTX
  std::vector<unsigned> CS1;
  std::vector<unsigned> CS2;
  //ETX
  vtkTypeRevisionMacro(vtkDeformableMeshCol, vtkHBBInteraction);
  static vtkDeformableMeshCol *New() {return new vtkDeformableMeshCol;};
  const char *GetClassName() {return "vtkDeformableMeshCol";};
  
  vtkDeformableMeshCol() {};
  vtkDeformableMeshCol(vtkDObject* obj1,
		    vtkDObject* obj2,
		    bool search);
  
  ~vtkDeformableMeshCol(void);
   //BTX
  /// Obtencion de datos de colision entre dos objetos
  //! Obtains collision between two objects information 
  void getCollisionInfo(std::vector<CollisionPair>& collisionInfo);
  //ETX
	 
  //! Check collision between leaf facets.
  bool VerifyCollision(void);
  
private:

  vtkDObject* obj1;
  vtkDObject* obj2;

  //! pointer to Vertexes of A  
  const vtkVector3f* _ptsA; 
  //! pointer to Vertexes of B  
  const vtkVector3f* _ptsB; 
  //! pointer to facets of A    
  const vtkVector3ui* _triA; 
  //! pointer to facets of B    
  const vtkVector3ui* _triB; 
//BTX
  std::vector<unsigned> IB1;
  std::vector<unsigned> OB1;
  std::vector<unsigned> IB2;
  std::vector<unsigned> OB2;

  std::vector<CollisionPair> collisionFacets;
//ETX
  //! Collision volume of object A
  double colVolA; 
  //! Collision volume of object B
  double colVolB; 
  //! Collision volume Center Of Mass of object A
  vtkVector3f colComA; 
//BTX
  const std::vector<unsigned>* neighborsA;
  const std::vector<unsigned>* neighborsB;
//ETX  
  bool collision;

  bool searchSurface;
  
  //BTX
  //! List of Son to Deform
  std::vector<BoundingBoxTree*> deformSonA, deformSonB;
  //! List of Father to Deform
  std::vector<BoundingBoxTree*> deformFatherA, deformFatherB;
  //ETX
   
  //! Triangle triangle intersection test routine.   
  bool facetFacetCollisionTest(const vtkVector3f& a0,
			       const vtkVector3f& a1,
			       const vtkVector3f& a2,
			       const vtkVector3f& b0, 
			       const vtkVector3f& b1,
			       const vtkVector3f& b2, 
			       const vtkVector3f& n1,
			       const vtkVector3f& n2);
  
   
  //! Search for all contact elements by first constructing the inner and outer boundary. Then localize recursively from the inner boundary list.
  void search(void);

//BTX
  void BuildContour(std::vector<unsigned>& CS, std::vector<unsigned>& OB, 
										  const std::vector<unsigned>* neighbors, unsigned cara) {};
   
  //!  Construct the contact surface from the inner boundary list. The variable seed will be the starting point.
  void contactSurface(unsigned seed,
		      const std::vector<unsigned>* neighbors, 
		      std::vector<unsigned>& CS,
		      std::vector<unsigned>& OB);

  //! Calculate the volume of penetration and the center of mass of this volume. force will be applied at this point.
  void collisionVolume(double& colVol,
		       vtkVector3f& colCom,
		       const vtkVector3f* pts,
		       const vtkVector3ui* tri,
		       std::vector<unsigned>& CS);

  
  //! Update the BoundingBox Tree with the lists deformFather and deformSon
  void update(const vtkVector3f* pts,
	      const vtkVector3ui* tri,
	      std::vector<BoundingBoxTree*>& deformSon,
	      std::vector<BoundingBoxTree*>& deformFather);
  //ETX
  
   //! Update a Box
   /*!
     A Tree : combine the 2 sons boxes
     A Leaf : just construc the box
   */
  void updateBox(const vtkVector3f* pts,
		 const vtkVector3ui* tri,
		 BoundingBoxTree* bbt);
  
};

#endif /* ifndef DEFORMABLEMESHCOL_H */

/* DeformableMeshCol.h ends here */
