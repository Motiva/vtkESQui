/*
 ******************************************************************************
 * Title:
 * Project:
 ******************************************************************************
 * File: ConcaveDistance.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-15
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Compute distance between non-convex polyhedras 
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef CONCAVEDISTANCE_H
#define CONCAVEDISTANCE_H

#include "tools.h"
#include "vtkMesh.h"
#include "vtkDObject.h"
#include "vtkEnGJK.h"
#include "vtkObject.h"
//#include "Macros.h"
#include "vtkesquiColDetectWin32Header.h"
//! Compute distance between non-convex polyhedras
class VTK_ESQUI_COLDETECT_EXPORT vtkConcaveDistance: public vtkObject
{
private:
  
  double** transA;
  double** transB;

  //! pointer to Vertexes of A  
  vtkVector3f* _ptsA; 
  //! pointer to Vertexes of B
  vtkVector3f* _ptsB; 
  //! pointer to facets of A    
  const vtkVector3ui* _triA; 
  //! pointer to facets of B
  const vtkVector3ui* _triB; 

  BoundingBoxTree* bbARoot;
  BoundingBoxTree* bbBRoot;
//BTX
  std::vector<BoundingBoxTree *> bbAMinVector;
  std::vector<BoundingBoxTree *> bbBMinVector;

  std::vector<vtkVector3f> tabCoordVectorA;
  std::vector<vtkVector3f> tabCoordVectorB;

  std::vector<unsigned>* triangleRing;
//ETX
  double distanceMin;
  
  vtkVector3f* tabVectorRes;

public:
  vtkTypeRevisionMacro(vtkConcaveDistance, vtkObject);
  static vtkConcaveDistance *New();
  const char *GetClassName() {return "vtkConcaveDistance";};
  vtkConcaveDistance() {};
  vtkConcaveDistance(vtkDObject* obj1, vtkDObject* obj2);
  
  ~vtkConcaveDistance(void);

  double getDistance(void);

  vtkVector3f* getTabVectorRes(void) {return tabVectorRes;}

  vtkConcaveDistance (const vtkConcaveDistance &);
  vtkConcaveDistance operator =(const vtkConcaveDistance &);
private:  
  void recurSearchMin(BoundingBoxTree* bbA, 
		      BoundingBoxTree* bbB);
  
  void exploreA(BoundingBoxTree* bbA,
		BoundingBoxTree* bbB);
  
  void exploreB(BoundingBoxTree* bbA,
		BoundingBoxTree* bbB);
  
  double distanceBBoxAsSphere(BoundingBoxTree* bbA,
			      BoundingBoxTree* bbB);
  
  double distanceTriangleTriangle(int indA,
				 int indB);
 
  void computeTriangleRing(void);
  
  double searchCoupleMin(void);
  
};

#endif /* ifndef CONCAVEDISTANCE_H */

/* ConcaveDistance.h ends here */

