/*
 ******************************************************************************
 * Title: Mesh
 * Project: ColDetection Library
 ******************************************************************************
 * File: Mesh.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-02-18
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Mesh Description
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef MESH_H
#define MESH_H

#include "tools.h" 

#include "vtkObject.h"
#include "Macros.h"
#include "vtkesquiColDetectWin32Header.h"
//! A Bounding box 
struct BoundingBox 
{
  vtkVector3f center;
  vtkVector3f diagonal;
  double volume;
  vtkVector3f Vertexes[8];
};
//! Enum with the type of bounding box
enum BoundingBoxNodeType {
  LEAF, TREE
};
//! A bounding box node
struct BoundingBoxNode 
{
  BoundingBoxNodeType type;
  BoundingBox* box;
  unsigned id;
};
//! A bounding box tree
struct BoundingBoxTree
{
  BoundingBoxNode* node;
  BoundingBoxTree* lson;
  BoundingBoxTree* rson;
  BoundingBoxTree* father;
  bool changed;
};
//! Mesh for collision detect
class VTK_ESQUI_COLDETECT_EXPORT vtkMesh: public vtkObject
{
public:
  //BTX
  //! Number of Vertexes
  unsigned nbVertexes;

  //! Number of facets
  unsigned nbFacets;
//ETX
  //! Vertex coordinates
  vtkVector3f* _vertexes;

  //! Indices of Vertexes for each triangle
  vtkVector3ui* _facets;
//BTX  
  //! Indices of neighbouring facets for each facet
  std::vector<unsigned>* _neighborsOfFacets;

  //! Indices of neighbouring Vertexes for each vertex.
  std::vector<unsigned>* _neighborsOfVertices;

  //! Indices of neighbouring facets for each vertex
  std::vector<unsigned>* _facetsOfVertices;

  //! For the facet i accessFacetBBT[i] = BoundingBoxTree (a leaf) associate to the facet i 
  std::vector<BoundingBoxTree*>* accessFacetBBT;

  //! List of initial leaf of the bounding box tree that need to be updated 
  std::vector<BoundingBoxTree*>* initDeformSon;
  //ETX
private:
  //! Bounding Box Tree of the object
  BoundingBoxTree* _boundingBoxTree;

public:
  vtkTypeRevisionMacro(vtkMesh, vtkObject);
  static vtkMesh *New() {return new vtkMesh;};
  const char *GetClassName() {return "vtkMesh";};
  
  vtkMesh(void);
  ~vtkMesh(void);
  
  //! Get the array of vertex coordinates.
  vtkVector3f* Vertexes(void) {return _vertexes;}

  //! Get the array of indices of Vertexes for each triangular facet.
  vtkVector3ui* facets(void) {return _facets;}
//BTX
  //! Get the array for neighbour of facets.
  const std::vector<unsigned>* neighborsOfFacets(void) {return _neighborsOfFacets;}

  //! Get the array of each vertex neighbors.
  const std::vector<unsigned>* neighborsOfVertices(void) 
  {return _neighborsOfVertices;}
//ETX
  //! Get the BBox Binary Tree read-only
  BoundingBoxTree* getBoundingBoxTree(void) {return _boundingBoxTree;}

  //! Set the BBox Binary Tree
  void setBoundingBoxTree(BoundingBoxTree* bbt) {_boundingBoxTree = bbt;};
//BTX
  //! Set the AccessFacetBBT list
  void setAccessFacetBBT(std::vector<BoundingBoxTree*>* acc) {accessFacetBBT = acc;};
//ETX
  //! alMesh::computeFacetRing \\ GJK
  void computeFacetRing(void);

  //! alMesh::computeRing \\ GJK
  void computeVertexNeighbors(void);

  //! alMesh::buildVertex2FacetLinks \\ GJK
  void computeFacetsOfVertices(void);
  
};

#endif /* ifndef MESH_H */

/* Mesh.h ends here */
