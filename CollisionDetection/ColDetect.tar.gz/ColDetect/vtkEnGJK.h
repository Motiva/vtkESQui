/*
 ******************************************************************************
 * Title: EnGJK
 * Project: ColDetection Library
 ******************************************************************************
 * File: EnGJK.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-08
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * Enhanced GJK
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef ENGJK_H
#define ENGJK_H

#include "tools.h"
#include "Matrix4f.h"
#include "vtkDObject.h"
#include "vtkObject.h"
#include "Macros.h"
#include "vtkesquiColDetectWin32Header.h"

#define EDGE_APPROXIMATION                  1
#define TRIANGLE_APPROXIMATION              2
#define COLLISION                           3
#define NO_MORE_DESCENT                     4
#define NOT_INTERACTING                     5
#define OKAY                                6
#define RELATIVE_PRECISION_FOR_PROJECTION   0.01
#define RELATIVE_PRECISION                  0.1
#define SECURITY_DISTANCE_SQUARE            0.001
#define INTERACTION_DISTANCE                MAX_REAL
#define MIN_TRIANGLE_SURFACE                0.000001
#define MIN_EDGE_LENTH_SQUARE               0.001
//BTX
struct distMemory
{
  //! Number of point necessary to express the projection of wptB on A
  int nptsSimplexA;
  //! Number of point necessary to express the projection of wptA on B
  int nptsSimplexB;
  //! Index of these points
  int indexSimplexA[4];   
  //! Index of these points
  int indexSimplexB[4];  
  //! Previously calculated points expressed in A frame
  vtkVector3f wptA;
  //! Previously calculated points expressed in B frame
  vtkVector3f wptB;
};
//ETX
//! Enhanced GJK
class VTK_ESQUI_COLDETECT_EXPORT vtkEnGJK: public vtkObject
{
private:
   //BTX
  //! Transformation matrix
  double** transA;
  //! Transformation matrix
  double** transB;

  // GJK
  vtkVector3f* gjkPtsA;
  vtkVector3f* gjkPtsB;
  unsigned nptsA;
  unsigned nptsB;
 
  const std::vector<unsigned>* neighborA;
  const std::vector<unsigned>* neighborB;

  distMemory* memory;
  double gjkDist;

  vtkVector3f* tabVectorRes;
  //ETX  
public:
  
  vtkTypeRevisionMacro(vtkEnGJK, vtkObject);
  static vtkEnGJK *New() {return new vtkEnGJK;};
  const char *GetClassName() {return "vtkEnGJK";};
  
  vtkEnGJK(vtkDObject* obj1,
	vtkDObject* obj2);
//BTX
  vtkEnGJK(unsigned nptsA,
	vtkVector3f* verticesA,
	const std::vector<unsigned>* neighborsOfVerticesA,
	double* transA[16],
	unsigned nptsB,
	vtkVector3f* verticesB,
	const std::vector<unsigned>* neighborsOfVerticesB,
	double* transB[16]);
//ETX  
  ~vtkEnGJK(void);
  
  //! Return the distance between the 2 objects
  //
  /*! 
	This code is only valid for convex.
  */
  double getDistance(void);

  vtkVector3f* getTabVectorRes(void) {return tabVectorRes;}
protected:
	vtkEnGJK() {};  
private:
  //BTX
  void init(unsigned nptsA,
	    vtkVector3f* verticesA,
	    const std::vector<unsigned>* neighborsOfVerticesA,
	    double* transA[16],
	    unsigned nptsB,
	    vtkVector3f* verticesB,
	    const std::vector<unsigned>* neighborsOfVerticesB,
	    double* transB[16]);
  //ETX
  //! This routin returns true is there is a collision. 
  /*!
     It computes the distance between two convexes. This convex can be either a solid
     or a face. If it is a solid its topology is defined by a ring
     structure else it is defined with its original data structure ie
     pdb_polygon.
  
     The whitness points are stored in the distMemory data structure in
     the reference frame the corresponding convex.
  
     This code is only valid for convex.
  
     The principle is pased on finding the upper and the lower bound
     of the distance by alternatively projecting on point of one
     convex on the other.
  */
  bool enGJKDistance(void);
  
  //! This routine returns the index of the vertex wich minimizes direction.pts[i] (. is the dot product)
  /*!  
		It uses the topology described in ring to move directly to the most favorable vertex
  */
  //BTX
  int convexSupportFunction(const vtkVector3f pts[],
			    const std::vector<unsigned>* topo,
			    int start, 
			    const vtkVector3f& direction,
			    double* trans[16]);
  //ETX
  //! This routine computes the projection of one point (point) on a convex (object).
  /*!
	  It does not really return the projection point
	  but the projection on the tcso tcso_wpt. To obtain the real point
	  one has to add P+point. Everything must be express in the
      reference frame of the object.
  
     This code is only valid for convex.
  */
  int projectOriginOnSimplex(vtkVector3f& simplexWpt,
			     vtkVector3f simplex[4],
			     int simplexIndices[4],
			     int* nbSimplexPoint);
  
  //! This routine computes the projection of one point (point) on a convex (object).
  /*
	 It does not really return the projection point
	 but the projection on the tcso tcso_wpt. To obtain the real point
     one has to add P+point. Everything must be express in the
     reference frame of the object.
  
     This code is only valid for convex.
  */
  //BTX
  int projectPointOnConvex(const vtkVector3f& point,
			   const vtkVector3f object[], 
			   const std::vector<unsigned>* neighbor,
			   int simplexIndex[],
			   int* nbSimplexPoint,
			   vtkVector3f& tcsoWpt,
			   double* upperBound,
			   double* trans[16]);
//ETX
  void updateTabVectorRes(void);
  
};

#endif /* ifndef ENGJK_H */

/* EnGJK.h ends here */
