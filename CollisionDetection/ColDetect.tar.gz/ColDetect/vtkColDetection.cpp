/*
 ******************************************************************************
 * Title: ColDetection
 * Project: ColDetection Library
 ******************************************************************************
 * File: ColDetection.cpp
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-06
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * ColDetection body
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#include "vtkColDetection.h"



vtkColDetection::vtkColDetection(void)
{
  cdPrivate = new CDPrivate();
  cdPrivate -> vectorOfCDObjects = new std::vector<vtkDObject *>;
  cdPrivate -> vectorOfEnGJK = new std::vector<vtkEnGJK*>;
  cdPrivate -> vectorOfConcaveDistance = new std::vector<vtkConcaveDistance*>;
  cdPrivate -> vectorOfMeshCol = new std::vector<vtkMeshCol*>;
  cdPrivate -> vectorOfDeformableMeshCol = new std::vector<vtkDeformableMeshCol*>;
}

vtkColDetection::~vtkColDetection(void)

{
	unsigned i;
	for (i = 0 ; i < (cdPrivate -> vectorOfCDObjects) -> size() ; i++)
		(* (cdPrivate -> vectorOfCDObjects))[i]->Delete();
	
	delete cdPrivate -> vectorOfCDObjects;

	for ( /*unsigned*/ i = 0 ; i < (cdPrivate -> vectorOfEnGJK) -> size() ; i++) 
		(* (cdPrivate -> vectorOfEnGJK))[i]->Delete();
	
	delete cdPrivate -> vectorOfEnGJK;


	for ( /*unsigned*/ i = 0 ; i < (cdPrivate -> vectorOfConcaveDistance) -> size() ; i++)
		(* (cdPrivate -> vectorOfConcaveDistance))[i]->Delete();
	delete cdPrivate -> vectorOfConcaveDistance;
	

	for ( /*unsigned*/i = 0 ; i < (cdPrivate -> vectorOfMeshCol) -> size() ; i++)
		(* (cdPrivate -> vectorOfMeshCol))[i]->Delete();
	
	delete cdPrivate -> vectorOfMeshCol;

	for ( /*unsigned*/i = 0 ; i < (cdPrivate -> vectorOfDeformableMeshCol) -> size() ; i++)
		(* (cdPrivate -> vectorOfDeformableMeshCol))[i]->Delete();;
  
	delete cdPrivate -> vectorOfDeformableMeshCol;

	delete cdPrivate;
}
///Crea un Objeto de clase vtkDObject devolviendo el identificador del objeto
/// para localizarlo en el vector

//Creates an vtkDObject Object returning the id of the object to locate it in the vector
unsigned vtkColDetection::createObject(void)
{
  vtkIdType id = (this->cdPrivate -> vectorOfCDObjects) -> size();
  (cdPrivate -> vectorOfCDObjects) -> push_back(new vtkDObject);

  (* (cdPrivate -> vectorOfCDObjects))[id] -> state = NEWOBJECT;

  return static_cast<unsigned>(id);
}

void vtkColDetection::beginObject(unsigned id,
			       unsigned nbFacets,
			       unsigned nbVertexes)
{
  (* (cdPrivate -> vectorOfCDObjects))[id] -> beginObject(nbFacets,
							  nbVertexes);
  (* (cdPrivate -> vectorOfCDObjects))[id] -> state = ADD_TRIANGLE;
}

void vtkColDetection::SetVertexes(unsigned id,
			       double** Vertexes)
{
  (* (cdPrivate -> vectorOfCDObjects))[id] -> SetVertexes(Vertexes);
}

void vtkColDetection::SetVertexes(unsigned id,
			       double* Vertexes)
{
  (* (cdPrivate -> vectorOfCDObjects))[id] -> SetVertexes(Vertexes);
}

void vtkColDetection::GetVertexes(unsigned id, unsigned face, unsigned* Vertexes)
{
	((* (cdPrivate -> vectorOfCDObjects))[id] -> GetVertexes(face,Vertexes));
}

void vtkColDetection::CoordsVertexes(unsigned id, unsigned vertex, float* coord)
{
	((* (cdPrivate -> vectorOfCDObjects))[id] -> CoordsVertexes(vertex, coord));
}

void vtkColDetection::RelativeCoordsVertexes(unsigned id, unsigned vertex, float* coord){
	((* (cdPrivate -> vectorOfCDObjects))[id] -> RelativeCoordsVertexes(vertex, coord));
}//end RelativeCoordsVertexes
void vtkColDetection::addTriangle(unsigned id,
			       unsigned idFace,
			       const unsigned v1,
			       const unsigned v2,
			       const unsigned v3)
{
  (* (cdPrivate -> vectorOfCDObjects))[id] -> addTriangle(idFace, v1, v2, v3);
}

void vtkColDetection::endObject(unsigned id)
{
  (* (cdPrivate -> vectorOfCDObjects))[id] -> computeIntermediateStructure();
  (* (cdPrivate -> vectorOfCDObjects))[id] -> state = CREATED;
}

void vtkColDetection::SetTransformationMatrix(unsigned id, double* trans[16])
{
  (* (cdPrivate -> vectorOfCDObjects))[id] -> SetTransformationMatrix(trans);
}

unsigned vtkColDetection::DistanceConvex(unsigned id1, unsigned id2)
{
  SPY("Creating the object EnGJK");
  unsigned id = (cdPrivate -> vectorOfEnGJK) -> size();
  (cdPrivate -> vectorOfEnGJK) -> 
    push_back(new vtkEnGJK((* (cdPrivate -> vectorOfCDObjects))[id1],
			(* (cdPrivate -> vectorOfCDObjects))[id2]));
  SPY("Creation of the object EnGJK done.");
  return id;
}

double vtkColDetection::GetDistanceConvex(unsigned id)
{
  double res = (* (cdPrivate -> vectorOfEnGJK))[id] -> getDistance();
  SPY("Distance : " << res);
  return res;
}

void vtkColDetection::GetPointDistanceConvex(unsigned id,
					  double& xA, double& yA, double& zA,
					  double& xB, double& yB, double& zB)
{
  vtkVector3f* res = (* (cdPrivate -> vectorOfEnGJK))[id] -> getTabVectorRes();

  xA = res[0].x; yA = res[0].y; zA = res[0].z;
  xB = res[1].x; yB = res[1].y; zB = res[1].z;
}

unsigned vtkColDetection::DistanceConcave(unsigned id1, unsigned id2)
{
  SPY("Begin of ColDetection::DistanceConcave");
  SPY("Creating the Bounding Box id1");

  // Creating the Bounding Box id1
  new vtkBoundingBoxBinTree((* (cdPrivate -> vectorOfCDObjects))[id1] -> mesh);

  SPY("Creating the Bounding Box id2");

  // Creating the Bounding Box id2
  new vtkBoundingBoxBinTree((* (cdPrivate -> vectorOfCDObjects))[id2] -> mesh);

  SPY("Construction of the 2 BoundingBox done.");

  unsigned id = (cdPrivate -> vectorOfConcaveDistance) -> size();
  (cdPrivate -> vectorOfConcaveDistance) -> 
    push_back(new vtkConcaveDistance((* (cdPrivate -> vectorOfCDObjects))[id1],
				  (* (cdPrivate -> vectorOfCDObjects))[id2]));
  return id;
}

double vtkColDetection::GetDistanceConcave(unsigned id)
{
  double res = (* (cdPrivate -> vectorOfConcaveDistance))[id] -> getDistance();
  SPY("Distance : " << res);
  return res;
}

void vtkColDetection::GetPointDistanceConcave(unsigned id,
					   double& xA, double& yA, double& zA,
					   double& xB, double& yB, double& zB)
{
  vtkVector3f* res = 
    (* (cdPrivate -> vectorOfConcaveDistance))[id] -> getTabVectorRes();
  
  xA = res[0].x; yA = res[0].y; zA = res[0].z;
  xB = res[1].x; yB = res[1].y; zB = res[1].z;
}

unsigned vtkColDetection::Collide(unsigned id1, 
			       unsigned id2,
			       bool search)
{
  SPY("Begin of ColDetection::Collide");
 
  SPY("Creating the Bounding Box id1");

  // Creating the Bounding Box id1
  new vtkBoundingBoxBinTree((* (cdPrivate -> vectorOfCDObjects))[id1] -> mesh);

  SPY("Creating the Bounding Box id2");

  // Creating the Bounding Box id2
  new vtkBoundingBoxBinTree((* (cdPrivate -> vectorOfCDObjects))[id2] -> mesh);
  
  SPY("Construction of the 2 BoundingBox done.");

  unsigned id = (cdPrivate -> vectorOfMeshCol) -> size();
  (cdPrivate -> vectorOfMeshCol) -> 
    push_back(new vtkMeshCol((* (cdPrivate -> vectorOfCDObjects))[id1],
			  (* (cdPrivate -> vectorOfCDObjects))[id2],
			  search));
  return id;
}

bool vtkColDetection::VerifyCollision(unsigned id) 
{
  bool res = (* (cdPrivate -> vectorOfMeshCol))[id] -> VerifyCollision();

  if (res) {
    SPY("Collision +++");
  } else {
    SPY("Collision ---");
  }
  
  return res;
}

void vtkColDetection::ReportCollision(unsigned id, std::vector<unsigned>& contactSurfaceObject1, std::vector<unsigned>& contactSurfaceObject2, std::vector<NormalType>& normalObject1, std::vector<NormalType>& normalObject2)
{
	std::vector<CollisionPair> collisionInfo;
	(*(cdPrivate -> vectorOfMeshCol))[id] -> getCollisionInfo(collisionInfo);	

	NormalType n;
	unsigned i;
	for (i=0; i< collisionInfo.size(); i++)
	{
		contactSurfaceObject1.push_back(collisionInfo[i].F1);
		contactSurfaceObject2.push_back(collisionInfo[i].F2);
		n.normal.push_back(collisionInfo[i].P1.n.x);
		n.normal.push_back(collisionInfo[i].P1.n.y);
		n.normal.push_back(collisionInfo[i].P1.n.z);
		normalObject1.push_back(n);
		n.normal.clear();
		n.normal.push_back(collisionInfo[i].P2.n.x);
		n.normal.push_back(collisionInfo[i].P2.n.y);
		n.normal.push_back(collisionInfo[i].P2.n.z);
		normalObject2.push_back(n);
		n.normal.clear();
	}
}

void vtkColDetection::UpdateVertex(unsigned id,
				unsigned idVertex,
				double x,
				double y,
				double z)
{
  (* (cdPrivate -> vectorOfCDObjects))[id] -> UpdateVertex(idVertex, x, y, z);
}

void vtkColDetection::CreateBoundingBoxTree(unsigned id)
{
	new vtkBoundingBoxBinTree((* (cdPrivate -> vectorOfCDObjects))[id] -> mesh);
}

unsigned vtkColDetection::CollideDeformable(unsigned id1,
					 unsigned id2,
					 bool search)
{
//  vtkDebugMacro(<< "Begin of ColDetection::CollideDeformable");
 
//  vtkDebugMacro(<< "Creating the Bounding Box id1");
  

  // Creating the Bounding Box id1
//  new BoundingBoxBinTree((* (cdPrivate -> vectorOfCDObjects))[id1] -> mesh);

//  vtkDebugMacro(<< "Creating the Bounding Box id2");

  // Creating the Bounding Box id2
  //new BoundingBoxBinTree((* (cdPrivate -> vectorOfCDObjects))[id2] -> mesh);
  
//  vtkDebugMacro(<< "Construction of the 2 BoundingBox done.");

  unsigned id = (cdPrivate -> vectorOfDeformableMeshCol) -> size(); //El tama�o se correspondera con la colision actual
  (cdPrivate -> vectorOfDeformableMeshCol) -> 
    push_back(new vtkDeformableMeshCol((* (cdPrivate -> vectorOfCDObjects))[id1],
				    (* (cdPrivate -> vectorOfCDObjects))[id2],
				    search));
  return id;
}

bool vtkColDetection::VerifyCollisionDeformable(unsigned id)
{

  bool res = (* (cdPrivate -> vectorOfDeformableMeshCol))[id] -> VerifyCollision();
  // Code Only for Debug
/*
  if (res) {
	 //	FILE *fd;
	//	fd= fopen ("datos.txt", "a+");
	 // fprintf (fd, "verifica la colision \n");
	 // fclose (fd);
	//  SPY("Collision +++");
//    vtkDebugMacro(<< "Collision +++");
  } else {
	  FILE *fd;
		fd= fopen ("datos.txt", "a+");
	  fprintf (fd, "no hay colision \n");
	  fclose (fd);
	// SPY("Collision ---");
//    vtkDebugMacro(<< "Collision ---");
  }
 */ 
  return res;
}

void vtkColDetection::ReportCollisionDeformable(unsigned id,
					     std::vector<unsigned>& contactSurfaceObject1,
					     std::vector<unsigned>& contactSurfaceObject2)
{
  contactSurfaceObject1 = (* (cdPrivate -> vectorOfDeformableMeshCol))[id] -> CS1;
  contactSurfaceObject2 = (* (cdPrivate -> vectorOfDeformableMeshCol))[id] -> CS2;
}


void coord(const BoundingBoxTree* tree, std::vector<float*>& listVertices)
{
  if (tree == NULL) return;

  float* vert = new float[24];
  unsigned j = 0;

  for (unsigned i = 0 ; i < 8 ; i++) {
    vert[j++] = (tree -> node -> box -> Vertexes)[i].x;
    vert[j++] = (tree -> node -> box -> Vertexes)[i].y;
    vert[j++] = (tree -> node -> box -> Vertexes)[i].z;
  }
  listVertices.push_back(vert);
  
  coord(tree -> lson, listVertices);
  coord(tree -> rson, listVertices);
}

void vtkColDetection::GetBoundingBoxVertex(unsigned id,
					std::vector<float*>& listVertices)
{
  coord((* (cdPrivate -> vectorOfCDObjects))[id] -> 
	mesh -> getBoundingBoxTree(), listVertices);
}

/* ColDetection.cpp ends here */