/*
 ******************************************************************************
 * Title: ColDetection
 * Project: ColDetection Library
 ******************************************************************************
 * File: ColDetection.h
 * Author: Romain Rodriguez <Romain.Rodriguez@inrialpes.fr>
 * Created: 2003-01-06
 * Last update: 2003-05-20
 ******************************************************************************
 * Description: 
 * ColDetection header
 ******************************************************************************
 * Copyright (c) 2003, INRIA CYBERMOVE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************
 */

#ifndef __vtkColDetection_h
#define __vtkColDetection_h


// Comment this if you don't want to have some debug informations
#undef DEBUG
#define DEBUG

#ifdef _WIN32
#include <vector>
#else
#include <vector.h>
#endif

#include "tools.h" 
#include "Matrix4f.h" //definition of type only
#include "vtkDObject.h"
#include "vtkBoundingBoxBinTree.h"
#include "vtkMeshCol.h"
#include "vtkEnGJK.h"
#include "vtkConcaveDistance.h"
#include "vtkDeformableMeshCol.h"
#include "vtkObject.h"
#include "Macros.h"
#include "vtkesquiColDetectWin32Header.h"
#include "vtkColDetect.h"

//BTX
//#include "stdafx.h"
//! Estructura de datos que se se emplea en la detecciÃ³n de colisiones
//! Data structure used in the detection of collision
struct CDPrivate 
{
public:
  //! Vector de los objetos que se va a estudiar su colisiÃ³n
  //! Objects vector used to study the objects collision
  std::vector<vtkDObject *>* vectorOfCDObjects; 
  //! Vector de distancias utilizando el algortimo GJK.
  //! Vector of distances using the GJK algorithm
  std::vector<vtkEnGJK*>* vectorOfEnGJK;		 
  //! Vector de las distancias para objetos concavos
  //! Vector of the distances for concave objects
  std::vector<vtkConcaveDistance*>* vectorOfConcaveDistance; 
  //! Vector de colisiones entre modelos
  //! Vector of collisions between models
  std::vector<vtkMeshCol*>* vectorOfMeshCol;	
  //! vector de colisiones entre modelos deformables
  //! Vector of collisions between deformable models
  std::vector<vtkDeformableMeshCol*>* vectorOfDeformableMeshCol; 
};

typedef struct{
	
	std::vector<float> normal;

}NormalType;
//ETX
//! Class for collision detection
class VTK_ESQUI_COLDETECT_EXPORT vtkColDetection//: public vtkColDetect
	//: public vtkObject
{

public:

  static vtkColDetection *New() {return new vtkColDetection;};
  const char *GetClassName() {return "vtkColDetection";};
  
  //! Constructor
  vtkColDetection(void);

  //! Destructor
  ~vtkColDetection(void);


  // ==========================================================================
  //! Objects Definition

  //! Create a new object whith the identifier id.
//BTX
  unsigned createObject();
//ETX
  //! Begin of the construction of the geometry of the object id
  /*! The Object id has nbFacets facets and nbVertexes Vertexes
	  Funcion para reopresentar los modelos dentro de la libreria. En este caso le das
	  el nmero de caras que tiene la malla (son triangulares) y el nmero de Vertexes
  */ 

  void beginObject(unsigned id,
		   unsigned nbFacets,
		   unsigned nbVertexes);

  //! Set the table of Vertexes
  /*! Ith vertex  = (vertex.x      , vertex.y      , vertex.z      )
      Vertexes[i] = (Vertexes[i][0], Vertexes[i][1], Vertexes[i][2])
      le das la informaciï¿½ de la geometrï¿½ de los modelos
  */
  void SetVertexes(unsigned id,
		   double** Vertexes);
  
  //! Set the table of Vertexes
  
  /*! Ith vertex  = (vertex.x      , vertex.y      , vertex.z      )
      Vertexes[i] = (v1.x, v1.y, v1.z, v2.x, v2.y, v2.z)
       Modificacion para optimizar la utilizacion de la libreria
       pasando directamente un vector que es como se utiliza 
       tanto en nuestro simulador como en el objeto CDObject
	*/
  void SetVertexes(unsigned id,
	  double* Vertexes);
//BTX
	//! Returns verts of facet
	void GetVertexes(unsigned id, unsigned face, unsigned* Vertexes);
//ETX	
	//! Retruns the coords of a vert
	void CoordsVertexes(unsigned id, unsigned vertex, float* coord);	

	//! Returns relative coords of a vert
	void RelativeCoordsVertexes(unsigned id, unsigned vertex, float* coord);


  //! Add a triangle to the object id
  /*!
     This triangle is the idFace triangle and componed of the Vertexes
     v1, v2, v3
  */  
  //le das la informaciï¿½ topolï¿½ica de los modelos, debemos saber el indetificador del la cara
  // y el identificadro de cada uno de los vï¿½tices.
  
  void addTriangle(unsigned id,
		   unsigned idFace,
		   const unsigned v1,
		   const unsigned v2,
		   const unsigned v3);
  
  //! End of the construction of the geometry of the object id
  // Cuando finalices de defunir un modelo debes ejecutar esta funciï¿½.
  void endObject(unsigned id);

  // ==========================================================================
  //! Set the transformation matrix of the object
  
  /*!
   4x4 matrices
  
   Transformation matrix is in column major order and used to multiply
   column vector on the left as in OpenGL (ie  v' = M.v).
   Coordinate system and rotations are assumed to be right-handed.
   
        x   y   z   w           x   y   z   w
      ---------------         ---------------
    x | 0   4   8  12       x | r.s r.s r.s t
    y | 1   5   9  13       y | r.s r.s r.s t  (for affine transformations)
    z | 2   6  10  14       z | r.s r.s r.s t
    w | 3   7  11  15       w | 0   0   0   1
   
   element (i,j) (raw i, column j) of matrix M is accessed by M[4*j+i]
   The second figure is for transformation matrices. It implies that
   M = T.R.S, i.e scaling is applied first, then rotation and last
   translation.
  */
  void SetTransformationMatrix(unsigned id, 
			       double* trans[16]);
  
  // ==========================================================================
  // Operation on objects

  // ==========================================================================
  //! Computing Distance between Convex Objects
  /*!
     Compute the distance between the convex objects id1 and id2
     Return the identifier of the interaction between the two objects
  */
  // el parï¿½etro de salida es un identificador de la interacciï¿½.Este identificador
  // es el empleado para calcular la distancia exacta mediante la funciï¿½ GetDistanceConvex y la
  // funciï¿½ de obtener los puntos de cada objeto que tienen la disancia mï¿½ima. Supongo que 
  // xA,xB y xC son las coordenadas de los puntos del objeto id1 y xB,yB y zB es son las coordenadas
  // del punto de id2 mï¿½ cercano a id1.
  //BTX 
  unsigned DistanceConvex(unsigned id1,
			  unsigned id2);
  //ETX
  //! Get the distance between the two convex of DistanceConvex id is the identifier of the interaction 
  double GetDistanceConvex(unsigned id);

  //! Get the coordinates of the points that realize the distance between the 2 convex objects
  /*! 
     \param id Is the identifier of the interaction
  */
  void GetPointDistanceConvex(unsigned id,
			      double& xA, double& yA, double& zA,
			      double& xB, double& yB, double& zB);

  // ==========================================================================
  //! Computing Distance between Convex Objects
  /*!
     Compute the distance between the concave objects id1 and id2
     Return the identifier of the interaction between the two objects
  */
  //BTX
  unsigned DistanceConcave(unsigned id1, 
			   unsigned id2);
  //ETX
  //! Get the distance between the two concave of DistanceConcave
  /*!
	\param id is the identifier of the interaction
  */
  double GetDistanceConcave(unsigned id);
  
  //! Get the coordinates of the points that realize the distance between the 2 convex objects
    /*!
	\param id is the identifier of the interaction
  */
  void GetPointDistanceConcave(unsigned id,
			       double& xA, double& yA, double& zA,
			       double& xB, double& yB, double& zB);

  // ==========================================================================
  //! Collision Detection between 2 objects
  /*
     Perform the collision detection the objects id1 and id2
     Return the identifier of the interaction between the two objects
     Set search to true if you want to search for the contact surface
  */
  //BTX
  unsigned Collide(unsigned id1,
		   unsigned id2,
		   bool search);
  //ETX
  //! Verify the collision between the objects of collide(...)
  /*!
	\param Id is the identifier of the interaction
  */
  
  bool VerifyCollision(unsigned id);
  
  //! Report the results of collision detection
  /*!
	To have these informations you have to set search to true
	\param Id is the identifier of the interaction
	\param contactSurface is a vector of index of facets in the contact surface
  */
  //BTX
  void ReportCollision(unsigned id,
		       std::vector<unsigned>& contactSurfaceObject1,
		       std::vector<unsigned>& contactSurfaceObject2,
					 std::vector<NormalType>& normalObject1,
					 std::vector<NormalType>& normalObject2);
//ETX
  // ==========================================================================
  // Collision Detection between 2 deformable objects

  //! Update the coordinates of the vertex idVertex of the object id
  void UpdateVertex(unsigned id,
		    unsigned idVertex,
		    double x,
		    double y,
		    double z);
  
  //! Perform the collision detection the deformable objects id1 and id2
  
  /*! Return the identifier of the interaction between the two objects
      Set search to true if you want to search for the contact surface
  */
  //BTX
  unsigned CollideDeformable(unsigned id1,
			     unsigned id2,
			     bool search);
  //ETX
  void	CreateBoundingBoxTree(unsigned id);
  //! Verify the collision between the deformable objects of collide(...)
  /*! 
	\param Id is the identifier of the interaction
  */
  bool VerifyCollisionDeformable(unsigned id);

  //! Report the results of collision detection between the deformable objects. 
  /*! 
	To have these informations you have to set search to true
	\param Id is the identifier of the interaction
	\param contactSurface is a vector of index of facets in the contact surface
  */
  //BTX
  void ReportCollisionDeformable(unsigned id,
	  std::vector<unsigned>& contactSurfaceObject1,
	  std::vector<unsigned>& contactSurfaceObject2);
  // ==========================================================================
  // Debug and Render Tools

  //! Get the list of Vertexes of the bounding box tree for the object
  /*! 
	\param id Each element of listVertices constains the 24 float that represent each vertex of each bounding box.
  */
  void GetBoundingBoxVertex(unsigned id, std::vector<float*>& listVertices);
  //ETX
  virtual double* ObtainMatrix(unsigned id){
	return NULL;	  
  };
protected:
  CDPrivate* cdPrivate;
  
private:
	bool Debug;
	vtkColDetection(const vtkColDetection &);
	void operator =(const vtkColDetection &);
};

#endif /* ifndef COLDETECTION_H */

/* ColDetection.h ends here */

