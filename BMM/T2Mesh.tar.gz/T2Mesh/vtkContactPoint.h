
#if !defined(AFX_CONTACT_H__91A10633_2D80_11D4_A2B7_006097B4FCF5__INCLUDED_)
#define AFX_CONTACT_H__91A10633_2D80_11D4_A2B7_006097B4FCF5__INCLUDED_

#if( _MSC_VER > 1000 )
	#pragma once
#endif

#include "vtkBESSMat.h"
#include "vtkObject.h"
#include "vtkesquiT2MeshWin32Header.h"
#include "Macros.h"
class vtkOrgan;
class vtkContactPoint;

#ifndef UINT_MAX
#define UINT_MAX      0xffffffff
#endif
//! Class to manage the contacts
class VTK_ESQUI_T2MESH_EXPORT vtkContactPoint: public vtkObject  
{

//***** c o n s t r u c t o r s   /   d e s t r u c t o r

public:

	vtkTypeRevisionMacro(vtkContactPoint,vtkObject);
	static vtkContactPoint *New();
	const char *GetClassName() {return "vtkContactPoint";}
	void PrintSelf(ostream& os, vtkIndent indent);
	//! Initialize member variables and inform vtkOrgan about new contact;
	vtkContactPoint(double afGlobalCoord[],double afRestMov[],vtkOrgan* pOrgan, const UINT uElement, UINT nVertex,const UINT uContactID);

	//! Inform both tool point and organ of the lost contact
	~vtkContactPoint();


//***** c o m m o n   m e m b e r s

	void SetTool(int IdTool) {this->Tool = IdTool;}
	int GetTool() {return this->Tool;}
	//! Inquire the contact point's current global coord., which equal the tool point's position	
	float GetCoordX() const  { return m_afCoord[0]; }
	//! Inquire the contact point's current global coord., which equal the tool point's position
	float GetCoordY() const  { return m_afCoord[1]; }
	//! Inquire the contact point's current global coord., which equal the tool point's position
	float GetCoordZ() const  { return m_afCoord[2]; }

	//! Inquire the local coordinates of the contact point within the contact element;
	/*! 
		BEM: return the local coordinates within the (first) parent element
	*/
	float GetCoordXi0() const  { return m_afLocalCoord[0]; }
	//! Inquire the local coordinates of the contact point within the contact element;
	/*! 
		BEM: return the local coordinates within the (first) parent element
	*/
	float GetCoordXi1() const  { return m_afLocalCoord[1]; }
	//! Inquire the local coordinates of the contact point within the contact element;
	/*! 
		BEM: return the local coordinates within the (first) parent element
	*/
	float GetCoordXi2() const  { return m_afLocalCoord[2]; }

	//! Inquire the organ's element 
	/*!	
		Inquire the organ's element within which the contact has been established (T2) or the
		(first) parent element of the one within which the contact has been established (BEM)
	*/
	UINT GetElement() const  { assert( m_uElement != UINT_INVALID );  return m_uElement; }

	UINT GetNumVertex(){return m_nVertex; }

	//! Obtain a pointer to the current force fed back at the contact point
	void GetForceFeedback( float afForceFeedback[] ) const
	{
		afForceFeedback[0] = m_afForceFeedback[0];
		afForceFeedback[1] = m_afForceFeedback[1];
		afForceFeedback[2] = m_afForceFeedback[2];
	}

	//! Obtain coords
	/*!	
		Obtain both the organ's element within which the contact has been established and its
	    position in local coordinates within this element (T2), or the (first) parent element
	    of the one within which the contact has been established and its position in local
	    coordinates with respect to the prior (BEM)
	*/
	void GetLocalPoint( UINT& c_uEl, float c_afLocalCoord[] ) const
	{
		c_uEl = m_uElement;
		c_afLocalCoord[0] = m_afLocalCoord[0];
		c_afLocalCoord[1] = m_afLocalCoord[1];
		c_afLocalCoord[2] = m_afLocalCoord[2];
	}

	//! Pointer to the involved organ
	vtkOrgan* GetOrgan() const  { /*assert( m_pOrgan != NULL );*/  return m_pOrgan; }

	//! Inquire normal of collisioned polygon
	void GetPolygonNormal( float afNormal[3] )  { /*WTp3_copy( m_afNormal,afNormal ); */};

	//! Inquire pull permit (forceps only)
	bool GetPullPermit() const  { return m_bPullPermit; }

	//! Set pull permit (forceps only)
	void SetPullPermit( const bool bPermit )  { m_bPullPermit = bPermit; }

	//! Methods for set and inquire de exact position of a contact on the collision ray
	void  SetPositionOnRay(float fPos){ m_fPosOnRay=fPos; }
	//! Methods for set and inquire de exact position of a contact on the collision ray
	float GetPositionOnRay() const { return m_fPosOnRay; }

	void GetRestMov(float afRestMov[] ) const
	{
		afRestMov[0]=m_afRestMov[0];
		afRestMov[1]=m_afRestMov[1];
		afRestMov[2]=m_afRestMov[2];
	}

private:

	//! Organ and tool edge involved in contact
	vtkOrgan*	   m_pOrgan;

	//! Contact point's relative position, i.e. element and position in local coordinates within this element
	/*!
		 T2:  element within which the contact has been established;
		 BEM: parent element of the one whithin which the contact has been established
	*/
	//BTX
	UINT  m_uElement;
	UINT  m_nVertex;		// Vertice de contacto
	//ETX
	int Tool;
	float m_afLocalCoord[3];
	float m_afRestMov[3];

	//! Contact ID for vtkToolPoint
	//BTX
	UINT  m_uContactID;
	
	//! Normal of element within which the contact has originally been established
	float m_afNormal[3];

	//! Contact's current global position and force feedback
	float m_afCoord[3], m_afForceFeedback[3];

	//! Flag to indicate if tool can pull on organ (forceps etc.)
	bool m_bPullPermit;
	//ETX
	// Value that indicates the exact possition of contact on the collision ray,
	// necessary to estimate force in the haptic.
	float m_fPosOnRay;

	// Indica si hay una captura total
	//! Indicates if there is a total capture
	bool m_bTotalCapture;

//***** T 2 M e s h - s p e c i f i c   m e m b e r s

public:

	//! Set the contact point's force feedback by informing the respective tool
	void ForceUpdate( float afForceFeedback[] )
	{
		m_afForceFeedback[0] = afForceFeedback[0];
		m_afForceFeedback[1] = afForceFeedback[1];
		m_afForceFeedback[2] = afForceFeedback[2];		
	}

	//! Get a point which is used to determine the ubication of the contact point with respect to the element (inside / outside)   
	void GetReferencePoint( float afPoint[] ) const  { /*m_pToolEdge->obtenerIniGlobal(afPoint);*/};

	//! Inquire the shift flag
	bool GetShiftValue() const  { return m_bShift; }

	//! Set the contact point's current global coord., which equal the tool point's position
	void SetCoord( float afCoord[] )
	{
		m_afCoord[0] = afCoord[0];
		m_afCoord[1] = afCoord[1];
		m_afCoord[2] = afCoord[2];
	}

	//! Set the shift flag
	void SetShiftValue( bool bValue )  { m_bShift=bValue; }

	void SetTotalCapture(bool bValue) { m_bTotalCapture=bValue;}

	bool GetTotalCapture() { return m_bTotalCapture;}

private:

	//! Flag to indicate if contact can shift the organ's surface
	bool m_bShift;

	vtkContactPoint(const vtkContactPoint &);
	void operator =(const vtkContactPoint &);

protected:
		vtkContactPoint() {};

};  // class vtkContactPoint


#endif 
