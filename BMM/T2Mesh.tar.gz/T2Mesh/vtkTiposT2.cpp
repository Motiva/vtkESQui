/*
--------------------
Program: ESQUI
Info and Bugs: {marf,rsantana}@ctm.ulpgc.es 
-------------------------------------------

Copyright (c) 2006, Center for Technology in Medicine, University of Las Palmas
de Gran Canaria (Canary Islands, Spain).
All rights reserved.

This program is free software; you can redistribute it and/or modify it under 
the terms of the Creative Commons' "by-attribution" license 
(http://creativecommons.org/licenses/by/2.5).

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1) Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright 
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
=============================================================================*/
/////////////////////////////////////////////////////////////////////////////////
// Este fichero contiene la implementacion de los metodos de las clases auxiliares
// usadas por la clase principla vtkT2Mesh

#include "vtkTiposT2.h"
#include "vtkT2Mesh.h"
#include "vtkObjectFactory.h"

///////////////////////////////////////////////////////////////////////////////////
// Datos de los nodos de la malla T2

void vtkNodeT2::operator=(vtkNodeT2& node){
	int i;

	m_PointT2=node.ObtainPoint();
	m_PointT2Prev=node.ObtainPreviousPoint();
	for (i=0;i<3;i++){
		m_anConect[i]=node.ObtainConnection(i);
		m_anTypeConect[i]=node.ObtainTypeConnection(i);
		m_aSpins[i]=node.ObtainSpin(i);
	}
	m_anTypePoint=node.ObtainTypePoint();
	m_anStatePoint=node.ObtainStatePoint();
}
//metodos para control de vtk en la clase vtkFace
vtkCxxRevisionMacro(vtkWay, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkWay);
///////////////////////////////////////////////////////////////////////////////////
// metodos de la clase que permite restaurar informacion de la T2 incluyendo
// informacion de sobre la composicion de las caras
#include "vtkEsquiFaceCollection.h"
vtkCxxRevisionMacro(vtkDataT2Mesh, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkDataT2Mesh);

vtkDataT2Mesh::~vtkDataT2Mesh(){
	if (m_bLiberateMemory)
		LiberateMemory();
}

vtkDataT2Mesh::vtkDataT2Mesh(){
	m_pCopyPointsT2=NULL;
	m_pCopyTextureT2 = NULL;
	m_pCopyPreviousPointT2=NULL;
	m_panCopyConect=NULL;
	m_panCopyTypeConect=NULL;
	m_panCopyAdjacents=NULL;
	m_pnCopyPointType=NULL;
	m_pnCopyStatePoint=NULL;
	m_pCopyNormals=NULL;
	m_pCopyFaces=vtkEsquiFaceCollection::New();
	m_pCopySpins=NULL;
	m_pbCopyInestable=NULL;
	m_bLiberateMemory=false;
	m_bValidMemory=false;
}

void vtkDataT2Mesh::LiberateMemory(){
	if(m_pCopyPointsT2)
		delete[] m_pCopyPointsT2;
	if(m_pCopyTextureT2)
		delete[] m_pCopyTextureT2;
	if(m_pCopyPreviousPointT2)
		delete[] m_pCopyPreviousPointT2;
	if(m_panCopyConect)
		delete[] m_panCopyConect;
	if(m_panCopyTypeConect)
		delete[] m_panCopyTypeConect;
	if(m_panCopyAdjacents)
		delete[] m_panCopyAdjacents;
	if(m_pnCopyPointType)
		delete[] m_pnCopyPointType;
	if(m_pnCopyStatePoint)
		delete[] m_pnCopyStatePoint;
	if(m_pCopyNormals)
		delete[] m_pCopyNormals;
	if(m_pCopyFaces)
		m_pCopyFaces->DeleteAll();
		m_pCopyFaces->Delete();
	if(m_pCopySpins)
		delete[] m_pCopySpins;
	if(m_pbCopyInestable)
		delete[] m_pbCopyInestable;
}



void vtkDataT2Mesh::MakeSegurityCopy(vtkT2Mesh* pFont){

	int i,k;

	m_nCopyNumPointsT2 = pFont->m_nNumPointsT2;
	m_pCopyPointsT2 = new Point[m_nCopyNumPointsT2];
	m_pCopyTextureT2 = new Point[m_nCopyNumPointsT2];
	m_pCopyPreviousPointT2 = new Point[m_nCopyNumPointsT2];
	m_panCopyConect = new INT3[m_nCopyNumPointsT2];
	m_panCopyTypeConect = new INT3[m_nCopyNumPointsT2];
	m_pnCopyPointType = new int[m_nCopyNumPointsT2];
	m_pnCopyStatePoint = new int[m_nCopyNumPointsT2];
	m_pbCopyInestable = new bool[m_nCopyNumPointsT2];
	m_pCopySpins = new POINT3[m_nCopyNumPointsT2];
	m_pCopyNormals = new Point[m_nCopyNumPointsT2];
	m_panCopyAdjacents = new INT3[m_nCopyNumPointsT2];
	m_pCopyFaces->CreateNodes( pFont->m_nNumFaces);
	m_nCopyNumFaces = pFont->m_nNumFaces;

	for(i = 0; i < m_nCopyNumPointsT2; i++){
		m_pCopyPointsT2[i] = pFont->m_pPointsT2[i];
		m_pCopyTextureT2[i] = pFont->m_pTextureT2[i];
		m_pCopyPreviousPointT2[i] = pFont->m_pPrevPointT2[i];
		m_pnCopyPointType[i] = pFont->m_pnPointType[i];
		m_pnCopyStatePoint[i] = pFont->m_pnPointState[i];
		m_pbCopyInestable[i] = pFont->m_pbUnstable[i];
		m_pCopyNormals[i] = pFont->m_pNormals[i];
		for(k = 0; k < 3; k++){
			m_pCopySpins[i][k] = pFont->m_paSpins[i][k];
			m_panCopyTypeConect[i][k] = pFont->m_panConectionType[i][k];
			m_panCopyConect[i][k] = pFont->m_panConect[i][k];
			m_panCopyAdjacents[i][k] = pFont->m_panAdjacentFaces[i][k];
		}
	}
	for(i = 0; i < m_nCopyNumFaces; i++){
		m_pCopyFaces->Item(i)->numVertex = 0;
		for(k = 0; k < pFont->m_pFaces->Item(i)->numVertex; k++)
			m_pCopyFaces->Item(i)->AddVertex((*pFont->m_pFaces->Item(i))[k]);
	}
	m_bLiberateMemory=true;	
	m_bValidMemory=true;
}

void vtkDataT2Mesh::Restore(vtkT2Mesh* pAssing){

	if (m_bValidMemory){
		pAssing->m_nNumPointsT2 = m_nCopyNumPointsT2;
		pAssing->m_pPointsT2 =  m_pCopyPointsT2; 
		pAssing->m_pTextureT2 = m_pCopyTextureT2;
		pAssing->m_pPrevPointT2 = m_pCopyPreviousPointT2; 
		pAssing->m_panConect = m_panCopyConect;
		pAssing->m_panConectionType = m_panCopyTypeConect; 
		pAssing->m_panAdjacentFaces = m_panCopyAdjacents; 
		pAssing->m_pnPointType = m_pnCopyPointType;
		pAssing->m_pnPointState = m_pnCopyStatePoint; 
		pAssing->m_pbUnstable = m_pbCopyInestable;
		pAssing->m_pNormals = m_pCopyNormals; 
		pAssing->m_pFaces = m_pCopyFaces; 
		pAssing->m_nNumFaces = m_nCopyNumFaces;
		pAssing->m_paSpins = m_pCopySpins;
		m_bLiberateMemory=false;                     
	}
}
