
#ifndef _CCARAS
#define _CCARAS

#include "vtkAlgebra.h"
#include "vtkObject.h"
#include "vtkBESSMat.h"
#include "Macros.h"
#include "vtkesquiT2MeshWin32Header.h"

//Valores mÃ¡ximos
#define NLIGTHS 8
#define NFORCEPOINTS 16

class vtkFace;
// Clase que implementa las caras de la T2-mesh.
/*
	 Esta clase implementa una cara de la malla T2. Sus componentes son punteros a la	   
	 lista de vertices de la malla T2, y ademas se ordenan en sentido antihorario.	   
	 El ultimo vertice es igual que el primero, para facilitar posteriormente el dibujo  
	 de la cara y el calculo de la malla triangular dual.
*/
//! Implements the T2-Mesh faces.
/*! 
	This class implements a T2 Mess's face. Its components are pointer to the lists of vertex of the T2 Mesh.
	These vertex are stored in antihourly form. The last vertex is the same as the first in order to facilitate 
	the print of the face and the dual triangular mess calculation
*/
class VTK_ESQUI_T2MESH_EXPORT vtkFace: public vtkObject 

{
public:
	vtkTypeRevisionMacro(vtkFace,vtkObject);
	static vtkFace *New();
	const char *GetClassName() {return "vtkFace";}

	int numVertex;
	int *Vertexes;
	// Constructor por defecto.
	//! Defect constructor
	vtkFace();
	~vtkFace();
	// Agnade un vertice a la cara.	
	//! Add a vertex to the face
	void AddVertex(int p);
	// Retorna el vÃ©rtice i de la cara.	
	//! Return the "i" vertex of the face
	int operator [](int i); 
	// Retorna la normal de la cara.	
	//! Return the face's normal
	Point normal(Point *puntost2);
	// Asigna caras.	
	//! Assing faces
	vtkFace operator =(const vtkFace &);
	// ¿Contiene la cara el puntot2[p] en sus vertices?	
	//! Does the face contains the "p" point?
	BOOL Contains(int p); 
	// ¿Pertenece el punto p a la cara?	
	//! Does the "p" point belong to the face?
	BOOL dentroproy(Point p, Point *puntost2);
	// Obtiene el indice del vertice con coordenadas p	
	//! Obtains the index of the vertex given by the "p" coordinates
	int Index(Point p, Point *puntost2); 
	// Halla el centroide de los puntos que forman la cara	
	//! Obtain the center of the points that compose the face
	Point Center(Point * puntost2); 
		

private:
	vtkFace(const vtkFace &){};
};


#endif
