
#ifndef __vtkModeloDeformableC_h
#define __vtkModeloDeformableC_h

#include "vtkCollection.h"
#include "Macros.h"
#include "vtkesquiT2MeshWin32Header.h"
class vtkDeformableModel;
//! vtkDeformableModelCollection a list of model collision of deformable organs
/*!
	 vtkDeformableModelCollection represents and provides methods to manipulate a list of
	 vtkDeformableModel (i.e., vtkTool and subclasses). The list is unsorted and duplicate
	 entries are not prevented.
*/
class VTK_ESQUI_T2MESH_EXPORT vtkDeformableModelCollection : public vtkCollection
{
 public:
	 static vtkDeformableModelCollection *New();
  vtkTypeRevisionMacro(vtkDeformableModelCollection,vtkCollection);
  virtual void PrintSelf(ostream& os, vtkIndent indent);

  //! Add a item to the list.
  void InsertOrgan(vtkDeformableModel *a);
  //! Get the item i in the list. 
  vtkDeformableModel *GetModelOnPosition(int i);

protected:
//   vtkIdType NumeroDeHerramientas;
  vtkDeformableModelCollection() {};
  ~vtkDeformableModelCollection() {};


private:
  //! Hide the standard AddItem from the user and the compiler.
  void AddItem(vtkObject *o) { this->vtkCollection::AddItem(o); }

private:
  vtkDeformableModelCollection(const vtkDeformableModelCollection&);  // Not implemented.
  void operator=(const vtkDeformableModelCollection&);					// Not implemented.
};


#endif
