#ifndef __vtkEsquiCaraCollection_h
#define __vtkEsquiCaraCollection_h

#include "vtkEsquiCollection.h"


#include "vtkesquiT2MeshWin32Header.h"
class vtkFace;

//!  A list of vtkCaras
/*! 
   vtkEsquiFaceCollection represents and provides methods to manipulate a list of
   Caras (i.e., vtkCaras and subclasses). The list is unsorted and duplicate
   entries are not prevented.

   \sa vtkCollection, vtkFace
*/
class VTK_ESQUI_T2MESH_EXPORT vtkEsquiFaceCollection: public vtkEsquiCollection
{
 public:
  static vtkEsquiFaceCollection *New();
  vtkTypeRevisionMacro(vtkEsquiFaceCollection,vtkEsquiCollection);
  virtual void PrintSelf(ostream& os, vtkIndent indent);

  // Description:
  //! Add a face to the list.
  vtkIdType Append(vtkFace *object);
  //! Returns the Cara on i position.
  vtkFace *Item(vtkIdType i);
  //! Returns the first Cara.
  vtkFace *GetFirst();
  //! Returns the position of cara.
  vtkIdType Find(vtkFace *object);
  //! Returns the position of cara.
  vtkIdType IndexOf(vtkFace *object);
  //! Returns the next item in the list
  vtkFace *GetNextItem();
  //! Delete all the items in the list.(The items no longer exist)
  void DeleteAll();
  //! Create a specified number of nodes in the list
  void CreateNodes(int numNodes);

protected:
  vtkEsquiFaceCollection() {};
  ~vtkEsquiFaceCollection() {};

private:
  vtkEsquiFaceCollection(const vtkEsquiFaceCollection&);  // Not implemented.
  void operator=(const vtkEsquiFaceCollection&);		  // Not implemented.
};


#endif
