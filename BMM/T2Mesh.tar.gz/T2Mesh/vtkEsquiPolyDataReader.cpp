#include "vtkEsquiPolyDataReader.h"
#include "vtkEsquiPolyData.h"
#include "vtkObjectFactory.h"
#include "vtkPolyDataNormals.h"
#include "vtkT2Mesh.h"
#include "vtkCellArray.h"
#include "vtkFloatArray.h"
#include "vtkPointData.h"


vtkCxxRevisionMacro(vtkEsquiPolyDataReader, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkEsquiPolyDataReader);

void vtkEsquiPolyDataReader::SetName(char *Name) {
	this->Name = Name;
}
const char* vtkEsquiPolyDataReader::GetName() {
	return this->Name;
}

vtkT2Mesh* vtkEsquiPolyDataReader::GetOrgan() {
	vtkPolyDataNormals *NormalsOfInput = vtkPolyDataNormals::New();
	NormalsOfInput->SetInput(this->GetOutput());
	NormalsOfInput->Update();
	vtkT2Mesh* Salida= vtkT2Mesh::New();

	vtkCellArray* Polys = vtkCellArray::New();
		Polys->DeepCopy(NormalsOfInput->GetOutput()->GetPolys());
		Salida->vtkPolyData::SetPolys(Polys);

	vtkPoints *Puntos = vtkPoints::New();
		Puntos->DeepCopy(NormalsOfInput->GetOutput()->GetPoints());
		Salida->vtkPolyData::SetPoints(Puntos);

	vtkFloatArray *Texturas = vtkFloatArray::New();
		Texturas->DeepCopy(NormalsOfInput->GetOutput()->GetPointData()->GetTCoords());
		Salida ->GetPointData()->SetTCoords(Texturas);
		//Salida->vtkPolyData::GetPointData()->SetTCoords(Texturas);

	vtkFloatArray *Normales = vtkFloatArray::New();
		Normales->DeepCopy(NormalsOfInput->GetOutput()->GetPointData()->GetNormals());
		Salida->vtkPolyData::GetPointData()->SetNormals(Normales);


	return Salida;

}
void vtkEsquiPolyDataReader::PrintSelf(ostream &os, vtkIndent indent) {
	this->Superclass::PrintSelf(os,indent);
}
