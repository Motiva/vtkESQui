#include "vtkDeformableModelCollection.h"

#include "vtkObjectFactory.h"
#include "vtkDeformableModel.h"

#include <math.h>

vtkCxxRevisionMacro(vtkDeformableModelCollection, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkDeformableModelCollection);

void vtkDeformableModelCollection::InsertOrgan(vtkDeformableModel *a) {
	this->vtkCollection::AddItem((vtkObject *) a);
}

vtkDeformableModel* vtkDeformableModelCollection::GetModelOnPosition(int i) {
	return static_cast <vtkDeformableModel *>(this->GetItemAsObject(i));
}

//----------------------------------------------------------------------------
void vtkDeformableModelCollection::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
}
