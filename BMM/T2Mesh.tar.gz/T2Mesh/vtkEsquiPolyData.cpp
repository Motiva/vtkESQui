/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkEsquiPolyData.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
#include "vtkEsquiPolyData.h"
#include "vtkPointData.h"
#include "vtkObjectFactory.h"
#include "vtkDataArray.h"
#include <float.h>

 #include <math.h>

vtkCxxRevisionMacro(vtkEsquiPolyData, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkEsquiPolyData);

void vtkEsquiPolyData::coordTexturaVertPoligono(vtkIdType i,vtkIdType Component,float* uv) {
	vtkIdType IdVertice;
	IdVertice= idPolygonVertex(i, Component);
	*uv = (float) this->GetPointData()->GetTCoords()->GetComponent(IdVertice,Component);
}

void vtkEsquiPolyData::modificaGeometria() {
	
		int u;
	
		float vertice1[3],vertice2[3],vertice3[3];	
	
		float* pNormals = new float[3*this->GetNumberOfPoints()];
		float vect1[3];
		float vect2[3];
		float normal[3];
		vtkIdType v1,v2,v3;

		memset(pNormals,0,this->GetNumberOfPoints()*sizeof(float)*3);

		for( u = 0;  u < this->GetNumberOfPolys();  u ++ )
		{
		
			v1= this->GetCell(u)->GetPointIds()->GetId(0);
			v2= this->GetCell(u)->GetPointIds()->GetId(1);
			v3= this->GetCell(u)->GetPointIds()->GetId(2);

			vertice1[0] = this->m_afCurrentCoord[v1*3];
			vertice1[1] = this->m_afCurrentCoord[v1*3+1];
			vertice1[2] = this->m_afCurrentCoord[v1*3+2];

			vertice2[0] = this->m_afCurrentCoord[v2*3];
			vertice2[1] = this->m_afCurrentCoord[v2*3+1];
			vertice2[2] = this->m_afCurrentCoord[v2*3+2];

			vertice3[0] = this->m_afCurrentCoord[v3*3];
			vertice3[1] = this->m_afCurrentCoord[v3*3+1];
			vertice3[2] = this->m_afCurrentCoord[v3*3+2];

			/// Calculo la normal de esta cara y la aÃ±ado a las normales de los vÃ©rtices..
			vect1[0] = vertice2[0] - vertice1[0];
			vect1[1] = vertice2[1] - vertice1[1];
			vect1[2] = vertice2[2] - vertice1[2];
			vect2[0] = vertice3[0] - vertice1[0];
			vect2[1] = vertice3[1] - vertice1[1];
			vect2[2] = vertice3[2] - vertice1[2];

			normal[0] = (vect1[1]*vect2[2]) - (vect1[2]*vect2[1]);
			normal[1] = (vect1[2]*vect2[0]) - (vect1[0]*vect2[2]);
			normal[2] = (vect1[0]*vect2[1]) - (vect1[1]*vect2[0]);
					
			pNormals[v1*3]   += normal[0];
			pNormals[v1*3+1] += normal[1];
			pNormals[v1*3+2] += normal[2];
			pNormals[v2*3]   += normal[0];
			pNormals[v2*3+1] += normal[1];
			pNormals[v2*3+2] += normal[2];
			pNormals[v3*3]   += normal[0];
			pNormals[v3*3+1] += normal[1];
			pNormals[v3*3+2] += normal[2];

		//	poligono = WTpoly_next(poligono);

		}

		// Normalizar y Actualizar
		vtkPoints* vertice = this->GetPoints();
		float longitud;
		float x,y,z;
			
		for(u = 0;  u < this->GetNumberOfPoints();  u ++ )
		{
			x = pNormals[u*3];
			y = pNormals[u*3+1];
			z = pNormals[u*3+2];
			longitud = 1.0f / ( sqrt(x*x + y*y + z*z) + FLT_EPSILON );
			pNormals[u*3] *= longitud;
			pNormals[u*3+1] *= longitud;
			pNormals[u*3+2] *= longitud;

			vertice->GetData()->SetTuple(u, &this->m_afCurrentCoord[u*3]);
			this->GetPointData()->GetNormals()->SetTuple(u,&pNormals[u*3]);

			
		}

}
//----------------------------------------------------------------------------
void vtkEsquiPolyData::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
}
