#include "vtkAlgebra.h"

// Clase Point -------------------------------------------
//--------------------------------------------------------

Point::Point(float xx, float yy, float zz, float ww)
//Constructor por defecto
{
	x=xx; y=yy; z=zz; w=ww; isUnitary=0;
};

Point Point::operator +(Point p)
//Suma de dos vectores 
{
	Point suma;
	
	suma.x=x+p.x; suma.y=y+p.y; suma.z=z+p.z;
	return suma;
};

Point Point::operator -(Point p)
//Diferencia de dos vectores
{
	Point sub;
	sub.x=x - p.x; sub.y=y-p.y; sub.z=z-p.z;
	return sub;

};

Point Point::operator *(float k)
//Producto por un escalar POR LA DERECHA
{
	Point multi;
	multi.x=x*k; multi.y=y*k; multi.z=z*k;
	return multi;
};

float Point::operator [](int i)
//Tratamiento como vector por sobrecarga del operador []
{
	switch(i)
	{
	case 0:
		return(x);
		break;
	case 1:
		return(y);
		break;
	case 2:
		return(z);
		break;
	case 3:
		return(w);
		break;
	default:
		std::cerr << "GB:Indice de coordenada fuera de rango\n";
	};
	exit(1);
	return 0.0f;
};

Point Point::operator *(Matrix m)
//Producto por una matriz POR LA DERECHA (P*M)
{
	int i;
	Point resul;

	resul.w = 0.0f;
	// Â¿O w debe valer 1 siempre en el punto resultante?
	for (i=0; i<4; i++)
	{
		resul.x += (*this)[i]*m.e[i][0];
		resul.y += (*this)[i]*m.e[i][1];
		resul.z += (*this)[i]*m.e[i][2];
		resul.w += (*this)[i]*m.e[i][3];
	}
	return resul;

};

Point Point::Transformate(Transformation &t)
//Transforma considerando el punto como vector columna
//es decir, aplica la transformacion por la izquierda
{
	return (t*(*this));
};

Point Point::Invert()
//Devuelve un nuevo vector con el signo cambiado
{
	return Point(-x,-y,-z,w);
};

float Point::Module()
//Devuelve el modulo del vector
{
	float modu;
	modu = cuad(x) + cuad(y) + cuad(z);
	modu = (float)sqrt(modu);
	if(modu == 0.0f) modu = 0.0001f;
	return modu;

};

Point Point::Normalize()
//Normaliza el vector receptor y se devuelve a si mismo
{
	float temp;

	if (isUnitary == 0) {
		isUnitary = 1;
		temp = Module();
		x = x/temp;
		y = y/temp;
		z = z/temp;
		}
	return *this;
};

Point Point::Unitary()
//Devuelve el vector unitario en esa direccion
{
	Point norm;
	float temp;

	if (isUnitary == 0) {
		temp = Module();
		norm.x = x/temp;
		norm.y = y/temp;
		norm.z = z/temp;
		norm.w = 1.0f;
		}
	else {
		norm.x = x; norm.y = y; norm.z = z; norm.w=1.0f;
	}
	norm.isUnitary = 1;
	return norm;
};

float Point::Length()
//Calcula la longitud (0..360Âº) esferica del vector en grados
{
	float longi;
	float hipot;
	float coseno;

	hipot = (float)sqrt(cuad(x)+cuad(z));
	if (hipot != 0) 
	{
		coseno = z/(hipot);
		longi= (float)acos(coseno);
		if (x<0) longi= -longi;
	}
	else
		longi = 0.0f;
	
	return longi*180/PI;
	
};

float Point::Latitude()
//Calcula la latitud (-90Âº..90Âº) esfÃ©rica del vector en grados
{
	float lat;
	lat= (float)acos(sqrt(x*x+z*z)/Module());		
	if(y<0) lat= -lat;
	return lat*180/PI;
};

float Point::operator *(Point p)
//Calcula el producto escalar
{
	int i;
	float tot = 0.0f;
	for (i=0; i<3; i++)
		tot += (*this)[i]*p[i];

	return tot;
}

Point Point::operator ^(Point p)
//Calcula el producto vectorial
{
	Point resul;

	resul.x = y*p.z - z*p.y;
	resul.y = z*p.x - x*p.z;
	resul.z = x*p.y - y*p.x;

	return resul;
}

Point Point::Homogeneous()
//Devuelve el punto con w=1 (dividiendo por w)
{
	Point resul;
	
	resul.x = x/w;
	resul.y = y/w;
	resul.z = z/w;
	resul.w = 1.0f;

	return resul;
}

void Point::write()
//Escribe las coordenadas del punto en la consola
{
	std::cout << x <<","<< y << ","<< z <<","<< w;
	std::cout << std::endl;
};

BOOL Point::operator ==(Point p)
//Compara puntos
{
	if ((x == p.x)&&(y == p.y)&&(z == p.z)&&(w == p.w))
		return TRUE;
	else
		return FALSE;
};


//Clase Matrix -------------------------------------------
//--------------------------------------------------------


Matrix::Matrix()
//Construye la identidad por defecto
{
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			if(j==i) e[i][j]=1.0f;
			else e[i][j]=0.0f;
		};
};

Matrix::Matrix(Point e1,Point e2,Point e3,Point e4)
//Construye la matriz por columnas
{
	int i;
	for(i=0;i<4;i++){
		e[i][0]=e1[i];
		e[i][1]=e2[i];
		e[i][2]=e3[i];
		e[i][3]=e4[i];
	};
};

Point Matrix::row(int i)
//Devuelve un punto formado por la fila i (0..3)
{
	if(i<4 && i>=0) return Point(e[i][0],e[i][1],e[i][2],e[i][3]);
	else {		
		std::cerr << "GB:Indice de columna fuera de rango\n";
		exit(1);
	};
	return Point();
};

Point Matrix::column(int i)
//Devuelve un punto con la columna i (0..3)
{
	if(i<4 && i>=0) return Point(e[0][i],e[1][i],e[2][i],e[3][i]);
	else {		
		std::cerr << "GB:Indice de columna fuera de rango\n";
		exit(1);
	};
	return Point();
};


Matrix Matrix::operator =(const Matrix &m)
//Asignacion de matrices
{
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++) e[i][j]=m.e[i][j];
	return *this;
};

Matrix Matrix::operator *(Matrix m)
//Producto de matrices. Devuelve una nueva matriz
{
	Matrix product;
	int i,j,k;

	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
			product.e[i][j] = 0.0f;

	for (i=0; i<4; i++) {
		for (j=0; j<4; j++){
			for (k=0; k<4; k++){
				product.e[i][j] += e[i][k] * m.e[k][j];
			}
		}
	}
	return product;
};

Point Matrix::operator *(Point p)
//Producto por un vector POR LA DERECHA (M*P)
{
	int j;
	Point pr(0.0f,0.0f,0.0f,0.0f);

	for(j=0;j<4;j++){
		  pr.x= pr.x+e[0][j]*p[j];
		  pr.y= pr.y+e[1][j]*p[j];
		  pr.z= pr.z+e[2][j]*p[j];
		  pr.w= pr.w+e[3][j]*p[j];
	};
	return pr;
};

Matrix3d Matrix::operator *(const Matrix3d &m3d)
//Multiplica por capas (k cte.) y devuelve una matriz3d
{
	int i,j,k,n;
	Matrix3d mr;	//Por defecto toda a ceros

	for(k=0;k<4;k++) //fija la capa
		for(i=0;i<4;i++)
			for(j=0;j<4;j++)
				for(n=0;n<4;n++)
					mr.e[i][j][k]= mr.e[i][j][k] + e[i][n]*m3d.e[n][j][k];
	return mr;
};


Matrix Matrix::operator *(float k)
//Producto por un escalar (M*k). Devuelve una nueva matriz
{
	Matrix prod;
	int i,j;

	for (i=0; i<4; i++) {
		for (j=0; j<4; j++){
			prod.e[i][j] = e[i][j]*k;
		}
	}
	return prod;
};

Matrix Matrix::operator !()
//Devuelve la traspuesta en una nueva matriz. 
//Usar parentesis para asegurar precedencia (!M)
{
	Matrix trasp;
	int i,j;

	for (i=0; i<4; i++){
		for (j=0; j<4; j++){
			trasp.e[j][i] = e[i][j];
		}
	}
	return trasp;
};

void Matrix::write()
//Escribe la matriz por filas en la salida estandar
{
	int i,j;

	for(i=0;i<4;i++){
		std::cout << std::endl;
		for(j=0;j<4;j++)
			std::cout << e[i][j] << "  ";
	};
	std::cout << std::endl;
};


//Clase Transformation (subclase de Matrix) -------------------------
//-------------------------------------------------------------------

void Transformation::Displacement(Point d)
//Acumula la traslacion propuesta (d es la traslaciÃ³n)
{
	Matrix t;
	int i;

	for (i=0;i<3;i++) t.e[i][3]=d[i];
	Matrix::operator=((*this)*t); // ===  (*this)=(*this)*t;
};

void Transformation::Scale(float sx,float sy,float sz, Point center)
//Acumula el escalado sobre un punto generico
{
	Matrix s;
	
	s.e[0][0] = sx; s.e[1][1] = sy; s.e[2][2] = sz;
	if (center.Module() != 0) Displacement(center);
	Matrix::operator=((*this)*s);
	if (center.Module() != 0) Displacement(center.Invert());

};


void Transformation::Rotation(float ang, Point vectorEje, Point enRecta )
//Acumula el giro alrededor de un eje generico
{
	float lat,longit;

	lat = vectorEje.Latitude();
	longit = vectorEje.Length();

	Displacement(enRecta);
	RotationY(longit);
	RotationX(-lat);

	RotationZ(ang); //El giro sobre el eje tumbado

	RotationX(lat);
	RotationY(-longit);
	Displacement(enRecta.Invert());

};

//Acumulacion de giros especÃ­ficos
void Transformation::RotationX(float ang)
//en X
{
	Matrix g;
	g.e[1][1]=(float)cos((double)ang/180*PI);
    g.e[1][2]=(float)sin((double)(-ang/180*PI));
	g.e[2][1]= -g.e[1][2];        
	g.e[2][2]=g.e[1][1];

	Matrix::operator=((*this)*g);
};
void Transformation::RotationY(float ang)
//en Y
{
	Matrix g;
	g.e[0][0]=(float)cos((double)ang/180*PI);
    g.e[2][0]=(float)sin((double)(-ang/180*PI));
	g.e[0][2]= -g.e[2][0];        
	g.e[2][2]=g.e[0][0];

	Matrix::operator=((*this)*g);
};
void Transformation::RotationZ(float ang)
//en Z
{
	Matrix g;
	g.e[0][0]=(float)cos((double)ang/180*PI);
    g.e[0][1]=(float)sin((double)(-ang/180*PI));
	g.e[1][0]= -g.e[0][1];        
	g.e[1][1]=g.e[0][0];

	Matrix::operator=((*this)*g);
};
void Transformation::Rotation(Point u, Point v, Point w)
//Acumula un cambio de base dado por los ejes u,v,w
{
	Matrix g;

	g = !(Matrix(u,v,w,Point(0.0f,0.0f,0.0f,1.0f)));
	g.e[0][3] = 0.0f;
	g.e[1][3] = 0.0f;
	g.e[2][3] = 0.0f;

	Matrix::operator=((*this)*g);
}

void Transformation::Identity()
{
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			if(j==i) e[i][j]=1.0f;
			else e[i][j]=0.0f;
		};

}


// Clase Matrix3d -------------------------------------------
//-----------------------------------------------------------

Matrix3d::Matrix3d()
//Constructor por defecto. Matriz toda a 0.0
{
	int i,j,k;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++)
		for(k=0;k<4;k++) e[i][j][k]=0.0f;
};

Matrix3d::Matrix3d(Matrix c1, Matrix c2, Matrix c3, Matrix c4)
//Contruye la matriz3d con las matrices como columnas
{
	int i,k;

	for(i=0;i<4;i++)
		for(k=0;k<4;k++){
			e[i][0][k]=c1.e[k][i];
			e[i][1][k]=c2.e[k][i];
			e[i][2][k]=c3.e[k][i];
			e[i][3][k]=c4.e[k][i];
	};
};

Matrix3d Matrix3d::operator =(const Matrix3d &m)
//Asignacion de matrices 3d
{
	int i,j,k;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++)
			for (k=0;k<4;k++) e[i][j][k]=m.e[i][j][k];
	return *this;
};

Matrix3d Matrix3d::operator *(const Matrix &m)
//Multiplica por capas y devuelve la nueva matriz 3d
{
	int i,j,k,n;
	Matrix3d mr;	//Por defecto toda a ceros

	for(k=0;k<4;k++) //fija la capa
		for(i=0;i<4;i++)
			for(j=0;j<4;j++)
				for(n=0;n<4;n++)
					mr.e[i][j][k]= mr.e[i][j][k] + e[i][n][k]*m.e[n][j];
	return mr;

};

Point Matrix3d::RowColumn(int i, int j)
//Devuelve el punto para esa fila,columna 
{
/********************* A IMPLEMENTAR ***********************/
	return Point(e[i][j][0],e[i][j][1],e[i][j][2],e[i][j][3]);
};

void Matrix3d::write()
//escribe la matriz por la salida estandar por columnas
{
	int i,j,k;

	for(j=0;j<4;j++){
		std::cout << std::endl;
		for(i=0;i<4;i++){
			std::cout << std::endl;
			for(k=0;k<4;k++) std::cout << e[i][j][k] << "  ";
		};
	};
};

Matrix3d Matrix3d::InsertPoint(int i, int j, Point p)
//Mete un punto en la posicion i,j
{
	int k;
	for(k=0;k<4;k++)
		e[i][j][k]=p[k];
	return *this;
};

