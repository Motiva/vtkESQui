#include "vtkEsquiFaceCollection.h"
#include "vtkObjectFactory.h"
#include "vtkFace.h"

vtkCxxRevisionMacro(vtkEsquiFaceCollection, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkEsquiFaceCollection);

vtkIdType vtkEsquiFaceCollection::Append(vtkFace *a) {
	this->vtkEsquiCollection::InsertObject((vtkObject *) a);
	return (this->GetNumberOfItems() -1);
}
vtkFace* vtkEsquiFaceCollection::Item(vtkIdType Posicion) {
	return static_cast <vtkFace *> (this->vtkCollection::GetItemAsObject((int)Posicion));
}
vtkFace* vtkEsquiFaceCollection::GetFirst() {
	return this->Item(0);
}
void vtkEsquiFaceCollection::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
}
vtkIdType vtkEsquiFaceCollection::Find(vtkFace *object) {
	return this->Superclass::Find((vtkObject*) object);
}
vtkIdType vtkEsquiFaceCollection::IndexOf(vtkFace *object) {
	return this->Superclass::IndexOf((vtkObject*) object);
}
vtkFace* vtkEsquiFaceCollection::GetNextItem() {
	return static_cast<vtkFace*>(this->vtkCollection::GetNextItemAsObject());
}
void vtkEsquiFaceCollection::DeleteAll() {
	vtkFace *Temp;
	this->InitTraversal();
	while (Temp = this->GetNextItem()) {
		Temp->Delete();
	}
	this->RemoveAllItems();
}
void vtkEsquiFaceCollection::CreateNodes(int numNodes) {
	for (int i = 0; i<numNodes; i++) {
		this->Append(vtkFace::New());
	}
}

