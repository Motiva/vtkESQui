
#ifndef _J02032001CLINK_
#define _J02032001CLINK_

#include "vtkObject.h"
#include "vtkBaseArray.h"
#include "Macros.h"
#include "vtkesquiT2MeshWin32Header.h"
// Establece el modo de actualizar los puntos que forman el link entre dos organos por posicion
//! Establishes the way of updating the points that form the link between two organs for position 
#define UM_POSITION 0   // 
// Establece el modo de actualizar los puntos que forman el link entre dos organos por desplazamiento
//! Establishes the way of updating the points that form the link between two organs for displacement
#define UM_SHIFT 1 

class vtkOrgan;

// Esta clase representa las uniones entre organos, sirve para informar a cada una de los cambios que le provee la otra y viceversa
//! This class represents the unions between organs, serves to inform to each of the changes that other one provides him and vice versa
class VTK_ESQUI_T2MESH_EXPORT vtkLink: public vtkObject {
protected:
	// Para cada organo debemos saber que poligono contiene el punto en cuestion
	//! For every organ we must know which polygon contains the point
	vtkOrgan* m_pPrimary;     
	// Identificador primario
	//! Primary identificator
	UINT    m_nPId;		     
	float   m_afPPoint[3];
	float   m_afPIniPt[3];
	float   m_afPDispl[3];
	float	m_afPForce[3];
	float	m_afPPointOrig[3];
	// Para cada organo debemos saber que poligono contiene el punto en cuestion
	/*
		Normalmente para el primario indica el vertice y para el 
		secundario indica el poligono dentro del que se encuentra la union 
	*/
	//! For every organ we must know which polygon contains the point
	/*!
		Normally for the primary indicates the vertex and for the secondary it indicates the polygon in which the union is
	*/
	vtkOrgan* m_pSecondary;   
	
	UINT	m_nSId;		// primaria o secundaria.
	float   m_afSPoint[3];  // 
	float   m_afSIniPt[3];  // 
	float   m_afSDispl[3];  // encuentra la union.
	float	m_afSForce[3];
	float	m_afSPointOrig[3];

	// Desplazamiento inicial, secundario-primario
	//! Initial displacement, secondary-primary
	float   m_afIniDispl[3];
	bool    m_bEnabled;
	bool    m_bChanged;

	// Cuando despues de invocar UnRef es igual a 0 el objeto se destruye
	
	UINT    m_nRef;         
	// Metodo de actualizacion para el esclavo
	//! Metod of update for the slave
	int     m_fgUpdateType; 
	
public:
	vtkTypeRevisionMacro(vtkLink, vtkObject);
	static vtkLink *New();
	const char *GetClassName() {return "vtkLink";}
	void PrintSelf(ostream& os,vtkIndent indent);

	vtkLink(int fgUpdType=0){ m_fgUpdateType=fgUpdType;m_pPrimary=m_pSecondary=NULL; m_bEnabled=false;m_nRef=0; 
		m_afPDispl[0]=m_afPDispl[1]=m_afPDispl[2]=0.0f;
		m_afSDispl[0]=m_afSDispl[1]=m_afSDispl[2]=0.0f;
	};
	~vtkLink() {}
	// Establece un punto de union entre organos asignando todos los parametros
	//! Establish a union point between the organs, assigning all parameters
	void SetLinkData(vtkOrgan* pPrimary,UINT nPId,float* afPPoint, float* afPForce,
					 vtkOrgan* pSecondary,UINT nSId,float* afSPoint, float* afSForce);
	// Establece un punto de union entre organos asignando todos los parametros
	//! Establish a union point between the organs, assigning all parameters
	void SetLinkData(vtkOrgan* pCaller,UINT nId,float* afPoint=NULL, float* afForce=NULL );
	// Extrae la informacion de una union
	//! Get the union's information
	void GetLinkData(vtkOrgan* pCaller,UINT* pId,float* afPoint=NULL, float* afForce=NULL) const;
	
	// Actualiza la informacion de las uniones
	//! Update the union's information
	void UpdateLinkInfo(const vtkOrgan* pCaller,float* afPosition, float* afForce);
	void GetLinkShift(const vtkOrgan* pCaller,float* afShift) const;
	void GetRelativePosition(const vtkOrgan* pCaller, float* afPosition) const;
	void GetLinkForce(const vtkOrgan* pCaller, float* afForce) const;
	void GetLinkPosition(const vtkOrgan* pCaller,float* afPosition) const;
	void GetLinkOrigPositionCaller(const vtkOrgan* pCaller,float* afPosition) const;
	int  GetUpdateMode() const{ return m_fgUpdateType; }

	bool IsPrimary(const vtkOrgan* pCaller) const;
	void ChangePriority();

	void SetEnabled(bool bValue){ m_bEnabled=bValue; }
	bool IsEnabled() const { return m_bEnabled; }
	bool IsChanged() const { return m_bChanged; }

	void Ref(){ m_nRef++; }
	void UnRef();
private:
	vtkLink(const vtkLink &);
	void operator =(const vtkLink &);
};

#endif


