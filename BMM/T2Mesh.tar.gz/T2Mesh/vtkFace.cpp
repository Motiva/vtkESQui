
#include "vtkFace.h"
#include "vtkObjectFactory.h"
#include "math.h"

vtkCxxRevisionMacro(vtkFace, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkFace);
vtkFace::vtkFace()
//Constructor por defecto
{
	Vertexes = NULL;
	numVertex = 0;
};

vtkFace::~vtkFace(){
	delete[] Vertexes;
	//this->UnRegister(this);
}

void vtkFace::AddVertex(int p)
//Esta funciÃ³n aÃ±ade un nuevo vÃ©rtice a la cara tratada
{
	int i;
	int *vloc;

	numVertex++;
	if (numVertex>1)
	{
	vloc = (int *)new int[numVertex];
	for (i=0;i<(numVertex-1);i++)
		vloc[i]=Vertexes[i];
	vloc[numVertex-1]=p;
	delete[] Vertexes;
	Vertexes = (int *)new int[numVertex];
	for (i=0;i<numVertex;i++)
		Vertexes[i]=vloc[i];
	delete[] vloc;
	}
	else
	{
		Vertexes = (int *)new int[numVertex];
		Vertexes[numVertex-1]=p;
	}
};

int vtkFace::operator [](int i) 
//Se obtiene el vertice nÃºmero i de la cara
{
	if (i<numVertex)
		return Vertexes[i];
	else
		return -1;

};

Point vtkFace::normal(Point *puntost2)
//Devuelve la normal de la cara
{
	Point seg1,seg2;
	if (numVertex > 2)
	{
		seg1 = puntost2[Vertexes[1]] - puntost2[Vertexes[0]];
		seg2 = puntost2[Vertexes[2]] - puntost2[Vertexes[1]];
		return (seg1^seg2).Unitary();
	}
	else
		return Point();
};

vtkFace vtkFace::operator =(const vtkFace &c)
//Asigna caras
{
	int i;
	if (numVertex>0)
	{
		delete Vertexes;
		numVertex = 0;
	}
	numVertex = c.numVertex;
	Vertexes = (int *)new int[numVertex];
	for (i=0;i<numVertex;i++)
		Vertexes[i]=c.Vertexes[i];

	return *this;
};


BOOL vtkFace::Contains(int p)
//Comprueba si la cara contiene el vÃ©rtice de Ã­ndice p
{
	int i;
	BOOL encontrado = FALSE;

	i=0;
	while ((!(encontrado))&&(i<numVertex))
	{
		if (Vertexes[i]==p) 
			encontrado = TRUE;
		i++;
	}
	return encontrado;
}


BOOL vtkFace::dentroproy(Point p, Point *puntost2)
//Comprueba si el punto p pertenece a la proyecciÃ³n ortogrÃ¡fica de la cara
{
	int i;
	Point *vp;		//Vectores del punto a los vÃ©rtices de la proyecciÃ³n
	float ang=0.0f;	//Angulo acumulado para comprobar interioridad
	
	vp = (Point *)new Point[numVertex];
	for (i=0; i<numVertex;i++)
	{
		vp[i]=Point(puntost2[Vertexes[i]].x-p.x,puntost2[Vertexes[i]].y-p.y,0.0f);
		vp[i]=vp[i].Unitary();
	}
	for (i=0; i<numVertex-1;i++)
		ang += (float)acos(vp[i]*vp[i+1]);
	ang = (float)grad(ang);
	delete[] vp;
	if ((ang >= 359.9f)&&(ang <= 360.1f)) 
		return TRUE;
	else 
		return FALSE;
}

int vtkFace::Index(Point p, Point *puntost2)
{
	int i;

	for (i=0; i<numVertex; i++)
		if (puntost2[Vertexes[i]]==p)
			return i;

	return -1;
}

Point vtkFace::Center(Point * puntost2)
{
	Point acum;
	int i;

	acum = puntost2[Vertexes[0]];
	for (i=1; i<numVertex;i++)
		acum = acum + puntost2[Vertexes[i]];
	acum = acum*(1.0f/numVertex);
	return acum;
}

