#include "vtkEsquiContactCollection.h"

#include "vtkObjectFactory.h"
#include "vtkContactPoint.h"

vtkCxxRevisionMacro(vtkEsquiContactCollection, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkEsquiContactCollection);

vtkIdType vtkEsquiContactCollection::Append(vtkContactPoint *a) {
	this->vtkEsquiCollection::InsertObject((vtkObject *) a);
	return (this->GetNumberOfItems() -1);
}
vtkContactPoint* vtkEsquiContactCollection::Item(vtkIdType Posicion) {
	return static_cast <vtkContactPoint *> (this->vtkCollection::GetItemAsObject((int)Posicion));
}
vtkContactPoint* vtkEsquiContactCollection::GetFirst() {
	return this->Item(0);
}
void vtkEsquiContactCollection::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
}
vtkIdType vtkEsquiContactCollection::Find(vtkContactPoint *object) {
	return this->Superclass::Find((vtkObject*) object);
}
vtkIdType vtkEsquiContactCollection::IndexOf(vtkContactPoint *object) {
	return this->Superclass::IndexOf((vtkObject*) object);
}
