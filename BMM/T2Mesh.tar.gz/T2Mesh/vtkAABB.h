#ifndef __vtkAABB_h
#define __vtkAABB_h


#include "vtkGeometricModel.h"
#include "Macros.h"
#include "vtkesquiT2MeshWin32Header.h"

// Caja de inclusion para la deteccion de colisiones
//! Bounding box for the detection of collisions
class VTK_ESQUI_T2MESH_EXPORT vtkAABB: public vtkGeometricModel {
public:
	vtkTypeRevisionMacro(vtkAABB,vtkGeometricModel);
	static vtkAABB *New(){return new vtkAABB;}
	const char *GetClassName() {return "vtkAABB";};
	// Punto central de la caja de inclusion
	//! Central point of the bounding box
	float Center[3];
	// Extension de la caja en los 3 ejes X Y Z 
	/*
		Tamano de la caja   center - extens/2 <-> center+extens/2
	*/

	//! Extension of the box in 3 axes X Y Z
	/*
		Size of the box center - extens/2 <-> center+extens/2
	*/
	float extension[3];		

	// Constructor por defecto											
	//! Default constructor
	vtkAABB():vtkGeometricModel() {
		Center[0] = Center[1] = Center[2] = 0.0f;
		extension[0] = extension[1] = extension[2] = 0.0f;

	};
private:
	vtkAABB(const vtkAABB &);
	void operator=(const vtkAABB &);
};
#endif
