#include "vtkDeformableModel.h"
#include "vtkObjectFactory.h"

vtkCxxRevisionMacro(vtkDeformableModel, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkDeformableModel);
vtkDeformableModel::~vtkDeformableModel(){
if(idVerticesMovidos)
			delete[] idVerticesMovidos;
		if(Vertexes)
			delete[] Vertexes;
		if (Faces)
			delete[] Faces;
};


vtkIdType vtkDeformableModel::GetNumberOfVertexes() 
{
	return this->VertexesNumber;
};
vtkIdType vtkDeformableModel::GetNumberOfFaces() 
{
	return (vtkIdType)this->FacesNumber;
};
vtkIdType vtkDeformableModel::GetNumberOfMovedVertexes() 
{
	return (vtkIdType)this->MovedVertexesNumber;
};

float* vtkDeformableModel::GetVertex(vtkIdType Index) {
	float *aux =new float[3];
	aux[0]= this->Vertexes[Index*3+0];
	aux[1]= this->Vertexes[Index*3+1];
	aux[2]= this->Vertexes[Index*3+2];
	return aux;
}

void vtkDeformableModel::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);

  os << indent << "Numero de Vertices Movidos: " << this->GetNumberOfMovedVertexes() << endl;
  
}
