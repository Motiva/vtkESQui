#ifndef _CALGEBRA
#define _CALGEBRA

#include <iostream>
using namespace std;
#include <stdio.h> //AÃ‘ADIDO
#include <stdlib.h> //AÃ‘ADIDO
#include <math.h>
#include "Macros.h"
#include "vtkesquiT2MeshWin32Header.h"

//Clases basicas de geometria y algebra

class Point;
class Matrix;
class Transformation;
class Matrix3d;


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Actua indistintamente como punto o vector almacenado 4 coordenadas o componentes
//! Actuates indistinctly as point or vector of 4 coordinates or components
class VTK_ESQUI_T2MESH_EXPORT Point

{
public:
	// Coordenadas homogeneas
	//! Homogeneous coordinates
	float x,y,z,w;							
	// Constructor por defecto
	//! Defect constructor
	Point(float xx=0.0, float yy=0.0,		
		  float zz=0.0, float ww=1.0); 
	// Suma de puntos
	//! Sum of points
	Point operator +(Point p);				
	// Resta de puntos
	//! Subtraction of points
	Point operator -(Point p);				
	// Producto por un escalar
	//! Product for one scalar
	Point operator *(float k);				
	// Considerado como vector
	//! Considered as vector
	float operator [](int i);				
	// Producto por una matriz
	//! Matrix product
	Point operator *(Matrix m);				
	// Transformacion de un punto
	//! Point transformation
	Point Transformate(Transformation &t);	
	// Point con el signo cambiado
	//! Change the point's sign
	Point Invert();							
	// Normaliza el punto y se devuelve asi mismo
	//! Normalize the point
	Point Normalize();						
	// Vector unitario en esa direccion
	//! Unitary vector on this direction
	Point Unitary();						
	// Calcula el modulo del vector
	//! Calculate the vector's module
	float Module();							
	// Calcula la longitud esferica del vector
	//! Calculate the spheric length of the vector
	float Length();						
	// Calcula la latitud esferica del vector
	//! Calculate the spheric latitude of the vector
	float Latitude();						
	// Calcula el producto escalar
	//! Calculate the scalar product
	float operator *(Point p);		
	// Calcula el producto vectorial
	//! Calculate the vectorial product
	Point operator ^(Point p);		
	// Devuelve el punto con w=1
	//! Return the point with w=1
	Point Homogeneous();				
	// Escribe el punto
	//! Write the point
	void write();						
	// Compara puntos
	//! Compare points
	BOOL operator ==(Point p);		

private:
	// esta normalizado
	//! It is normalized
	int isUnitary;							
};
 
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Matriz de 4x4 coordenadas o Matriz vector de 4 puntos
//! 4X4 coordinates matrix or 4 points matrix
class VTK_ESQUI_T2MESH_EXPORT Matrix

{
public:
	float e[4][4];
	// Construye la identidad por defecto
	//! Constructs the identity by default
	Matrix();							
	// Constructor por columnas
	//! constructor by columns
	Matrix(Point e1,Point e2,			
		   Point e3,Point e4=Point());
	// Devuelve un punto con la fila i(0..3)
	//! Return a point with the i(0..3) row
	Point row(int i);					
	// Devuelve un punto con la columna i(0..3)
	//! Return a point with the i(0..3) column
	Point column(int i);				
	// Asignacion de matrices
	//! Matrix assing
	Matrix operator =(const Matrix &);	
	// Producto de matrices
	//! Matrix product
	Matrix operator *(Matrix m);		
	// Producto por un vector	
	//! Product for a vector
	Point operator *(Point p);		
	// Producto por capas con una matriz 3d
	//! Product for caps with a 3d matrix
	Matrix3d operator *(const Matrix3d &);
	// Producto por un escalar
	//! Product for a scalar
	Matrix operator *(float k);			
	// Traspone filas y columnas
	//! Transpose colums and rows
	Matrix operator !();				
	// Escribe la matriz
	//! Write the matrix
	void write();					
};

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Matriz de transformacion derivada de matriz que acumula transformaciones 3D
/*
	La acumulacion es LIFO sobre el punto pensando en coordenadas fijas
	y se debe aplicar por la izquierda del punto en columna (idem GL)
	Ej: P' = M1*M2*M3*P  (M3 fue la ultima en acumularse y la primera en aplicarse)
*/
//! Transformation matrix derived from a matrix that stores 3D transformations

class VTK_ESQUI_T2MESH_EXPORT Transformation: public Matrix

{
public:
	// Acumula la traslacion propuesta
	//! Store the proposed displacement
	void Displacement(Point d);
	
	// Acumula el escalado
	//! Store the scale
	void Scale(float sx=1.0,float sy=1.0,float sz=1.0, Point Center=Point());
	
	// Acumula el giro (ang en grados)
	//! Store the spin (degrees)
	void Rotation(float ang, Point vectorEje, Point enRecta=Point() );
	
	// Acumulacion de giros especificos (ang en grados)
	//! Store the spin in the X axe (degrees)
	void RotationX(float ang);
	// Acumulacion de giros especificos (ang en grados)
	//! Store the spin in the Y axe (degrees)
	void RotationY(float ang);
	// Acumulacion de giros especificos (ang en grados)
	//! Store the spin in the Z axe (degrees)
	void RotationZ(float ang);
	
	// Acumula un cambio de base dado por los ejes u, v, w
	//! Store the change in the base given by the u, v, w axes 
	void Rotation(Point u, Point v, Point w);
	
	void Identity();
};

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Matriz cubica de 4x4x4 (filas X columnas X capas)
//! 4x4x4 Cubic matrix 
class VTK_ESQUI_T2MESH_EXPORT Matrix3d: public Matrix

{
public:
	float e[4][4][4];

	Matrix3d();
	// Constructor por columnas
	//! Constructor by columns
	Matrix3d(Matrix , Matrix , Matrix , Matrix );
	
	// Devuelve el punto en fila i, columna j
	//! Return the point in the i row, column j
	Point RowColumn(int i,int j);				
	// Mete el punto en la posicion i,j
	//! Insert the point in the (i,j) position
	Matrix3d InsertPoint(int i, int j, Point p);
	// Asignacion de matrices 3d
	//! Assign 3D matrixes
	Matrix3d operator =(const Matrix3d &);  
	// Producto por capas con una matriz
	//! Product for caps with a matrix
	Matrix3d operator *(const Matrix &);	
	void write();
};

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


#endif 
