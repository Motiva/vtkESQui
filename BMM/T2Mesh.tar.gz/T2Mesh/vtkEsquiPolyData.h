#ifndef __vtkEsquiPolyData_h
#define __vtkEsquiPolyData_h

//#include "Macros.h"
#include "vtkPolyData.h"
#include "vtkCell.h" // Se incluye aqui para funciones inline
#include "vtkesquiT2MeshWin32Header.h"

// Clase que abstrae de la libreria grfica, a las clases derivadas.
//! Abstact the graphic library 
class VTK_ESQUI_T2MESH_EXPORT vtkEsquiPolyData : public vtkPolyData 
{
public:
  static vtkEsquiPolyData *New();
  vtkTypeRevisionMacro(vtkEsquiPolyData,vtkPolyData);
  virtual void PrintSelf(ostream& os, vtkIndent indent);
  
  //BTX
  // Calcula la posicion del vertice
  /*
	\param vertex Vertice a buscar
	\param i Posicion del vertice buscado
  */
  //! Calculate the vertex position
  /*
	\param vertex Vertex to search
	\param i vertex's position
  */
  inline void VertexPosition(vtkIdType i, float* vertex);
  // Devuelve el identificador del vertice dentro del poligono
  /*
	\param i Poligono a buscar
	\param Component Numero de vertice dentro del poligono
  */
  //! Return the identificator of the vertex in the polygon
  /*
	\param i Polygon to search
	\param Component polygon's vertex number
  */
  inline vtkIdType idPolygonVertex(vtkIdType i, vtkIdType Component);
  //ETX
   // Devuelve en uv la coordenada de la textura para un punto dado
   //! Return in "uv" the coordinate of the texture for a given point
  void coordTexturaVertPoligono(vtkIdType i,vtkIdType Component,float* uv);
  // Modifica la geometria actualizada por el modelo deformable
  //! Modify the geometry set up by the deformable model
  void modificaGeometria();
 
protected:
	vtkEsquiPolyData() {}
	~vtkEsquiPolyData() {}
float* m_afCurrentCoord;

private:
  vtkEsquiPolyData(const vtkEsquiPolyData&);  // Not implemented.
  void operator=(const vtkEsquiPolyData&);  // Not implemented.
};

inline void vtkEsquiPolyData::VertexPosition(vtkIdType i, float* vertex) {
	vertex[0]=this->vtkPolyData::GetPoints()->GetPoint(i)[0];
	vertex[1]=this->vtkPolyData::GetPoints()->GetPoint(i)[1];
	vertex[2]=this->vtkPolyData::GetPoints()->GetPoint(i)[2];
}
inline vtkIdType vtkEsquiPolyData::idPolygonVertex(vtkIdType i, vtkIdType Component) {

	return this->vtkPolyData::GetCell(i)->GetPointIds()->GetId(Component);
}

#endif


