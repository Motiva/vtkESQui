#include "vtkContactPoint.h"
#include "vtkOrgan.h"
#include "vtkObjectFactory.h"

#ifdef _DEBUG
	#undef THIS_FILE
	static char THIS_FILE[]=__FILE__;
#endif
vtkCxxRevisionMacro(vtkContactPoint, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkContactPoint);
//*****   c o n s t r u c t o r

// standard constructor to be called by CToolPoint::EstablishContact():
// initialize member variables and inform vtkOrgan about new contact;
vtkContactPoint::vtkContactPoint( double		 c_afCoord[],
		  double afRestMov[],
		  vtkOrgan*	 c_pOrgan,
		  const UINT c_uElement,
		  UINT nVertex,
		  const UINT c_uContactID )
{
	// pointers to tool point and organ
	assert(c_pOrgan != NULL );
	m_pOrgan    = c_pOrgan;

	// contact point's global and relative position w.r.t. element within which the contact
	//   has been established
	m_afCoord[0] = c_afCoord[0];
	m_afCoord[1] = c_afCoord[1];
	m_afCoord[2] = c_afCoord[2];
	assert( c_uElement < c_pOrgan->Elements() );
	m_uElement = c_uElement;
	m_nVertex = nVertex;
	m_afLocalCoord[0] = 0.0f;
	m_afLocalCoord[1] = 0.0f;
	m_afLocalCoord[2] = 0.0f;

	m_afRestMov[0]=afRestMov[0];
	m_afRestMov[1]=afRestMov[1];
	m_afRestMov[2]=afRestMov[2];

	// other common members
	m_uContactID = c_uContactID;
	m_afForceFeedback[0] = m_afForceFeedback[1] = m_afForceFeedback[2] = 0.0f;
	m_bPullPermit = false;

	// T2-specific members
	m_bShift = true;

	// inform affected organ about new contact
	//AfxMessageBox("Nuevo contacto");
	c_pOrgan->AddContact( this );

}


//*****   d e s t r u c t o r

// inform both tool point and organ of the lost contact
vtkContactPoint::~vtkContactPoint()
{
	if( m_pOrgan!= NULL )
		m_pOrgan->ContactLost( this );
	this->UnRegister(this);
}

void vtkContactPoint::PrintSelf(ostream& os, vtkIndent indent) {
	this->Superclass::PrintSelf(os,indent);
}


