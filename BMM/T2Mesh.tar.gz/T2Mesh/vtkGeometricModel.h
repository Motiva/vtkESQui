#ifndef __vtkModeloGeometrico_h
#define __vtkModeloGeometrico_h
#include "vtkObject.h"
#include "vtkesquiT2MeshWin32Header.h"


#include "Macros.h"
#define TAM_MATRIZ_TRANS 16

//! Base class for geometrics models ina collision detection
class VTK_ESQUI_T2MESH_EXPORT vtkGeometricModel: public vtkObject
{
public:
	vtkTypeRevisionMacro(vtkGeometricModel,vtkObject);
 	static vtkGeometricModel *New();
	const char *GetClassName() {return "vtkGeometricModel";};
	//! Matrix transformation of the model
	float matrix[16]; /// Matriz de TransformaciÃ¯Â¿Â½ del modelo
	//! Id of the box
	/*!
		It use if a model is divided in few boxes
	*/
	int	  id; 

	vtkGeometricModel() {
		matrix[0] = matrix[5] = matrix[10] = matrix[15] = 1.0f;
		matrix[1] = matrix[2] = matrix[3] = 0.0f;
		matrix[4] = matrix[6] = matrix[7] = 0.0f;
		matrix[8] = matrix[9] = matrix[11] = 0.0f;
		matrix[12] = matrix[13] = matrix[14] = 0.0f;

		id=-1;
	};
private:
 	vtkGeometricModel (const vtkGeometricModel &); //Not Implemented
 	void operator =(const vtkGeometricModel &); //Not Implemented
};
// }
#endif
