#include "vtkGeometricModel.h"
#include "vtkObjectFactory.h"

vtkCxxRevisionMacro(vtkGeometricModel, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkGeometricModel);
