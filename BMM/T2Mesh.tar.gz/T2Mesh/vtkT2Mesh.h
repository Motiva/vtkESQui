/*
--------------------
Program: ESQUI
Info and Bugs: {marf,rsantana}@ctm.ulpgc.es 
-------------------------------------------

Copyright (c) 2006, Center for Technology in Medicine, University of Las Palmas
de Gran Canaria (Canary Islands, Spain).
All rights reserved.

This program is free software; you can redistribute it and/or modify it under 
the terms of the Creative Commons' "by-attribution" license 
(http://creativecommons.org/licenses/by/2.5).

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1) Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright 
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
=============================================================================*/
#ifndef _CMALLAT2
#define _CMALLAT2



#include "vtkTiposT2.h"
#include "vtkOrgan.h"
#include "Macros.h"
#include "vtkesquiT2MeshWin32Header.h"
class vtkFace;
class vtkIdListCollection;

// Implementacion del modelo biomecánico T2-MESH
/* 
	Esta clase implementa a una malla de tipo T2-mesh, estando esta formada por un	   
   vector de caras (el cual a su vez hace uso de la clase vtkFace), cuyos componentes son 
   punteros a la lista de vertices.													
																					   
   Los vertices deben ordenarse en sentido antihorario para que la representacion	   
   sombreada de buenos resultados, y ademas el ultimo de ellos coincide con el primero,
   cosa que viene bien de cara al calculo de la malla triangular dual y en el dibujado 
   de la malla.	
 
   Ademas, esta clase contiene la malla triangular dual de la malla T2, ya que por el  
   momento y hasta que no se amplie la implementacion, la lectura y escritura desde y  
   a fichero se realiza solo con mallas triangulares.

   \sa vtkOrgan, vtkEsquiPolyData
*/
//! Implementation of the biomechanic model T2-Mesh
/*!
	 This class implements a mesh of type T2-mesh, being this formed 
	 by a vector of faces (which in turn uses the class vtkFace), which components are 
	 pointers to the list of vertices.

	 The vertices must be ordained in antihourly sense in order that the shaded representation
	 gives good results. The last one of them coincides with the first one, this simplify 
	 the calculation of the triangular dual mesh and in the drawn 
	 one of the mesh.   

	 this class contains the triangular dual mesh of the mesh T2, since for the 
	 present time and until not amplie the implementation, the reading and 
	 writing from and to file it is realized only by triangular meshes.
*/
class VTK_ESQUI_T2MESH_EXPORT vtkT2Mesh: public vtkOrgan
{
//Clase que implementa una malla T2
	//BTX
  // clase que permite almacenar la informacion importante de la T2-Mesh 
  // para poder restaurar esta en caso de fallo  
  //! This class stores information needed for the T2-Mesh
  //! Is used to restore the T2-Mesh in failure case
	friend class vtkDataT2Mesh;   
	//ETX						   

public:
	static vtkT2Mesh *New();
	vtkTypeRevisionMacro(vtkT2Mesh,vtkOrgan);
	const char *GetClassName() {return "vtkT2Mesh";}
	void PrintSelf(ostream &os, vtkIndent indent);

	/*****************************************************************/
//BTX
	// Numero de puntos de la T2
	//! Number of points of the T2
	int		m_nNumPointsT2;
	// Tipo de los puntos de la T2	
	//! Type of the T2's points
	int*	m_pnPointType;		
	// Estado de los puntos de la T2: seleccionado o no
	//! State of the points of the T2: Selected or not
	int*	m_pnPointState;	
    // Marca el tipo de conexiones del nodo T2 (fantasma o real)
	//! Type of conections of the T2 node (true or false)
	INT3*   m_panConectionType;
	// Puntos que forman la T2
	//! Points that form the T2
	Point*  m_pPointsT2;		
	// Sera la textura asociada a cada vertice de la malla T2
	//! Texture associated to every vertex of the T2 Mesh
	Point*	m_pTextureT2;		
	// Posicion de los puntos de la T2 en la iteracion anterior
	//! Position of the points of the T2 in the previous iteration
	Point*  m_pPrevPointT2;

	int		m_nNumClips;
	// Estabilidad de los nodos
	//! Stability of the nodes
	bool*	m_pbUnstable;		
	// Estas variables contienen el desplazamiento calculado para los centros de cada una de las caras que forman la malla
	//! Contains the calculated displacement of the center of the mesh faces
	double *CenterDisplacementX, *CenterDisplacementY, *CenterDisplacementZ;
//ETX
	// Obtiene la posición de los vertices de la malla a partir de los desplazamientos producidos en los centros de cada una de las caras que componen la malla
	//! Obtains the position of the mesh vertexes from the displacement of the center of the faces of the mesh 
	void CalculateNewVertexesPosition();
	// Obtiene el número de caras a las que pertenece cada vertice de la malla
	//! Obtains the number of faces to which every vertex belongs
	void GetNumberOfFacesContainingEveryVertex();

	// Indica si una cara esta siendo tocada por un dispositivo
	//! Indicates if a faces is being touched by a device
	bool Touched(int nFace);
    // Indica si una nFace esta siendo pinzada con un pinzamiento total por parte de un dispositivo
	//! Indicates if a face is being gripped by a device
	bool Grasped(int nFace);
	// Calcula la fuerza interna
	/*
		Este metodo permite calcular el desplazamiento para un nodo segun
		las tensiones de los muelles que lo unen con otros tres nodos
	*/
	//! Calculate the internal force
	/*!
		This method allows to calculate the displacement for a node according 
		to the tensions of the wharves that join it with other three nodes 
	*/
	void InternalForceCalculation(int nIndPto,float fCompensacion);
	// Calcula la fuerza interna libre
	/*
		Este metodo permite calcular el desplazamiento para un nodo segun
		las tensiones de los muelles que lo unen con otros tres nodos
	*/
	//! Calculate the free internal force
	void FreeInternalForceCalculation(int nIndPto,float fCompensacion);
	//! Calcula la posicion de los nodos
	/*
		Permite calcular la posiciÃ³n de los nodos unidos a otros nodos a travÃ©s de links
	*/
	//! Calculate the position of the nodes
 	void LinksPositionCalculation();
	// Permite calcular la posiciÃ³n de los nodos que han sido pinzados con un pizado total
	//! Calculate the position of the nodes that have been gripped
	void TotalGrasperPositionCalculation();
	// Crea la malla simple tipo 2
	//! Create the simple T2-Mesh
	void PrepareSimulation();
	// Agnade un nuevo punto de contacto a la malla			
	//! Add a new point of contact to the mesh
    void AddContact( vtkContactPoint* c_pContact );				
	// Calcula numero de iteraciones en funcion de la deformacion indicada			
	//! Calculate the number of iterations in function with the indicated deformation
	void Deform(int iteracion);
	// Realiza el corte provocado por un dispositivo
	//! Make the cut done by a device
	int Cut(const char tipocorte, const unsigned uElementoComienzo, float *ptoElementoComienzo,
				const unsigned uElementoFinal, float *ptoElementoFinal, float *pfVector);
	// Cauteriza el Organo
	//! Cauterize the organ
	void Cauterize(const unsigned uElemento);
	// Elimina un contacto de la lista de contactos
	//! Delete a contact from the list of contacts
	void ContactLost( vtkContactPoint* c_pContact );
	// Elimina todos los contactos			
	//! Delete all contacts
	void DeleteContacts(){
		//
		while (m_lpContacts->GetFirst()!=NULL){
				ContactLost (m_lpContacts->GetFirst());
			}		
	}
		
	// Obtiene los nodos implicados en un pinzamiento total
	/*
		Este metodo obtiene los nodos implicados en un pinzamiento total y
		los almacena en una estructura del tipo PinzaTotal y los aÃ±ade a la
		lista de pinzas (el primer elemento esta apuntado por m_pPrimPinza)
	*/
	//! Obtains the involved nodes in a grip
	/*!
		This function obtains the involved nodes in a grip and stores them in a "PinzaTotal" structure
		and add them to the graspers list (the first element is pointed by m_pPrimPinza)
	*/
	int TotalCapture(unsigned uElementoComienzo, float *ptoElementoComienzo, float *pfVector);
	// Devuelve el numero de iteraciones que ha de realizar la T2-MEsh	
	//! Return the number of iterations that must be done by the T2-Mesh
	int GetNumIter(){ return m_nNumIter;};
			
	int PartialCapture(const unsigned uElementoComienzo, float *ptoElementoComienzo, const unsigned uElementoFinal, float *ptoElementoFinal, float *pfVector);
	void RemoveRemovedConstraints();
	//! Set Alpha parameter	
	void SetAlphaParameter(float valor);
	//! Set Gamma parameter
	void SetGammaParameter(float valor);
	//! Set Ommega parameter
	void SetOmmegaParameter(float valor);
	vtkPolyData *GetDualMesh() {return this->DualMesh;}
	vtkIdListCollection *VertexConection;
	vtkIdListCollection *InitialInternalForce;
	vtkPoints *PreviousDualMeshPoints;
	vtkPoints *DualMeshPoints;
	vtkPoints *DualLimitPoints;
	
protected:
	// Constructor por defecto
	//! Defect constructor
	vtkT2Mesh();
	// Destructor de la malla	
	//! Destructor of the mess
	~vtkT2Mesh();

	// Esta variable es una lista que contiene el número de caras a las que pertenece cada vertice de la malla
	//! Contains the number of faces to that every vertex belong
	int *NumberOfFacesContainingTheVertex;

	int		m_nNumFaces;
	// Estado de los muelles que unen cada punto en estado de reposo
	//! State of the wharves that join every point in condition of rest
	POINT3* m_paSpins;		
	// Esta copia es necesaria en el proceso de corte total
	//! This copy of "m_paSpins" is needed in the process of total cut
	POINT3* m_paCopySpins;	
	// Caras que forman la T2
	//vtkFace*   m_pFaces;			
	//! Faces that form the T2-Mesh
	vtkEsquiFaceCollection* m_pFaces;
	// Usados para restablecer la malla original T2
	//! Used to restore the original T2-Mesh
	Point*  m_pPointOrigT2;
	// Normales de la T2
	//! Normals of the T2
	Point*  m_pNormals;		
	// Conectividades de los puntos que forman la malla T2
	//! Conextions of the points that form the T2-Mesh
	INT3*   m_panConect;		
	// Copia de las conexiones, necesario para el corte total
	//! Copy of the "m_panConect", needed for the total cut
	INT3*   m_panCopyConect;   
	// Caras adyacentes a cada punto de la T2
	//! Adjacent faces to every point of the T2-Mesh
	INT3*   m_panAdjacentFaces;		
	// Vector que marca la direcciÃ³n de la gravedad en la escena
	//! Vector that set the gravity direction in the scene
	Point   m_ptoGravityDirection;		

	// Variables de la triangulacion.
	//! Variables of the triangulation
	int		m_nNumPointsTr;
	// Variables de la triangulacion.
	//! Variables of the triangulation
	int     m_nNumTriang;
	// Los puntos con los que se trabaje.
	//! The points with which are working
	Point*	m_pTrPoints;			
	// Triangulos que forman la triangulacion
	//! Triangles that form the triangulation
	INT3*	m_panTriangles;	
	// Sirve para mantener coherencia con la lista de vertices de vtkOrgan
	// \sa vtkOrgan
	//! Support the coherence with the list of vertices of "vtkOrgan"
	//! \sa vtkOrgan
	int*	m_pnEmptyFaces;    
	// Sirve para mantener coherencia con la lista de vertices de vtkOrgan
	// \sa vtkOrgan
	//! Support the coherence with the list of vertices of "vtkOrgan"
	//! \sa vtkOrgan
	int*    m_pnVertexesCoherence;   

	int		m_nNumContacts;
	vtkDataContact* m_pFirstContact;
	vtkDataContact* m_pLastContact;
	int		m_nNumIter;
	float	m_fGravity;
	// Mide la "unidad" de corte, sirve para fijar la abertura del corte
	//! Measure the cut "unit", used to set the overture of the cut
	double  m_fCutStep;         
	// Opciones para deformar la malla
	//! Optios for deform the mess
	OpDeformation m_OpcDeform; 	
	// Indica si la T2 existe o no
	//! Indicates if the T2 exist or not
	bool	m_bExistMesh;		
	// Indica si hay un nuevo pinzamiento
	//! Indicates if there is a new grip
	bool m_bNewGrasper;			
	// Indica si se ha calculado una deformacion sin contactos
	//! Indicates if a deformation without contacts has been calculated
	bool m_bDeformSC;			

	// Determina la tension de los muelles
	/*
		Este atributo se usa para determinar, de forma dinamica, (durante el calculo de las fuerzas
		de deformacion que muelle esta excesivamente tensado y, por tanto, deberÃ­a ser cortado
	*/
	//Este atributo se usa para determinar, de forma dinÃ¡mica, (durante el cÃ¡lculo de las fuerzas
	//de deformaciÃ³n) quÃ© muelle estÃ¡ excesivamente tensado y, por tanto, deberÃ­a ser cortado
	//! Determines the tension of the spins 
	/*!
		This attribute is used to determine, if dynamical form, (during the calculation of the forces 
		of deformation) what spin is excessively tensed and, therefore, it will have to be cutted
	*/
	int m_nCutFace;
	float m_fMaxDist;

	// Busca el vÃ©rtice mÃ¡s cercano de entre los reales de la cara de contacto
	//! Search the nearest vertex between the real vertexes of the contact face
	int FindContact(int nTriangulo, Point &ptoContacto, Point &ptoVtceContacto);
	// Devuelve el contacto de ataque
	/*
		devuelve "true" si el contacto de ataque es el positivo de la cara
		devuelve "false" si el contacto de ataque es el negativo de la cara
	*/
	//! Return the attack contact
	/*!
		True if the attack contact is the positive of the face
		False if the attack contact is the negative of the face
	*/
	bool ContactSide(int nTriangulo, Point &ptoPosicion);
	// Obtiene la triangulacion dual a la malla simple tipo 2 actual	
	//! Obtains the dual triangulation of the simple actual mess type 2
	void ObtainTriangulation();
	// Reobtiene la triangulacion dual a la malla simple tipo 2 actual			
	//! Reobtains the dual triangulation of the simple actual mess type 2
	void ReObtainTriangulation();
	// Calcula la fuerza que se opone a la deformacion causada por las herramientas				
	//! Calculate the opposite force to the deformation caused by the tools
	void ColisionForce();
	// Obtiene las caras adyacentes al vertice nVertex	
	//! Obtain the faces adjacents to the "nVertex" vertex 
	int Adjacents(int nVertex,INT3 anResul) const; 
	// Encuentra el triángulo que comparte Vtce1 y Vtce2 con el triÃ¡ngulo tri			
	//! Search the triangle that share the given vertex "Vtce1" and "Vtce2" with the given triangle "nTri" 
	int Neighbour(int nTri, int nVtce1, int nVtce2) const;
	// Calcula la interseccion de la arista de la cara con el plano definido por normplano y D
	//! calculates the intersection of the face's edge with the plane defined for ptoNormPlano and fD 
	Point Intersect(int nFace, int nEdge, Point &ptoNormPlano, float fD);
	// Calcula la interseccion de la arista de la cara con el plano definido por normplano y D				
	//! calculates the intersection of the face's edge with the plane defined for ptoNormPlano and fD 
	Point Intersect(Point &ptoIni, Point &ptoFin, Point &ptoNormPlano, float fD);
	// Mira si el punto intersecciÃ³n se encuentra dentro o en un extremo o en la arista de la cara
	//! Look if the intersection point is inside, in an extreme or in the edge of the face
	int NodeType(int nFace, int nEdge, Point &ptoInter);
	// Determina si el punto p esta dentro del triangulo
	/*
		Determina si el punto p esta dentro del triangulo definido por (t1, t2, t3)
		Si esta dentro, en ptoLocCoord devuelve las correspondientes coordenadas locales
	*/
	//! Determines if the "p" point is inside of the triangle defined by (t1, t2, t3)
	/*!
		Determines if the "p" point is inside of the triangle defined by (t1, t2, t3)
		If it is inside, the "ptoLocCoord" parameter contains the local coordinates
	*/
	bool InsideTriangle(Point &pto, Point &ptoTri0, Point &ptoTri1, Point &ptoTri2, Point &ptoLocCoor);
	// Determina si el punto p estÃ¡ dentro del triÃ¡ngulo definido por (t1, t2, t3)		
	//! Determines if the "p" point is inside of the triangle defined by (t1, t2, t3)
	bool InsideTriangle(Point &pto, Point &ptoTri0, Point &ptoTri1, Point &ptoTri2);
	// Busca el corte a izquierdas o derechas			
	/*
		Busca el corte a izquierdas o derechas (segun flgDir) de la cara actual (caraactual)
		Devuelve el punto de corte (pizq), la arista que corta (arista) y el tipo de corte (tipo)
	*/
	//! Search the cut to left or right
	/*!
		Search the cut to left or right (in function of flgDir parameter) of the actual face "nCaraActual".
		Return the point of cut, the edge who cuts and the type of cut
	*/
	void CalculateIntersection(int nCaraActual, Point &ptoNormPlano, float fD, Point &ptoIter, int &nEdge, int &nTipoConect,int flgDir);
	// Reequilibra una Interseccion que coincide con el nodo de una cara para que no coincida (dado que dara lugar a una cara degenerada)	
	//! Re-balances an Intersection that coincides with the node of a face in order that it does not coincide (because it will create a degenerate face) 
	void Re_BalanceIntersection(int nCaraActual, int nEdge, Point &ptoInter);
	// Obtiene la cara que esta en contacto con la cara actual a traves de arista				
	//! Obtains the face that is in touch with the current face across edge
	int ObtainNextFace(int nCaraActual, int nEdge);
	// Comprueba que nCaraSig se puede alcanzar desde nCaraAct devolviendo la arista de nCaraSig compartida.
	//! Verifies that "nCaraSig" it is possible to reach from "nCaraAct" returning the edge of "nCaraSig" shared.
	bool NextFaceEdge(int nCaraAct,int nCaraSig,int* nEdge);
	// Devuelve el tipo de cara caraactual.				
	//! Return the tipe of the face given by "nCaraActual"
	int ObtainFaceType(int nCaraActual);
	// Crea las conexiones inicial, a izquierdas y a derechas segun el flag que se le pase	como ultimo parametro
	//! Create the connections initial, to left or right in according with the "dirfinal" flag
 	void CreateConection(vtkWay *pCaminoAct, int &nNodoDer, int &nNodoIzq, Point *pNuevosNodos, 
					  Point *pNuevaTextura, INT3 *pnConexiones, int &nNumAnadidos, INT3 *pnTipoConect, 
					  POINT3 *pMuelleso, int flgDir, bool final = false, bool dirfinal = false);
				
	// Crea la ultima conexion que enlaza el primer nodo con el ultimo en un corte	total de superficie continua
	//! Create the last connection that link the first node with the last in a total cut of continue surface
	void CreateFinalConection(vtkWay* pIntersecciones,int nNodoDerIni, int nNodoIzqIni, int nNodoDer, int nNodoIzq, 
						   int nNumAnadidos,INT3 *pnConexiones, POINT3 *pMuelleso);
	// Este procedimiento libera toda la memoria eliminando la informacion actual sobre la malla   
	//! Liberate the memory and destroy all the actual information about the mess
	void DestroyT2Mesh();
	// Realiza una copia de los muelles, copia necesaria para luego los cortes, sobre todo para el corte total
	//! Copy the spins, this copy is needed for the cuts calculation
	void CopySpinState();
	// Calcula el muelle que atraviesa una cara y que es generado durante el corte. 			
	//! Calculate the spin that cross a face and is generated during the cut
	Point SpinCalculate(vtkWay* pIntersecciones, int nIndFin, int nIndIni, int nNumNodos);
	
	vtkPolyData *DualMesh;
private:
		vtkT2Mesh(const vtkT2Mesh &);
		void operator =(const vtkT2Mesh &);

};
#endif
