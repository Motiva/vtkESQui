#ifndef __vtkEsquiLinkCollection_h
#define __vtkEsquiLinkCollection_h

#include "vtkEsquiCollection.h"
#include "vtkesquiT2MeshWin32Header.h"
class vtkLink;

//!  A list of Links
/*! 
   vtkEsquiLinksCollection represents and provides methods to manipulate a list of
   Links (i.e., vtkLink and subclasses). The list is unsorted and duplicate
   entries are not prevented.

   \sa vtkEsquiCollection, vtkLink
*/
class VTK_ESQUI_T2MESH_EXPORT vtkEsquiLinkCollection: public vtkEsquiCollection
{
 public:
  static vtkEsquiLinkCollection *New();
  vtkTypeRevisionMacro(vtkEsquiLinkCollection,vtkEsquiCollection);
  virtual void PrintSelf(ostream& os, vtkIndent indent);

  //! Add a Link to the list.
  vtkIdType Append(vtkLink *object);
  //! Returns the Link on i position.
  vtkLink *Item(vtkIdType i);
  //! Returns the first Link on i position.
  vtkLink *GetFirst();
  //! Returns the position of link.
  virtual vtkIdType Find(vtkLink *object);
  //! Returns the position of link.
  virtual vtkIdType IndexOf(vtkLink *object);

protected:
  vtkEsquiLinkCollection() {};
  ~vtkEsquiLinkCollection() {};


private:
  vtkEsquiLinkCollection(const vtkEsquiLinkCollection&);  // Not implemented.
  void operator=(const vtkEsquiLinkCollection&);		  // Not implemented.
};


#endif
