/*
--------------------
Program: ESQUI
Info and Bugs: {marf,rsantana}@ctm.ulpgc.es 
-------------------------------------------

Copyright (c) 2006, Center for Technology in Medicine, University of Las Palmas
de Gran Canaria (Canary Islands, Spain).
All rights reserved.

This program is free software; you can redistribute it and/or modify it under 
the terms of the Creative Commons' "by-attribution" license 
(http://creativecommons.org/licenses/by/2.5).

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1) Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright 
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
=============================================================================*/

#include "vtkT2Mesh.h"

#include <math.h>
#include <stdlib.h> 
#include <stdio.h> 
#include <iostream>
#include <float.h>	
#include "vtkMultiThreader.h"
#include "vtkIdListCollection.h"

#define numprocs 2

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <process.h>
#else
#include <semaphore.h>
#endif

#ifdef _SOLARIS_
/* Must be a Sun machine */
#include <thread.h>
#endif

using namespace std;
//Estructura a pasar a los threads, que contiene los 
//punteros a todas las variables necesarias
struct sThreadData{
	int ThreadID;
	int iter;
	vtkT2Mesh* Malla;
};

#ifdef _WIN32
HANDLE hRunSemaphore[numprocs];
#else
sem_t hRunSemaphore[numprocs];
#endif
//Manejadores de los semÃ¡foros
// HANDLE hRunSemaphore[numprocs];

//CÃ³digo a ejecutar por los threads-----------------------------------------------------
VTK_THREAD_RETURN_TYPE CodigoThread( void *arg )
 {
    
    vtkT2Mesh* This;
	int				inicio,fin,pto;
	int             threadId;
    int             threadCount;
	Point			ptoAux;
	double			*ptAux = new double[3];
	float			fCompensacion;

   threadId    = ((ThreadInfoStruct *)(arg))->ThreadID;
   threadCount = ((ThreadInfoStruct *)(arg))->NumberOfThreads;
 
   This = (vtkT2Mesh *)(((ThreadInfoStruct *)(arg))->UserData);
 
   //Obtenemos el punto inicial y final que debe calcular el thread--------------------
	if (threadId>0)
		//inicio=(This->m_nNumPointsT2/numprocs)*(threadId)+1;
		inicio=(This->VertexConection->GetNumberOfItems()/numprocs)*(threadId)+1;
	else
		inicio=0;
	
	if (threadId==numprocs-1)
		fin=This->VertexConection->GetNumberOfItems()-1;
	else
		fin=(This->VertexConection->GetNumberOfItems()/numprocs)*(threadId+1);
	//-----------------------------------------------------------------------------------
	
	for(char j = 0; j < 1; j++){

	//Realizamos los calculos de la deformaciÃ³n
	for(pto = inicio; pto <= fin; pto++){
			if(!This->Grasped(pto)){ // Esta función siempre devuelve el valor "false"
				if((This->m_pnPointType[pto] == POINTTYPE_DEFORMABLE) && (This->m_pnPointState[pto] != CLIPPED_STATE) && 
					(This->m_pnPointState[pto] != LINKEDSECUNDARY_STATE) && (This->m_pnPointState[pto] != LINKEDSECUNDARYARMONIC_STATE))
				{
					if (This->m_panConectionType[pto][0] == UNREAL_EDGE ||
						This->m_panConectionType[pto][1] == UNREAL_EDGE ||
						This->m_panConectionType[pto][2] == UNREAL_EDGE )
						fCompensacion = 0.66f;
					else
						fCompensacion=1.0f;

					ptoAux = This->m_pPointsT2[pto];

					This->InternalForceCalculation(pto,fCompensacion);
					This->m_pPrevPointT2[pto] = ptoAux;
					
					This->CenterDisplacementX[pto] = This->CenterDisplacementX[pto] + (ptoAux.x - This->m_pPointsT2[pto].x);
					This->CenterDisplacementY[pto] = This->CenterDisplacementY[pto] + (ptoAux.y - This->m_pPointsT2[pto].y);
					This->CenterDisplacementZ[pto] = This->CenterDisplacementZ[pto] + (ptoAux.z - This->m_pPointsT2[pto].z);
				}
			}
	}
		if(!This->m_lpLinks->IsEmpty())
			This->LinksPositionCalculation();
	}

   //Liberamos el semÃ¡foro--------------------------------------------------------------
	#ifdef _WIN32
	ReleaseSemaphore(hRunSemaphore[threadId], 1, NULL);
	#else
	sem_post(&hRunSemaphore[threadId]);
	#endif
	
	//-----------------------------------------------------------------------------------
   return VTK_THREAD_RETURN_VALUE;
 
 }

#include "vtkLink.h"
#include "vtkFace.h"
#include "vtkObjectFactory.h"
#include "vtkEsquiFaceCollection.h"
#include "vtkCellArray.h"
//---------------------------------------------------------------------------------------
vtkCxxRevisionMacro(vtkT2Mesh, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkT2Mesh);

vtkT2Mesh::vtkT2Mesh() 
{
//Constructor por defecto
	m_nNumPointsTr = m_nNumPointsT2 =0;
	m_nNumTriang = m_nNumFaces = 0;
	m_bExistMesh = false; 
	m_pFirstContact = m_pLastContact = NULL;
	m_nNumContacts = 0;
	m_nNumIter = 4;
	m_OpcDeform.inct = 1.0f / ((float)m_nNumIter * 15.0f);
	m_nNumClips = 0;
	m_fGravity = -0.0f;// / (float)m_dScale;  /*VALOR DEPENDIENTE DEL FACTOR DE ESCALA*/
	m_fCutStep = 0.0f;
	m_bNewGrasper = false;
	m_bDeformSC = false;
	m_nCutFace = -1;
	m_fMaxDist = -1.0f;
	this->m_pFaces = vtkEsquiFaceCollection::New();
	this->DualMesh = vtkPolyData::New();
}

vtkT2Mesh::~vtkT2Mesh(){
	int i;

// Print(cout);
	/*for(i = 0; i < m_nNumContacts; i++){
		ReleaseContact(i);
	}*/
	/*if (m_nNumPointsTr>0){
					  delete[] m_pTrPoints;
					  delete[] m_pnEmptyFaces;
					  delete[] m_pnVertexesCoherence;
	}
	if (m_nNumPointsT2>0){
					  delete[] m_pPointsT2;
					  delete[] m_pPrevPointT2;
					  delete[] m_pnPointType; delete[] m_pnPointState;
					  delete[] m_pTextureT2;
					  delete[] m_panConect;
					  delete[] m_panConectionType;
					  delete[] m_panAdjacentFaces;
					  delete[] m_pPointOrigT2;
					  delete[] m_pNormals;
					  delete[] m_paSpins;
					  delete[] m_pbUnstable;
	}
	if (m_nNumClips > 0){
		m_nNumClips = 0;
	}
	if (m_nNumTriang>0) 
		delete[] m_panTriangles; 
	if (m_nNumFaces > 0) {
		m_pFaces->DeleteAll();
		m_pFaces->Delete();
	}

	delete[] m_paCopySpins;
	delete[] m_panCopyConect;
	delete[] CenterDisplacementX;
	delete[] CenterDisplacementY;
	delete[] CenterDisplacementZ;
	delete[] NumberOfFacesContainingTheVertex;
*/
}

	
int vtkT2Mesh::Adjacents(int nVertex,INT3 anResul) const{
//Obtiene las caras T2 adyacentes al Nodo nVertex
	int i=0;
	int nCont=0;
	
	while ( nCont<3 && i<m_nNumFaces ){        // como un nodo siempre tiene
		if ( m_pFaces->Item(i)->Contains(nVertex) ){ // 3 uniones formara parte de
			anResul[nCont]=i;				   // 3 caras de la malla T2
			nCont++;
		}
		i++;
	}
	if (nCont<3) 
		return -1;
	else 
		return 1;
};
	
int vtkT2Mesh::Neighbour(int nTri, int nVtce1, int nVtce2) const{
//Encuentra el triÃ¡ngulo que comparte la nEdge nVtce1-nVtce2 del triangulo nTri
	int i=0, nCont=0; 
	int nFace=-1;           // si no hay vecino devolvemos error

	while ( i<m_nNumTriang && nFace==-1){
		if (i != nTri){							//Para cada triangulo menos el mismo
			nCont = 0;                         
			if (m_panTriangles[i][0]==nVtce1 ||// Si tiene el vertice nVtce1
				m_panTriangles[i][1]==nVtce1 ||
				m_panTriangles[i][2]==nVtce1)
				nCont++;
			if (m_panTriangles[i][0]==nVtce2 ||// y el Vtce2 es que comparte nEdge
				m_panTriangles[i][1]==nVtce2 ||
				m_panTriangles[i][2]==nVtce2)
				nCont++;
		}
		if (nCont == 2)
			nFace=i;
		i++;	
	}
	
	return nFace;
}

void vtkT2Mesh::DestroyT2Mesh(){


	int i;

	delete[] m_pTrPoints;     // liberamos la memoria consumida por todos los 
	delete[] m_pPointsT2;   // Arrays
	delete[] m_pTextureT2;
	delete m_pPrevPointT2;
	delete[] m_pnEmptyFaces;
	delete[] m_pnVertexesCoherence;
	delete[] m_panConect; delete[] m_panConectionType; delete[] m_panAdjacentFaces;
	delete[] m_pnPointType; delete[] m_pnPointState;
	delete[] m_pPointOrigT2; delete[] m_pNormals;
	m_nNumPointsTr =0; m_nNumPointsT2 = 0;
	delete[] m_panTriangles; m_nNumTriang =0;
	m_pFaces->DeleteAll(); 
	m_nNumFaces = 0;
	delete[] m_paSpins;
	delete[] m_pbUnstable;

	for(i = 0; i < m_nNumContacts; i++)
		ReleaseContact(i);
	m_pFirstContact=m_pLastContact=NULL;
	m_nNumContacts = 0;

	if (m_nNumClips > 0){                    // liberamos las grapas
		m_nNumClips = 0;
	}



	m_bExistMesh=false;
}

void vtkT2Mesh::GetNumberOfFacesContainingEveryVertex() {
	int NumberOfVertexes;
	int NumberOfFaces;
	NumberOfVertexes = (int)this->vtkPolyData::GetNumberOfPoints();
	vtkIdType VertexId;
	int i, j;
	this->NumberOfFacesContainingTheVertex = new int[NumberOfVertexes*3];
	for (i = 0; i < NumberOfVertexes; i++) {
		this->NumberOfFacesContainingTheVertex[i] = 0;
	}
	NumberOfFaces = this->GetNumberOfCells();
	this->CenterDisplacementX = new double[NumberOfFaces*3];
	this->CenterDisplacementY = new double[NumberOfFaces*3];
	this->CenterDisplacementZ = new double[NumberOfFaces*3];
	for (i = 0;  i < NumberOfFaces*3; i++) {
		this->CenterDisplacementX[i] = 0;
		this->CenterDisplacementY[i] = 0;
		this->CenterDisplacementZ[i] = 0;
	}

	for (i = 0; i < NumberOfFaces; i++) {
		for (j = 0; j < 3; j++) {
			VertexId= this->GetCell(i)->GetPointIds()->GetId(j);
			this->NumberOfFacesContainingTheVertex[VertexId] = this->NumberOfFacesContainingTheVertex[VertexId] + 1; 
		}
	}
}

void vtkT2Mesh::CalculateNewVertexesPosition() {
	int NumberOfPolygons = this->GetNumberOfPolys();
	vtkIdType v1,v2,v3;
	vtkPoints* vertices;
	vertices = this->GetPoints();

	for (int i = 0; i < NumberOfPolygons; i++) {
		v1= this->GetCell(i)->GetPointIds()->GetId(0);
		v2= this->GetCell(i)->GetPointIds()->GetId(1);
		v3= this->GetCell(i)->GetPointIds()->GetId(2);
	
		if ((this->CenterDisplacementX[i] < 1) && (this->CenterDisplacementX[i] > -1) && (this->CenterDisplacementY[i] < 1)&& (this->CenterDisplacementY[i] > -1) &&  (this->CenterDisplacementZ[i] < 1)&& (this->CenterDisplacementZ[i] > -1) ) {
			//VertexPosition = VertexPosition + (Displacement Of The Center Of This Face / Number Of Faces That Contains this vertex)
			vertices->SetPoint(v1, (vertices->GetPoint(v1)[0] + (this->CenterDisplacementX[i]/this->NumberOfFacesContainingTheVertex[v1])), (vertices->GetPoint(v1)[1] + (this->CenterDisplacementY[i]/this->NumberOfFacesContainingTheVertex[v1])), (vertices->GetPoint(v1)[2] + (this->CenterDisplacementZ[i]/this->NumberOfFacesContainingTheVertex[v1])));
			vertices->SetPoint(v2, (vertices->GetPoint(v2)[0] + (this->CenterDisplacementX[i]/this->NumberOfFacesContainingTheVertex[v2])), (vertices->GetPoint(v2)[1] + (this->CenterDisplacementY[i]/this->NumberOfFacesContainingTheVertex[v2])), (vertices->GetPoint(v2)[2] + (this->CenterDisplacementZ[i]/this->NumberOfFacesContainingTheVertex[v2])));
			vertices->SetPoint(v3, (vertices->GetPoint(v3)[0] + (this->CenterDisplacementX[i]/this->NumberOfFacesContainingTheVertex[v3])), (vertices->GetPoint(v3)[1] + (this->CenterDisplacementY[i]/this->NumberOfFacesContainingTheVertex[v3])), (vertices->GetPoint(v3)[2] + (this->CenterDisplacementZ[i]/this->NumberOfFacesContainingTheVertex[v3])));
		}
	}
}


void vtkT2Mesh::PrepareSimulation(){
	int i,j,k;				// variables generales para el recorrido
	bool bResul=false, bCerrado= false;
	bool bSalir;
	int nNodoAnt,nSig;
	int nEntradoPor,nIndConect;
	BOOL3* abMarcado;
	INT3 anAdy;     
	int nNumPtosLimite;						// numero de nodos que marcan el final de la geometria         
	vtkNodeLimT2* pLimPrim,*pLimAct,*pLimAux;  // para tratar los puntos limite de la T2

	int nNumPtosT2;				 // Variables que hacen una copia de la T2 Mesh por si
	Point* pPtosT2, *pPtosAntT2; // hay algun error y hay que restaurar
	INT3*  panConect, *panTipoConect;
	int *pnTipoPto, *pnEstadoPto;

	int nNumLinks;           // bloque de variables necesarias para la union de tejidos
	vtkLink *pLinkado;
	Point ptoCercaPrimario;
	Point ptoNodoInicial;
	float afNodoInicial[3];
	unsigned int nNodoTrinicial, nNodoPrimario;
	float fDist, fDistMin;
	Point *pTextura;	//Lista para la lectura de de coordenadas de textura. 
	this->VertexConection = vtkIdListCollection::New();
	this->InitialInternalForce = vtkIdListCollection::New();
	
	LoadBoundaryConditions();    // lo primero es cargar las condiciones de contorno
	GetNumberOfFacesContainingEveryVertex(); // Se obtiene el número de caras a las que pertenece cada vertice de la malla

	if (m_bExistMesh)
		DestroyT2Mesh();
 
	switch(m_yDirOfGravity){
		case 0: m_ptoGravityDirection = Point(1,0,0); break;
		case 1: m_ptoGravityDirection = Point(0,1,0); break;
		case 2: m_ptoGravityDirection = Point(0,0,1); break;
	}
	m_ptoGravityDirection = m_ptoGravityDirection * (float)m_cOrientOfGravity;

	m_nNumPointsTr = m_uNNodes;
	m_pTrPoints = (Point *)new Point[m_nNumPointsTr];
	pTextura = (Point *)new Point[m_nNumPointsTr];

	for(i = 0; i < m_nNumPointsTr; i++){
		m_pTrPoints[i].x = m_afCurrentCoord[i*3 + 0];
		m_pTrPoints[i].y = m_afCurrentCoord[i*3 + 1];
		m_pTrPoints[i].z = m_afCurrentCoord[i*3 + 2];
	}	 

	m_nNumTriang = m_uNEl;
	m_panTriangles = (INT3 *)new INT3[m_nNumTriang];
	for(i = 0; i < m_nNumTriang; i++)
		for(j = 0; j < 3; j++)
		{
			m_panTriangles[i][j] = m_auNodePtr[i*3 + j];
			pTextura[m_panTriangles[i][j]].x = m_afTextureCoord[(i*3 + j)*3 + 0];
			pTextura[m_panTriangles[i][j]].y = m_afTextureCoord[(i*3 + j)*3 + 1];
			pTextura[m_panTriangles[i][j]].z = m_afTextureCoord[(i*3 + j)*3 + 2];
		}

	m_nNumPointsT2 = m_nNumTriang;					// cada punto T2 es el centro de un triangulo
	m_pPointsT2 = new Point[m_nNumPointsT2];
	m_pPrevPointT2 = new Point[m_nNumPointsT2];
	m_pPointOrigT2 = new Point[m_nNumPointsT2];
	m_pnPointType = new int[m_nNumPointsT2];
	m_pnPointState = new int[m_nNumPointsT2];
	m_pTextureT2 = new Point[m_nNumPointsT2];
	m_pbUnstable = new bool[m_nNumPointsT2];

	/////////////////////////////////////////////////////////////////////////////////
	// Generamos la malla dual, sobre la que se realizarán los cálculos
	this->BuildCells();
	this->BuildLinks();
	vtkCell *ActualCell;
	vtkCell *ActualEdge;
	vtkIdList *EdgeIds;
	vtkIdList *CellsContainingTheVertex;
	vtkIdList *CellNeighbors = vtkIdList::New();
	int SbId;
	bool IsLimit;
	double X[3];
	double pcoords[3];
	double *Weigths = new double[this->GetMaxCellSize()];
	CellsContainingTheVertex = vtkIdList::New();
	vtkIdListCollection *VertexOfEveryCell = vtkIdListCollection::New();
	vtkIdList *VertexOfActualCell = vtkIdList::New();
	this->DualMeshPoints = vtkPoints::New();
	this->DualLimitPoints = vtkPoints::New();
	vtkIdList *ActualVertexConection;
	//VertexOfEveryCell = new vtkIdList[this->GetNumberOfCells()];
	// Primero recorremos las caras de la malla representada para obtener los vértices de la malla dual
	for (i = 0; i < this->GetNumberOfCells(); i++) {
		IsLimit = false;
		ActualVertexConection = vtkIdList::New();
		ActualCell = this->GetCell(i);
		if (ActualCell->GetNumberOfEdges() != 3) {
			// Error inicializando la malla, hay celdas que no son triangulares.
			return;
		}
		// Cada cara de la malla representada en la escena genera una serie de puntos de la malla dual
		// estos son el centro de la cara y los límites en el caso de que la cara ocupe un limite de la malla representada.
		// Los identificadores de los vertices generados por cada cara se almacenan en el objeto vtkIdList

		//Obtenemos el centro de cada cara de la malla
		SbId = ActualCell->GetParametricCenter(pcoords);
		ActualCell->EvaluateLocation(SbId, pcoords, X, Weigths);
		VertexOfActualCell = vtkIdList::New();
		VertexOfActualCell->InsertNextId(this->DualMeshPoints->InsertNextPoint(X));
		//Ahora miramos si esta cara es un límite de la malla, para obtener los correspondientes puntos limite
		for (int l = 0; l < 3; l ++) {
			ActualEdge = ActualCell->GetEdge(l);
			EdgeIds = ActualEdge->GetPointIds();

			this->GetCellEdgeNeighbors(i, EdgeIds->GetId(0), EdgeIds->GetId(1), CellNeighbors);
			if (CellNeighbors->GetNumberOfIds() == 0) {
				SbId = ActualEdge->GetParametricCenter(pcoords);
				ActualEdge->EvaluateLocation(SbId, pcoords, X, Weigths);
				VertexOfActualCell->InsertNextId(this->DualLimitPoints->InsertNextPoint(X));
				IsLimit = true;
			} else {
				// Si no es un límite, el identificador correspondiente a esta arista apunta a -1.
				// Estos indentificadores se emplearán luego para la creación de las caras del polydata.
				VertexOfActualCell->InsertNextId(-1);
			}
			// Creamos la lista de los enlaces del punto central
			// Si el punto central es un limite no se tiene en cuenta para los cálculos (de momento)
			if (IsLimit == false) {
				ActualVertexConection->InsertNextId(CellNeighbors->GetId(0));	
				
			}
		}
		this->VertexConection->AddItem(ActualVertexConection);
		VertexOfEveryCell->AddItem(VertexOfActualCell);
		VertexOfActualCell->Delete();
	}
	this->DualMesh->SetPoints(this->DualMeshPoints);
	this->PreviousDualMeshPoints = vtkPoints::New();
	this->PreviousDualMeshPoints->DeepCopy(this->DualMeshPoints);

	//Calculo de las fuerzas internas de la malla
	
	//Después de obtener todos los vertices de la malla dual, pasamos a generar las caras 
	vtkCellArray *DualMeshCells = vtkCellArray::New();
	vtkIdList *VertexOfTheDualCell;
	int FirstEdge, LastEdge;
	bool FirstEdgeObtained;
	for (i = 0; i < this->GetNumberOfPoints(); i++) {
		VertexOfTheDualCell = vtkIdList::New();
		this->GetPointCells(i, CellsContainingTheVertex);
		// Recorremos cada una de las caras de la malla representada y vemos cuántos puntos de la malla dual
		// son debidos a cada una de las caras a las que pertenece el punto
		int MeshFaceId;
		for (int l = 0; l < CellsContainingTheVertex->GetNumberOfIds(); l++) {
		//int l = 0;
		//while (0 < CellsContainingTheVertex->GetNumberOfIds()){
			MeshFaceId = CellsContainingTheVertex->GetId(l);
			VertexOfActualCell = VertexOfEveryCell->GetItem(MeshFaceId);
			ActualCell = this->GetCell(MeshFaceId);
			FirstEdgeObtained = false;
			// Ahora busco las aristas de la cara a las que pertenece el vertice bajo estudio.
			for (int n  = 0; n < 3; n++) {
				ActualEdge = ActualCell->GetEdge(n);
				EdgeIds = ActualEdge->GetPointIds();
				// Obtenemos las aristas a las que pertenece el vértice ordenadas en sentido antihorario
				if (EdgeIds->GetId(0) == i) {
						FirstEdge = n;
				} else {
					if (EdgeIds->GetId(1) == i )
						LastEdge = n;
				}
			}
			// Una vez detectadas las aristas a las que pertenece el vértice, miramos si son limite o si tienen una cara vecina
			if (VertexOfEveryCell->GetItem(MeshFaceId)->GetId(FirstEdge) != -1) {
				VertexOfTheDualCell->InsertNextId(VertexOfEveryCell->GetItem(MeshFaceId)->GetId(FirstEdge));
				//cout << "Añado vertice Limite " << VertexOfEveryCell->GetItem(MeshFaceId)->GetId(FirstEdge) << endl;
			}
			VertexOfTheDualCell->InsertNextId(VertexOfEveryCell->GetItem(MeshFaceId)->GetId(0));
			//cout << "Añado vertice central " << VertexOfEveryCell->GetItem(MeshFaceId)->GetId(0) << endl;
			if (VertexOfEveryCell->GetItem(MeshFaceId)->GetId(LastEdge) != -1) {
				VertexOfTheDualCell->InsertNextId(VertexOfEveryCell->GetItem(MeshFaceId)->GetId(LastEdge));
				//cout << "Añado vertice Limite " << VertexOfEveryCell->GetItem(MeshFaceId)->GetId(LastEdge) << endl;
			}
			CellsContainingTheVertex->DeleteId(l);

			// Ahora se añaden los correspondientes vertices de la malla dual a la cara que estamos componiendo
			
			if (VertexOfActualCell->GetNumberOfIds() > 1) {
			//	cout << "LIMITE" << endl;
			}
			//VertexOfTheDualCell->InsertNextId();
			//VertexOfTheDualCell->Delete();
		}
		DualMeshCells->InsertNextCell(VertexOfTheDualCell);
		this->DualMesh->SetPolys(DualMeshCells);
		this->DualMesh->BuildCells();
		this->DualMesh->BuildLinks();
		//cout << "numero de celdas que contienen el punto " << CellsContainingTheVertex->GetNumberOfIds() << endl;

	}
	// FIN DEL CÓDIGO PARA LA INTEGRACIÓN DEL MODELO BIOMECÁNICO EN VTK (JUNIO 2007)
	///////////////////////////////////////////////////////////////////////////////////

	nNumPtosLimite= 0;             // Lo primero es buscar si tenemos un cuerpo  
	pLimPrim = pLimAct = NULL;	   // cerrado o por el contrario tenemos  puntos limites
	for (i=0;i<m_nNumPointsT2;i++){  // es decir, tenemos una superficie (o agujeros)
		m_pPointOrigT2[i] = (m_pTrPoints[m_panTriangles[i][0]] +
							m_pTrPoints[m_panTriangles[i][1]] +
							m_pTrPoints[m_panTriangles[i][2]] )*(1.0f/3.0f);
		m_pTextureT2[i] =	(pTextura[m_panTriangles[i][0]] +
							pTextura[m_panTriangles[i][1]] +
							pTextura[m_panTriangles[i][2]] )*(1.0f/3.0f);
		m_pPointsT2[i] = m_pPrevPointT2[i] = m_pPointOrigT2[i];
		m_pnPointType[i] = POINTTYPE_DEFORMABLE;
		m_pnPointState[i]= FREE_STATE;
		m_pbUnstable[i] = true;
		for(j = 0; j < 3; j++)
			if(Neighbour(i, m_panTriangles[i][j], m_panTriangles[i][(j+1)%3]) == -1) {
				//cout << "LIMITE DE LA MALLA" << endl;
				// Esto es hay una nEdge del triangulo i que no es compartida por otro triangulo
				if(pLimPrim == NULL){
					//cout << "PRIMER LIMITE" << endl;
					pLimPrim = new vtkNodeLimT2;
					pLimPrim->m_PointT2 = (m_pTrPoints[m_panTriangles[i][j]] + m_pTrPoints[m_panTriangles[i][(j+1)%3]]) * 0.5f;
					pLimPrim->m_ptoTexture = (pTextura[m_panTriangles[i][j]] + pTextura[m_panTriangles[i][(j+1)%3]]) * 0.5f;
					pLimPrim->m_nFace = i;
					pLimPrim->m_anTypePoint = m_pnPointType[i];
					pLimPrim->m_anStatePoint = FREE_STATE;
					pLimPrim->m_nEdge = j;    // Las aristas se almacenan poniendo
					pLimPrim->m_nNext = NULL;    // el primer vertice teniendo en cuenta
					pLimAct = pLimPrim;         // que los poligonos se recorren antihorariamente
					nNumPtosLimite++;
				}
				else{
					pLimAct->m_nNext = new vtkNodeLimT2;
					pLimAct = pLimAct->m_nNext;
					pLimAct->m_PointT2 = (m_pTrPoints[m_panTriangles[i][j]] + m_pTrPoints[m_panTriangles[i][(j+1)%3]]) * 0.5f;					
					pLimAct->m_ptoTexture = (pTextura[m_panTriangles[i][j]] + pTextura[m_panTriangles[i][(j+1)%3]]) * 0.5f;
					pLimAct->m_nFace = i;
					pLimAct->m_anTypePoint = m_pnPointType[i];
					pLimAct->m_anStatePoint = FREE_STATE;
					pLimAct->m_nEdge = j;
					pLimAct->m_nNext = NULL;
					nNumPtosLimite++;
				}
			}
	} // terminamos de recorrer todos los puntos T2 (creandolos)
	delete[] pTextura;

	m_panConect = new INT3[m_nNumPointsT2];      // creamos ahora las pnConexiones
	m_panConectionType = new INT3[m_nNumPointsT2];  // de los puntos T2 (3 para cada uno)
	//cout << "NUMERO DE PUNTOS T2 " << m_nNumPointsT2 << endl;
	for (i=0;i<m_nNumPointsT2;i++){
	//DeterminaciÃ³n de adyacencias
		for(j = 0; j < 3; j++){
			m_panConect[i][j] = Neighbour(i,m_panTriangles[i][j],m_panTriangles[i][(j+1)%3]);
			if(m_panConect[i][j] == -1){ // si resulta que no hay conexion por que es un
				bSalir = false;			 // limite
				k = 0;
				pLimAct = pLimPrim;
				// los puntos limite seran unos puntos en medio de la nEdge del triangulo
				// que no tiene vecino, ahora suponemos que esos puntos limite a calcular
				// empiezan en -1 y crecen pero negativamente mientras que del 0 en adelante
				// tenemos los puntos T2 normales
				while((!bSalir) && (k < nNumPtosLimite)){
					if((pLimAct->m_nFace == i) && (pLimAct->m_nEdge == j)){
						m_panConect[i][j] = -(k+1);
						//cout << "PUNTERO DE CONEXIÓN " << m_panConect[i][j] << endl;
						bSalir = true;
					}
					pLimAct = pLimAct->m_nNext;
					k++;
				}

				if(!bSalir){
					 DestroyT2Mesh();
					 return;
				}
			}
			m_panConectionType[i][j] = REAL_EDGE;  // de un punto T2 a un punto Limite tambien es real
		}
	}

	pLimAct = pLimPrim;                  // Ahora establecemos las pnConexiones de los
	for(i = 0; i < nNumPtosLimite; i++){ // puntos limite, que delimitan huecos o el final
		pLimAux = pLimPrim;              // de una superficie
		pLimAct->m_anConect[0] = pLimAct->m_nFace;
		bSalir = false; j = 0; k = 0;
		
		pLimAct->m_anTypeConect[0]=REAL_EDGE;
		while(!bSalir && j<nNumPtosLimite){
			if(i != j){
				if(m_panTriangles[pLimAct->m_nFace][pLimAct->m_nEdge] == m_panTriangles[pLimAux->m_nFace][(pLimAux->m_nEdge + 1)%3]){
					//cout << "m_panTriangles" << pLimAct->m_nFace << " " << pLimAct->m_nEdge << "==" << "m_panTriangles" << pLimAux->m_nFace << " " << (pLimAux->m_nEdge + 1)%3 << endl;
					pLimAct->m_anConect[1] = -(j+1);
					//cout << "HOLE_EDGE" << endl;
					pLimAct->m_anTypeConect[1] = HOLE_EDGE;
					if(k == 2)
						bSalir = true;
					else
						k=1;
				}
				if(m_panTriangles[pLimAct->m_nFace][(pLimAct->m_nEdge + 1)%3] == m_panTriangles[pLimAux->m_nFace][pLimAux->m_nEdge]){
					pLimAct->m_anConect[2] = -(j+1);
					//cout << "m_panTriangles" << pLimAct->m_nFace << " " << (pLimAct->m_nEdge + 1)%3 << "==" << "m_panTriangles" << pLimAux->m_nFace << " " << pLimAux->m_nEdge << endl;
					//cout << "REAL_EDGE" << endl;
					pLimAct->m_anTypeConect[2] = REAL_EDGE;
					if(k == 1)
						bSalir = true;
					else
						k=2;
				}
			}
			pLimAux = pLimAux->m_nNext;
			j++;
		}
		if(!bSalir){
			DestroyT2Mesh();
			return;
		}
		pLimAct = pLimAct->m_nNext;
	}

	if(nNumPtosLimite > 0){			// en vista que hay limites, hacemos una copia de seguridad de lo que
		nNumPtosT2 = m_nNumPointsT2;  // porque vamos a fusionar las dos listas
		pPtosT2= new Point[nNumPtosT2];
		pPtosAntT2=new Point[nNumPtosT2];
	    panConect=new INT3[nNumPtosT2];
		panTipoConect=new INT3[nNumPtosT2];
		pnTipoPto=  new int[nNumPtosT2];
		pnEstadoPto=new int[nNumPtosT2];
		pTextura = new Point[nNumPtosT2];
		for(i = 0; i < nNumPtosT2; i++){
			pPtosT2[i] = m_pPointsT2[i];
			pTextura[i] = m_pTextureT2[i];
			pPtosAntT2[i] = m_pPrevPointT2[i];
			pnTipoPto[i] = m_pnPointType[i];
			pnEstadoPto[i] = m_pnPointState[i];
			for(k = 0; k < 3; k++){
				panTipoConect[i][k] = m_panConectionType[i][k];  // Ahora nos quitamos lo de los indices negativos
				if(m_panConect[i][k] < 0)                     // para pnConexiones con puntos limite
					panConect[i][k] = -m_panConect[i][k] + nNumPtosT2 - 1;
				else
					panConect[i][k] = m_panConect[i][k];
			}
		}

		delete[] m_pPointsT2; delete[] m_pPrevPointT2; delete[] m_panConect; // borramos la informacion que
		delete[] m_panConectionType; delete[] m_pnPointType;                  // teniamos hasta ahora de la T2
		delete[] m_pnPointState; delete[] m_pTextureT2;                   // porque tenemos copia
		delete[] m_pbUnstable;	//de este no tenemos copia de seguridad dado que
								//iniclamente todos los nodos son inestables
								//la evoluciÃ³n determinarÃ¡ si cambia el estado o no.

		m_nNumPointsT2 = nNumPtosT2 + nNumPtosLimite;
		m_pPointsT2 = (Point *)new Point[m_nNumPointsT2];
		m_pPrevPointT2 = (Point *)new Point[m_nNumPointsT2];
		m_pTextureT2 = (Point *)new Point[m_nNumPointsT2];
		m_pnPointType = (int *)new int[m_nNumPointsT2];
		m_pnPointState = (int *)new int[m_nNumPointsT2];
		m_pbUnstable = (bool *)new bool[m_nNumPointsT2];
		m_panConectionType = (INT3 *)new INT3[m_nNumPointsT2];
		m_panConect = (INT3 *)new INT3[m_nNumPointsT2];

		for(i = 0; i < nNumPtosT2; i++){    // comenzamos la fusion de en una sola lista de puntos T2
			m_pPointsT2[i] = pPtosT2[i];
			m_pPrevPointT2[i] = pPtosAntT2[i];
			m_pTextureT2[i] = pTextura[i];
			m_pnPointType[i] = pnTipoPto[i];
			m_pnPointState[i] = pnEstadoPto[i];
			m_pbUnstable[i] = true;
			for(k = 0; k < 3; k++){
				m_panConectionType[i][k] = panTipoConect[i][k];
				m_panConect[i][k] = panConect[i][k];
			}
		}
		delete[] pPtosT2;         // Ya hemos terminado la fusion, ahora ya solo hay
		delete[] pPtosAntT2;      // una lista de nodos de la T2, primero aquellos que no
		delete[] panConect;       // son puntos limite
		delete[] panTipoConect;
		delete[] pnTipoPto;
		delete[] pnEstadoPto;
		delete[] pTextura;

		pLimAct = pLimPrim;       // copiamos la informacion sobre las pnConexiones de los limites
		for(i = nNumPtosT2; i < m_nNumPointsT2; i++){
			m_pPrevPointT2[i] = m_pPointsT2[i] = pLimAct->m_PointT2;
			m_pTextureT2[i] = pLimAct->m_ptoTexture;
			m_pnPointType[i] = pLimAct->m_anTypePoint; 
			m_pnPointState[i] = pLimAct->m_anStatePoint;
			m_pbUnstable[i] = true;
			for(k = 0; k < 3; k++){
				m_panConectionType[i][k] = pLimAct->m_anTypeConect[k];
				if(pLimAct->m_anConect[k] < 0)
					m_panConect[i][k] = -pLimAct->m_anConect[k] + nNumPtosT2 - 1;
				else
					m_panConect[i][k] = pLimAct->m_anConect[k];
			}
			pLimAct = pLimAct->m_nNext;
		}
	
		pLimAct = pLimPrim;       // Borramos la lista de puntos limite
		for(i = 0; i < nNumPtosLimite; i++){ 
			pLimAct = pLimAct->m_nNext;
			pLimPrim->Delete();
			pLimPrim = pLimAct;
		}
	}

	for(i = 0; i < m_nNumPointsTr; i++){  // Ahora fijamos aquellos nodos 
		if(m_acFixed[i]){				// indicados en las condiciones de contorno
			ptoNodoInicial = m_pTrPoints[i];
			fDistMin = -1.0f;
			for(j = 0; j < m_nNumPointsT2; j++){
				fDist = (ptoNodoInicial - m_pPointsT2[j]).Module();
				if((fDist < fDistMin) || (fDistMin < 0.0f)){
					fDistMin = fDist;
					nNodoPrimario = j;
				}
			}
			m_pnPointType[nNodoPrimario] = m_pnPointType[nNodoPrimario] | m_acFixed[i];
		}
	}

	nNumLinks = m_lpLinks->GetCount();
	if(nNumLinks > 0){								// Pasamos de la informacion inicial
												     // que tienen los links, buscando siempre
		for(i = 0; i < nNumLinks; i++){             // los puntos T2 mas cercanos.
			pLinkado = m_lpLinks->Item(i);
			fDistMin = -1;
			pLinkado->GetLinkData(this, &nNodoTrinicial);
			ptoNodoInicial = m_pPointsT2[nNodoTrinicial];
			for(j = 0; j < m_nNumTriang; j++){
				fDist = (ptoNodoInicial - m_pPointsT2[j]).Module();
				if(fDist < fDistMin || fDistMin < 0.0f){
					if ((m_pnPointState[j] != LINKEDPRIMARY_STATE && pLinkado->IsPrimary(this)) ||
						(m_pnPointState[j] != LINKEDSECUNDARY_STATE && !pLinkado->IsPrimary(this))){
						fDistMin = fDist;
						nNodoPrimario = j;
					}
				}
			}
			for(j = 0; j < 3; j++)
				afNodoInicial[j] = m_pPointsT2[nNodoPrimario][j];
			pLinkado->SetLinkData(this, nNodoPrimario, afNodoInicial);
			if(fDistMin >= 0.0f)
				if (pLinkado->IsPrimary(this))
					m_pnPointState[nNodoPrimario] = LINKEDPRIMARY_STATE;
				else
					m_pnPointState[nNodoPrimario] = LINKEDSECUNDARY_STATE;

		}
	}

	abMarcado = new BOOL3[m_nNumPointsT2];
	for (i=0;i<m_nNumPointsT2;i++){
		abMarcado[i][0]=FALSE;
		abMarcado[i][1]=FALSE;
		abMarcado[i][2]=FALSE;
	}
	m_pFaces->CreateNodes(3*m_nNumPointsT2);
	m_nNumFaces = 0;
	for (i=0;i<m_nNumPointsT2;i++){ //CreaciÃ³n de las caras.
		for (j=0;j<3;j++){
			if (!abMarcado[i][j]){
				m_pFaces->Item(m_nNumFaces)->numVertex = 0;
				nNodoAnt = i; nSig = -1; nEntradoPor = -1; bCerrado = false;
				nIndConect = j;
				abMarcado[nNodoAnt][nIndConect] = TRUE;
				while (!bCerrado){
					nSig = m_panConect[nNodoAnt][nIndConect];
					if (m_panConect[nSig][0]==nNodoAnt)  // nEntradoPor indica porque       \ /
						nEntradoPor=0;                   // enlace entras y es necesario     |
					else                                 // para el recorrido correcto en sentido antihorario
						if (m_panConect[nSig][1]==nNodoAnt) 
							nEntradoPor=1;
						else
							if (m_panConect[nSig][2]==nNodoAnt) 
								nEntradoPor=2;
					m_pFaces->Item(m_nNumFaces)->AddVertex(nSig);
					nIndConect = (nEntradoPor+2)%3;
					if (abMarcado[nSig][nIndConect])
						bCerrado = true;
					else{
						abMarcado[nSig][nIndConect]=TRUE;
						nNodoAnt = nSig;
					}
				}
				m_nNumFaces++;
			}
		}
	}
	delete[] abMarcado;

	m_pNormals = (Point *)new Point[m_nNumPointsT2];
	m_panAdjacentFaces = (INT3 *)new INT3[m_nNumPointsT2];
	for (i=0;i<m_nNumPointsT2;i++){
		//Calculo de las normales de los puntos y sus m_pFaces adyacentes.
		if (Adjacents(i,anAdy)>0){
			m_pNormals[i] = ( m_pFaces->Item(anAdy[0])->normal(m_pPointsT2)+
				m_pFaces->Item(anAdy[1])->normal(m_pPointsT2)+
							m_pFaces->Item(anAdy[2])->normal(m_pPointsT2))*(1.0f/3.0f);
			m_panAdjacentFaces[i][0]=anAdy[0];
			m_panAdjacentFaces[i][1]=anAdy[1];
			m_panAdjacentFaces[i][2]=anAdy[2];
		}
		else{
			DestroyT2Mesh();
			return;
		}
	}
	//Fin del cÃ¡lculo de la malla dual.
	//Empezamos con el cÃ¡lculo de las fuerzas internas
	m_paSpins = new POINT3[m_nNumPointsT2];
	m_paCopySpins = new POINT3[m_nNumPointsT2];
	m_panCopyConect = new INT3[m_nNumPointsT2];
	for(i = 0; i < m_nNumPointsT2; i++)
		for(j = 0; j < 3; j++){
			m_paSpins[i][j] = m_pPointsT2[i] - m_pPointsT2[m_panConect[i][j]];
			m_paCopySpins[i][j]=m_paSpins[i][j];
			m_panCopyConect[i][j]=m_panConect[i][j];
		}

	//Termina el cÃ¡lculo de los coeficientes de fuerzas internas
	
	ObtainTriangulation();

	m_bExistMesh = true;
	m_bDeformed = true;
	m_bNewVertices=true;



	
}

void vtkT2Mesh::CopySpinState(){
	int i,j;

	// Este metodo borra la informacion anterior de la copia y reserva nuevamente
	// la memoria necesaria
	delete[] m_paCopySpins;
	delete[] m_panCopyConect;
	m_paCopySpins=new POINT3[m_nNumPointsT2];
	m_panCopyConect=new INT3[m_nNumPointsT2];
	for (i=0;i<m_nNumPointsT2;i++)
		for (j=0;j<3;j++){
			m_paCopySpins[i][j]=m_paSpins[i][j];
			m_panCopyConect[i][j]=m_panConect[i][j];
			if((m_panConect[i][j] > 10000) || (m_panConect[i][j] < -10000))
				i = i;
		}
}

int vtkT2Mesh::FindContact(int nTriangulo, Point &ptoContacto, Point &ptoVtceContacto){
	//Busca el vÃ©rtice mÃ¡s cercano de entre los T2 de la nFace inicial de contacto
	// basta con pasar solo dos coordenadas de contacto locales porque las tres deben 
	// sumar 1
	int i, nNumVtces, nVtceMax = -1, nCaraT2;
	float fDist, fDistMin; 

	nCaraT2 = m_panTriangles[nTriangulo][0];  // crearemos siempre la lista de triangulos de 
	nNumVtces = m_pFaces->Item(nCaraT2)->numVertex; // forma que el primer vertice indique siempre el
						                       // numero de la nFace del cual es centro

	fDistMin = -1;
	for(i = 0; i < nNumVtces; i++)
	{
		if(m_pnPointType[(*(m_pFaces->Item(nCaraT2)))[i]] == POINTTYPE_DEFORMABLE)   		
		{
			fDist = (ptoContacto - m_pPointsT2[(*(m_pFaces->Item(nCaraT2)))[i]]).Module();
			if(fDist < fDistMin || fDistMin == -1)
			{
				fDistMin = fDist;
				nVtceMax = (*(m_pFaces->Item(nCaraT2)))[i];
			}
		}
	}

	if(!Touched((*(m_pFaces->Item(nCaraT2)))[nVtceMax]))   // si no hay ya otro contacto en esta nFace
	{

		return nVtceMax;
	}
	return -1;
}



bool vtkT2Mesh::ContactSide(int nTriangulo, Point &ptoPosicion){
//devuelve "true" si el contacto de ataque es el positivo de la nFace
//devuelve "false" si el contacto de ataque es el negatibo de la nFace
	Point ptoCoord1, ptoCoord2, ptoCoord3;
	Point ptoNormPlano;
	double fD, fValor;

	ptoCoord1 = m_pFaces->Item(m_panTriangles[nTriangulo][0])->Center(m_pPointsT2);
	ptoCoord2 = m_pTrPoints[m_panTriangles[nTriangulo][1]];
	ptoCoord3 = m_pTrPoints[m_panTriangles[nTriangulo][2]];
	ptoNormPlano = (ptoCoord2-ptoCoord1)^(ptoCoord3-ptoCoord1);
	fD = -(ptoNormPlano*ptoCoord1);

	fValor = ptoPosicion*ptoNormPlano + fD;
	if(fValor > 0.0)
		return true;
	else
		return false;
}



int vtkT2Mesh::PartialCapture(const unsigned int uElementoComienzo, float *ptoElementoComienzo, const unsigned int uElementoFinal, float *ptoElementoFinal, float *pfVector){
	// Este mÃ©todo obtiene los nodos implicados en un pinzamiento parcial y
	// los almacena en una estructura del tipo PinzaTotal y los aÃ±ade a la
	// lista de pinzas (el primer elemento estÃ¡ apuntado por m_pPrimPinza

	
	return -1;


}



int vtkT2Mesh::TotalCapture(unsigned uElementoComienzo, float *ptoElementoComienzo, float *pfVector){
	// Este mÃ©todo obtiene los nodos implicados en un pinzamiento total y
	// los almacena en una estructura del tipo PinzaTotal y los aÃ±ade a la
	// lista de pinzas (el primer elemento estÃ¡ apuntado por m_pPrimPinza

	return -5;

}



void vtkT2Mesh::AddContact( vtkContactPoint* c_pContact ){
	//AÃ±ade un nuevo punto de contacto a la malla
	Point ptoVtceContacto, ptoVtceContMultRes;
	int nVtceContacto, nVtceContMultRes;
    float afRestMov[3];  // vector para la lectura de la restricciÃ³n de movimientos
	static bool bPrimVez = true;
	int nNumLinks, i, j;        // variables para el cambio de estado de los links
	unsigned int nNodoLinkado;  // afectados por el nuevo contacto
	vtkLink *pLinkado=NULL;

	if(m_bDeformSC)
		return;    


	nVtceContMultRes = c_pContact->GetNumVertex();
	ptoVtceContMultRes = Point(m_afCurrentCoord[nVtceContMultRes*3 + 0],
							   m_afCurrentCoord[nVtceContMultRes*3 + 1],
							   m_afCurrentCoord[nVtceContMultRes*3 + 2]);


	
	//nVtceContacto = FindContact(c_pContact->GetElement(), ptoVtceContMultRes, ptoVtceContacto);
	nVtceContacto = c_pContact->GetElement();

	if (nVtceContacto<0) 
		return;

	vtkOrgan::AddContact( c_pContact );
	
	if(m_pFirstContact == NULL)	
		m_pLastContact = m_pFirstContact = new vtkDataContact;		
	else{
		m_pLastContact->m_nNext = new vtkDataContact;
		(m_pLastContact->m_nNext)->m_nPrev = m_pLastContact;
		m_pLastContact = m_pLastContact->m_nNext;
	}

	m_pLastContact->m_nVtceContacto = nVtceContacto;
	m_pLastContact->m_nVtceContMultRes = nVtceContMultRes;  
	m_pLastContact->m_nCaraContacto = c_pContact->GetElement();
	m_pLastContact->m_ptoPos = ptoVtceContMultRes;

	m_pLastContact->m_bTirar = c_pContact->GetPullPermit();

	c_pContact->GetRestMov(afRestMov); //Lectura del vector de restricciÃ³n de movimiento
	m_pLastContact->m_ptoRestMov = Point(afRestMov[0], afRestMov[1], afRestMov[2]); 

	nNumLinks = m_lpLinks->GetCount();          // por ultimo actualizamos los links
										       // si tenemos el contacto sobre uno de ellos
	for(i = 0; i < nNumLinks; i++){			   // y no es primario cambiamos la prioridad
		pLinkado = m_lpLinks->Item(i);
		pLinkado->GetLinkData(this, &nNodoLinkado); 
		if(pLinkado->IsPrimary(this))
			if(!pLinkado->IsChanged())
				m_pnPointState[nNodoLinkado] = LINKEDPRIMARY_STATE;
		else
			if(pLinkado->IsChanged())
				m_pnPointState[nNodoLinkado] = LINKEDSECUNDARYARMONIC_STATE;
			else
				m_pnPointState[nNodoLinkado] = LINKEDSECUNDARY_STATE;

		if((int)nNodoLinkado == m_pLastContact->m_nVtceContacto)
			if(m_pnPointState[m_pLastContact->m_nVtceContacto] != LINKEDPRIMARY_STATE){
				pLinkado->ChangePriority();
				m_pnPointState[m_pLastContact->m_nVtceContacto] = LINKEDPRIMARY_STATE;
			}
	
		for(j = 0; j < 3; j++)  // de los enganches tambien cambiamos la prioridad
			if(m_panConect[m_pLastContact->m_nVtceContacto][j] == (int)nNodoLinkado)
				if((m_pnPointState[m_panConect[m_pLastContact->m_nVtceContacto][j]] != LINKEDPRIMARY_STATE) &&
					(m_pnPointState[m_panConect[m_pLastContact->m_nVtceContacto][j]] != LINKEDPRIMARYARMONIC_STATE)){		
				
					pLinkado->ChangePriority();
					m_pnPointState[m_panConect[m_pLastContact->m_nVtceContacto][j]] = LINKEDPRIMARYARMONIC_STATE;
			
				}
	}

		
	m_nNumContacts++;
}

bool vtkT2Mesh::Touched(int nFace){
	//Indica si una nFace estÃ¡ siendo tocada por un dispositivo
	int i;
	vtkDataContact *pContAct=NULL;
	bool bEstaTocado=false;

	pContAct = m_pFirstContact;
	for(i = 0; i < m_nNumContacts; i++){
			if(pContAct->m_nVtceContacto == nFace)
				bEstaTocado = true;
		pContAct = pContAct->m_nNext;
	}

	return bEstaTocado;
}



bool vtkT2Mesh::Grasped(int nFace){
	//Indica si una nFace estÃ¡ siendo pinzada con un pinzamiento total por parte de un dispositivo
	bool bEstaPinzado=false;

	return bEstaPinzado;
}



int vtkT2Mesh::NodeType(int nFace, int nEdge, Point &ptoInter){
	//Mira si el punto intersecciÃ³n se encuentra dentro , en el extremo inicial 
	//o en el extremo final de la nEdge de la nFace
	int i=0, nRetorno;
	float fT, fTdef, fX, fY, fZ;
	bool bSalir=false;

	while((i < 3) && (!bSalir)){
		fT = (m_pTrPoints[m_panTriangles[nFace][(nEdge+1)%3]][i] - m_pTrPoints[m_panTriangles[nFace][nEdge]][i]);
	    if((fT > 0.00001) || (fT < -0.00001)){
			fTdef = (ptoInter[i] - m_pTrPoints[m_panTriangles[nFace][nEdge]][i])/fT;
			fX = m_pTrPoints[m_panTriangles[nFace][nEdge]].x + 
				fTdef * (m_pTrPoints[m_panTriangles[nFace][(nEdge+1)%3]].x - m_pTrPoints[m_panTriangles[nFace][nEdge]].x);
			fY = m_pTrPoints[m_panTriangles[nFace][nEdge]].y + 
				fTdef * (m_pTrPoints[m_panTriangles[nFace][(nEdge+1)%3]].y - m_pTrPoints[m_panTriangles[nFace][nEdge]].y);
			fZ = m_pTrPoints[m_panTriangles[nFace][nEdge]].z + 
				fTdef * (m_pTrPoints[m_panTriangles[nFace][(nEdge+1)%3]].z - m_pTrPoints[m_panTriangles[nFace][nEdge]].z);

			if((Point(fX,fY,fZ)-ptoInter).Module() > 0.0001)
				nRetorno = TIPOIN_INTERNO;
			else
			if(fTdef < 0.00001f) nRetorno = TIPOIN_INICIAL;
			else
			if(fTdef > 0.99999f) nRetorno = TIPOIN_FINAL;
			else
				nRetorno = TIPOIN_ENARISTA;

			bSalir = true;
		}
		i++;
	}
	return nRetorno;
}


Point vtkT2Mesh::Intersect(int nFace, int nEdge, Point &ptoNormPlano, float fD){
	//Calcula la intersecciÃ³n de la nEdge de la nFace con el plano definido por 
	//ptoNormPlano y fD
	float fT;
	Point ptoVectorDir;

	ptoVectorDir = m_pTrPoints[m_panTriangles[nFace][(nEdge+1)%3]] - m_pTrPoints[m_panTriangles[nFace][nEdge]];
	fT = ptoNormPlano*ptoVectorDir;
	if(fT == 0)
		return Point(0.0f, 0.0f, 0.0f);
	else{
		fT = -(ptoNormPlano*m_pTrPoints[m_panTriangles[nFace][nEdge]]+fD)/fT;
		return (m_pTrPoints[m_panTriangles[nFace][nEdge]] + ptoVectorDir*fT);
	}
}

Point vtkT2Mesh::Intersect(Point &ptoIni, Point &ptoFin, Point &ptoNormPlano, float fD){
	//Calcula la intersecciÃ³n de la nEdge de la nFace con el plano definido por 
	//ptoNormPlano y fD
	float fT;
	Point ptoVectorDir;

	ptoVectorDir = ptoFin - ptoIni;

	fT = ptoNormPlano*ptoVectorDir;
	if(fT == 0)
		return Point(0.0f, 0.0f, 0.0f);
	else{
		fT = -(ptoNormPlano*ptoIni+fD)/fT;
		return (ptoIni + ptoVectorDir*fT);
	}
}



bool vtkT2Mesh::InsideTriangle(Point &pto, Point &ptoTri0, Point &ptoTri1, Point &ptoTri2,
							  Point &ptoLocCoor){
	//Determina si el punto p estÃ¡ dentro del triÃ¡ngulo definido por (t1, t2, t3)
	// normalmente este metodo se usa para saber si un punto esta dentro del triangulo
	// que forman los filos de las tijeras al principio del corte
	float afPto1[3], afPto2[3], afPto3[3];  // para pasar de clase Punto a array de
	float afCoord[3];                       // reales
	int i;

	for(i = 0; i < 3; i++){
		afPto1[i] = ptoTri0[i];
		afPto2[i] = ptoTri1[i];
		afPto3[i] = ptoTri2[i];
		afCoord[i] = pto[i];
	}

	// La siguiente parte del codigo ha sido desarrollada por Ulli
	vtkStdSubVector pv3fCoord0( afPto1 ),
				  pv3fCoord1( afPto2 ),
				  pv3fCoord2( afPto3 );

	// point's position w.r.t. element's node 2 in global x- and y-direction
	const float fCX = afCoord[0] - pv3fCoord2[0], fCY = afCoord[1] - pv3fCoord2[1];

	// element's local coordinate system axes Xi0 and Xi1 in global coordinates
	//   (xi0 from node 2 to node 0 and xi1 from node 2 to node 1)
	const float fXi0X = pv3fCoord0[0] - pv3fCoord2[0], fXi0Y = pv3fCoord0[1] - pv3fCoord2[1],
				fXi1X = pv3fCoord1[0] - pv3fCoord2[0], fXi1Y = pv3fCoord1[1] - pv3fCoord2[1];

	// starting from XiC0 * (P0 - P2) + XiC1 * (P1 - P2) = P - P2, where 0, 1, and 2 indicate the
	//   local nodes and XiC the inquired point's local coordinates, determine the latter:
	// ensure non-zero denominator of solution by switching between x-, y-, and z-coordinates, if
	//   necessary, starting with the pair x/y
	double dDenominator, dEnumerator0, dEnumerator1;
	double dTerm1 = (double)fXi0Y * fXi1X, dTerm2 = (double)fXi0X * fXi1Y,
		   dMaxAbsTerm = max( fabs( dTerm1 ),fabs( dTerm2 ) );
	if( dMaxAbsTerm > 0 && fabs( dDenominator = dTerm1 - dTerm2 ) / dMaxAbsTerm > 0.001 )
	{
		dEnumerator0 = (double)fCY * fXi1X - (double)fCX * fXi1Y;
		dEnumerator1 = (double)fCX * fXi0Y - (double)fCY * fXi0X;
	}
	else
	{
		// second try with x/z
		const float fCZ	  = afCoord [2] - pv3fCoord2[2],
					fXi0Z = pv3fCoord0[2] - pv3fCoord2[2], fXi1Z = pv3fCoord1[2] - pv3fCoord2[2];
		dTerm1 = (double)fXi0Z * fXi1X;  dTerm2 = (double)fXi0X * fXi1Z;
		dMaxAbsTerm = max( fabs( dTerm1 ),fabs( dTerm2 ) );
		if( dMaxAbsTerm > 0 && fabs( dDenominator = dTerm1 - dTerm2 ) / dMaxAbsTerm > 0.001 )
		{
			dEnumerator0 = (double)fCZ * fXi1X - (double)fCX * fXi1Z;
			dEnumerator1 = (double)fCX * fXi0Z - (double)fCZ * fXi0X;
		}
		else
		{
			// last resource y/z
			dTerm1 = (double)fXi0Y * fXi1Z;  dTerm2 = (double)fXi0Z * fXi1Y;
			dMaxAbsTerm = max( fabs( dTerm1 ),fabs( dTerm2 ) );
			if( dMaxAbsTerm > 0 && fabs( dDenominator = dTerm1 - dTerm2 ) / dMaxAbsTerm > 0.001 )
			{
				dEnumerator0 = (double)fCY * fXi1Z - (double)fCZ * fXi1Y;
				dEnumerator1 = (double)fCZ * fXi0Y - (double)fCY * fXi0Z;
			}
			else return false; //Error( "Organ contains singular element." );
		}
	}

	// finally compute local coordinates, where Xi2 follows from Xi0 + Xi1 + Xi2 = 0
	const float fXiC0 = (float)( dEnumerator0 / dDenominator ),
				fXiC1 = (float)( dEnumerator1 / dDenominator ),
				fXiC2 = (float)( 1.0 - fXiC0 - fXiC1 );

	ptoLocCoor = Point(fXiC0, fXiC1, fXiC2);

	return true;
}




bool vtkT2Mesh::InsideTriangle(Point &pto, Point &ptoTri0, Point &ptoTri1, Point &ptoTri2){
	//Determina si el punto p estÃ¡ dentro del triÃ¡ngulo definido por (t1, t2, t3)
	// normalmente este metodo se usa para saber si un punto esta dentro del triangulo
	// que forman los filos de las tijeras al principio del corte
	float afPto1[3], afPto2[3], afPto3[3];  // para pasar de clase Punto a array de
	float afCoord[3];                       // reales
	int i;

	for(i = 0; i < 3; i++){
		afPto1[i] = ptoTri0[i];
		afPto2[i] = ptoTri1[i];
		afPto3[i] = ptoTri2[i];
		afCoord[i] = pto[i];
	}

	// La siguiente parte del codigo ha sido desarrollada por Ulli
	vtkStdSubVector pv3fCoord0( afPto1 ),
				  pv3fCoord1( afPto2 ),
				  pv3fCoord2( afPto3 );

	// point's position w.r.t. element's node 2 in global x- and y-direction
	const float fCX = afCoord[0] - pv3fCoord2[0], fCY = afCoord[1] - pv3fCoord2[1];

	// element's local coordinate system axes Xi0 and Xi1 in global coordinates
	//   (xi0 from node 2 to node 0 and xi1 from node 2 to node 1)
	const float fXi0X = pv3fCoord0[0] - pv3fCoord2[0], fXi0Y = pv3fCoord0[1] - pv3fCoord2[1],
				fXi1X = pv3fCoord1[0] - pv3fCoord2[0], fXi1Y = pv3fCoord1[1] - pv3fCoord2[1];

	// starting from XiC0 * (P0 - P2) + XiC1 * (P1 - P2) = P - P2, where 0, 1, and 2 indicate the
	//   local nodes and XiC the inquired point's local coordinates, determine the latter:
	// ensure non-zero denominator of solution by switching between x-, y-, and z-coordinates, if
	//   necessary, starting with the pair x/y
	double dDenominator, dEnumerator0, dEnumerator1;
	double dTerm1 = (double)fXi0Y * fXi1X, dTerm2 = (double)fXi0X * fXi1Y,
		   dMaxAbsTerm = max( fabs( dTerm1 ),fabs( dTerm2 ) );
	if( dMaxAbsTerm > 0 && fabs( dDenominator = dTerm1 - dTerm2 ) / dMaxAbsTerm > 0.001 )
	{
		dEnumerator0 = (double)fCY * fXi1X - (double)fCX * fXi1Y;
		dEnumerator1 = (double)fCX * fXi0Y - (double)fCY * fXi0X;
	}
	else
	{
		// second try with x/z
		const float fCZ	  = afCoord [2] - pv3fCoord2[2],
					fXi0Z = pv3fCoord0[2] - pv3fCoord2[2], fXi1Z = pv3fCoord1[2] - pv3fCoord2[2];
		dTerm1 = (double)fXi0Z * fXi1X;  dTerm2 = (double)fXi0X * fXi1Z;
		dMaxAbsTerm = max( fabs( dTerm1 ),fabs( dTerm2 ) );
		if( dMaxAbsTerm > 0 && fabs( dDenominator = dTerm1 - dTerm2 ) / dMaxAbsTerm > 0.001 )
		{
			dEnumerator0 = (double)fCZ * fXi1X - (double)fCX * fXi1Z;
			dEnumerator1 = (double)fCX * fXi0Z - (double)fCZ * fXi0X;
		}
		else
		{
			// last resource y/z
			dTerm1 = (double)fXi0Y * fXi1Z;  dTerm2 = (double)fXi0Z * fXi1Y;
			dMaxAbsTerm = max( fabs( dTerm1 ),fabs( dTerm2 ) );
			if( dMaxAbsTerm > 0 && fabs( dDenominator = dTerm1 - dTerm2 ) / dMaxAbsTerm > 0.001 )
			{
				dEnumerator0 = (double)fCY * fXi1Z - (double)fCZ * fXi1Y;
				dEnumerator1 = (double)fCZ * fXi0Y - (double)fCY * fXi0Z;
			}
			else return false; //Error( "Organ contains singular element." );
		}
	}

	// finally compute local coordinates, where Xi2 follows from Xi0 + Xi1 + Xi2 = 0
	const float fXiC0 = (float)( dEnumerator0 / dDenominator ),
				fXiC1 = (float)( dEnumerator1 / dDenominator ),
				fXiC2 = (float)( 1.0 - fXiC0 - fXiC1 );

	if((fXiC0 >= -0.0001) && (fXiC1 >= -0.0001) && (fXiC2 >= -0.0001)) // El pto pasado esta dentro del triangulo
		return true;
	else
		return false;
}


///////////////////////////////////////////////////////////////////////////////////
//FIN MÃ“DULOS ÃšTILES PARA EL CORTE DE TEJIDO NORMAL CON TIJERAS
//MÃ“DULOS ÃšTILES PARA EL CORTE DE TEJIDO COMPLETO CON TIJERAS

void vtkT2Mesh::CalculateIntersection(int nCaraActual, Point &ptoNormPlano, float fD, Point &ptoIter, int &nEdge, int &nTipoConect,int flgDir){
	//Busca el corte a izquierdas de la nFace actual (caraactual)
	//Devuelve el punto de corte (ptoIzq), la nEdge que corta (nEdge) y el nTipo de corte (nTipo)
	int i=0, nNumNodos;
	bool bSalir=false;
	float fValor1, fValor2;
	Point ptoIni, ptoFin;

	nNumNodos = m_pFaces->Item(nCaraActual)->numVertex;
	while(!bSalir && i < nNumNodos){
		ptoIni = m_pPointsT2[(*(m_pFaces->Item(nCaraActual)))[i]];
		fValor1 = ptoIni * ptoNormPlano + fD;
		ptoFin = m_pPointsT2[(*(m_pFaces->Item(nCaraActual)))[(i+1)%nNumNodos]];
		fValor2 = ptoFin * ptoNormPlano + fD;
		if (flgDir==DIR_TOLEFT){
			if(fValor1 >= 0.0f){		// Las caras se recorren siempre en 
				if(fValor2 < 0.0f){     // sentido antihorario, lo que buscamos 
					bSalir = true;      // es una nEdge que tenga cada vertice a 
				}
			}
		}
		else{                           // un lado del plano de corte. Presumiblemente
			if(fValor1 <= 0.0f){        // cada cara tendra dos de estas, para descriminar
				if(fValor2 > 0.0f){     // es por lo que se usa a Izquierdas o derechas e
					bSalir = true;      // indica simplemente a que lado del plano queda
				}						// el vertice inicial de la nEdge
			}
		}
		i++;                            
	}
	nEdge = i-1;
	ptoIter = Intersect(ptoIni, ptoFin, ptoNormPlano, fD);
	if(fValor1 == 0.0f)
		nTipoConect = TIPOIN_INICIAL;
	else
		nTipoConect = TIPOIN_INTERNO;
}

void vtkT2Mesh::Re_BalanceIntersection(int nCaraActual, int nEdge, Point &ptoInter){
	//Reequilibra una IntersecciÃ³n que coincide con el nodo de una nFace
	//para que no coincida (dado que darÃ­a lugar a una nFace degenerada)
	Point ptoIni, ptoFin;

	ptoIni = m_pPointsT2[(*(m_pFaces->Item(nCaraActual)))[nEdge]];
	ptoFin = m_pPointsT2[(*(m_pFaces->Item(nCaraActual)))[(nEdge+1) % m_pFaces->Item(nCaraActual)->numVertex]];

	ptoInter = ptoIni * 0.9f + ptoFin * 0.1f;
}

int vtkT2Mesh::ObtainNextFace(int nCaraActual, int nEdge){
	//Obtiene la nFace que estÃ¡ en contacto con la nFace actual a travÃ©s de nEdge
	int i=0, j, nNumNodos;
	int nNodo1, nNodo2, nCaraComun;
	bool bEncontrada=false;

	nNodo1 = (*(m_pFaces->Item(nCaraActual)))[nEdge];
	nNodo2 = (*(m_pFaces->Item(nCaraActual)))[(nEdge+1) % m_pFaces->Item(nCaraActual)->numVertex];
	while(i < 3 && !bEncontrada){
		if(m_panAdjacentFaces[nNodo2][i] != nCaraActual){
			nCaraComun = m_panAdjacentFaces[nNodo2][i];
			nNumNodos = m_pFaces->Item(nCaraComun)->numVertex;
			j = 0;
			while(j < nNumNodos && !bEncontrada){
				if((((*(m_pFaces->Item(nCaraComun)))[j] == nNodo1) && ((*(m_pFaces->Item(nCaraComun)))[(j+1)%m_pFaces->Item(nCaraComun)->numVertex] == nNodo2)) ||
					(((*(m_pFaces->Item(nCaraComun)))[j] == nNodo2) && ((*(m_pFaces->Item(nCaraComun)))[(j+1)%m_pFaces->Item(nCaraComun)->numVertex] == nNodo1)))
				   bEncontrada = true;

				j++;
			}
		}
		i++;
	}
	if(!bEncontrada){
		return -1;
	}
	else
		return nCaraComun;
}

int vtkT2Mesh::ObtainFaceType(int nCaraActual){
	//Devuelve el nTipo de cara caraactual.
	int i=0;
	int nNodo1, nNodo2, nTipoConexion;
	bool bSalir=false;

	nNodo1 = (*(m_pFaces->Item(nCaraActual)))[0];
	nNodo2 = (*(m_pFaces->Item(nCaraActual)))[1];
	while(i < 3 && !bSalir){
		if(m_panConect[nNodo1][i] == nNodo2){
			nTipoConexion = m_panConectionType[nNodo1][i];
			bSalir = true;
		}
		i++;
	}
	if(!bSalir){
		return -1;
	}
	else
		return nTipoConexion;
}
bool vtkT2Mesh::NextFaceEdge(int nCaraAct,int nCaraSig,int* nEdge){
	// Este procedimiento calcula si nCaraSig se puede alcanzar desde nCaraAct
	// Devolviendo en caso afirmativo que arista de nCaraSig es la compartida
	int nAristaFinal=0;

	while (nAristaFinal<m_pFaces->Item(nCaraAct)->numVertex &&
		   ObtainNextFace(nCaraAct,nAristaFinal)!=nCaraSig){
		nAristaFinal++;
	}
		   if (nAristaFinal>=m_pFaces->Item(nCaraAct)->numVertex)
		return false;

	(*nEdge)=nAristaFinal;
	return true;
}

Point vtkT2Mesh::SpinCalculate(vtkWay* pIntersecciones,int nIndFin,int nIndIni,int nNumNodos){
	// Este metodo calcula el muelle que atraviesa una cara y que es
	// generado durante el corte.
	Point ptoResult(0.0f,0.0f,0.0f);
	int nVtceIni,nVtceFin;       // Nodos de la T2-Mesh que definen una arista
	int i,j;						 
	vtkWay* pInterIni=NULL,*pInterFin=NULL;           
	int nAristaIni,nAristaFin,nFace;
	float fValor=0.0f;			 // marcara la posicion relativa de una Interseccion en una arista

	assert(nIndFin>0 && nIndIni>0);
	pInterFin=pIntersecciones;
	pInterIni=pIntersecciones;
	i=nNumNodos-2;
	while(i>nIndIni || i>nIndFin){					// Una interseccion de la lista Camino del corte
		if (i>nIndFin) pInterFin=pInterFin->m_nPrev; // equivale a dos Nodos finales de la T2Mesh
		if (i>nIndIni) pInterIni=pInterIni->m_nPrev; // Izq y Der, aunque en principio con las mismas coordenadas
		i-=2;
	}
	nAristaFin=pInterFin->m_nEdge;
	nFace=pInterFin->m_nFace;			    // Esta es la cara, falta combertir la arista final a una
	if (nFace!=pInterIni->m_nFace){			// arista de la misma, ya que inicialmente las caras son distintas
		if (!NextFaceEdge(nFace,pInterIni->m_nFace,&nAristaIni)){
			// Este caso se da en el enganche final, donde la ultima cara se obvia
			// para no repetir 2 veces el mismo punto de interseccion.
			nFace=ObtainNextFace(nFace,nAristaFin);
			bool bCambio1=NextFaceEdge(nFace,pInterFin->m_nFace,&nAristaFin);
			bool bCambio2=NextFaceEdge(nFace,pInterIni->m_nFace,&nAristaIni);
			assert(bCambio1 && bCambio2);
		}
	}
	else 
		nAristaIni=pInterIni->m_nEdge;
	
	
	// Lo primero es sumar el porcentaje del muelle de las aristas iniciales y finales
	// hay que tener el cuenta que el recorrido es en contra del sentido horario y que
	// el porcentaje de la arista es el comprendido entre en nodo inicio de esa arista y el corte de la misma
	nVtceIni=(*(m_pFaces->Item(nFace)))[nAristaFin];
	nVtceFin=(*(m_pFaces->Item(nFace)))[(nAristaFin+1)%m_pFaces->Item(nFace)->numVertex];
	fValor=(pInterFin->m_ptoIntersec-m_pPointsT2[nVtceIni]).Module()/(m_pPointsT2[nVtceFin]-m_pPointsT2[nVtceIni]).Module();
	for (i=0;i<3;i++){
		if (m_panCopyConect[nVtceFin][i]==nVtceIni){
			ptoResult=m_paCopySpins[nVtceFin][i]*fValor;
		}
	}
	nVtceIni=(*(m_pFaces->Item(nFace)))[nAristaIni];
	nVtceFin=(*(m_pFaces->Item(nFace)))[(nAristaIni+1)%m_pFaces->Item(nFace)->numVertex];
	fValor=(pInterIni->m_ptoIntersec-m_pPointsT2[nVtceIni]).Module()/(m_pPointsT2[nVtceFin]-m_pPointsT2[nVtceIni]).Module();
	for (i=0;i<3;i++){
		if (m_panCopyConect[nVtceFin][i]==nVtceIni){
			ptoResult=ptoResult+m_paCopySpins[nVtceFin][i]*(1.0f-fValor);
		}
	}
	// Ahora solo queda recorrer los muelles entre el fin de la arista ini y el ini de la arista fin
	nVtceIni=nVtceFin;
	j=(nAristaIni+1)%m_pFaces->Item(nFace)->numVertex;  // Arista siguiente a la inicial
	while (j!=nAristaFin){
		j=(j+1)%m_pFaces->Item(nFace)->numVertex;
		nVtceFin=(*(m_pFaces->Item(nFace)))[j];
		for (i=0;i<3;i++){
			if (m_panCopyConect[nVtceFin][i]==nVtceIni){
				ptoResult=ptoResult+m_paCopySpins[nVtceFin][i];
			}
		}
		nVtceIni=nVtceFin;		
	}
	return ptoResult;
}


void vtkT2Mesh::CreateConection(vtkWay *pCaminoAct, int &nNodoDer, int &nNodoIzq, Point *pNuevosNodos,
							Point *pNuevaTextura, INT3 *pnConexiones, int &nNumAnadidos, 
							INT3 *pnTipoConect, POINT3 *pMuelleso, int flgDir, 
							bool final, bool dirfinal){
	int j;
	int nNodoAnt, nNodoPost, nMuelleAnt=-1, nMuellePost=-1;
	float fValor;
	int nTipoCxnNodoPost;
	Point ptoAux;

	pNuevosNodos[nNumAnadidos] = pCaminoAct->m_ptoIntersec;  
	nNumAnadidos++;
	pNuevosNodos[nNumAnadidos] = pCaminoAct->m_ptoIntersec;
	nNumAnadidos++;
	nNodoAnt = (*(m_pFaces->Item(pCaminoAct->m_nFace)))[pCaminoAct->m_nEdge];
	nNodoPost = (*(m_pFaces->Item(pCaminoAct->m_nFace)))[(pCaminoAct->m_nEdge+1)%m_pFaces->Item(pCaminoAct->m_nFace)->numVertex];
	fValor = (pCaminoAct->m_ptoIntersec-m_pPointsT2[nNodoAnt]).Module() / (m_pPointsT2[nNodoPost]-m_pPointsT2[nNodoAnt]).Module();

	pNuevaTextura[nNumAnadidos-2] = pNuevaTextura[nNumAnadidos-1] =
		(m_pTextureT2[nNodoAnt] * (1-fValor)) +
		(m_pTextureT2[nNodoPost]* fValor);

	for(j = 0; j < 3; j++){
		if(m_panConect[nNodoAnt][j] == nNodoPost){
			m_panConect[nNodoAnt][j] = -(nNumAnadidos-2);
			m_paSpins[nNodoAnt][j] = m_paCopySpins[nNodoAnt][j] * fValor*0.9f;
			pMuelleso[nNumAnadidos-2][0] = m_paSpins[nNodoAnt][j].Invert();
			nMuelleAnt = j;
		}
		if(m_panConect[nNodoPost][j] == nNodoAnt){
			m_panConect[nNodoPost][j] = -(nNumAnadidos-1);
			m_paSpins[nNodoPost][j] = m_paCopySpins[nNodoPost][j] * (1.0f-fValor)*0.9f;
			pMuelleso[nNumAnadidos-1][0] = m_paSpins[nNodoPost][j].Invert();
			nTipoCxnNodoPost = m_panConectionType[nNodoPost][j];
			nMuellePost = j;
		}
	}

	if (nMuellePost==-1 || nMuelleAnt==-1){
		return;
	}

	// esta es la parte del codigo comun a la hora de crear las conexiones
	pnConexiones[nNumAnadidos-2][0] = nNodoAnt;
	pnTipoConect[nNumAnadidos-2][0] = nTipoCxnNodoPost;
	pnTipoConect[nNumAnadidos-2][1] = (nTipoCxnNodoPost == REAL_EDGE)?HOLE_EDGE:UNREAL_EDGE;
	pnTipoConect[nNumAnadidos-2][2] = REAL_EDGE;
	pnConexiones[nNumAnadidos-1][0] = nNodoPost;
	pnTipoConect[nNumAnadidos-1][0] = REAL_EDGE;
	pnTipoConect[nNumAnadidos-1][1] = HOLE_EDGE;
	pnTipoConect[nNumAnadidos-1][2] = (nTipoCxnNodoPost == REAL_EDGE)?REAL_EDGE:UNREAL_EDGE;

	if((nTipoCxnNodoPost == HOLE_EDGE) || (final && !dirfinal))
	//dirfinal indica si el final se estÃ¡ cerrando en un punto inicial detectado
	//a derechas. SÃ³lo ocurre en el caso de corte de superficie.
	{
		pMuelleso[nNumAnadidos-2][1] = m_paCopySpins[nNodoAnt][nMuelleAnt] * 0.1;
		pMuelleso[nNumAnadidos-1][2] = m_paCopySpins[nNodoPost][nMuellePost] * 0.1;
		pnConexiones[nNumAnadidos-2][1] = -(nNumAnadidos-1);
		pnConexiones[nNumAnadidos-1][2] = -(nNumAnadidos-2);
	}
	else
	if(final && dirfinal)
	{
		pMuelleso[nNumAnadidos-2][2] = m_paCopySpins[nNodoAnt][nMuelleAnt] * 0.1;
		pMuelleso[nNumAnadidos-1][1] = m_paCopySpins[nNodoPost][nMuellePost] * 0.1;
		pnConexiones[nNumAnadidos-2][2] = -(nNumAnadidos-1);
		pnConexiones[nNumAnadidos-1][1] = -(nNumAnadidos-2);
	}
	// Aqui comienza la parte especifica segun en que direccion se estan realizando los enganches
	if (flgDir!=DIR_INITIALPOINT){
		switch(flgDir){
		case DIR_TOLEFT:
			pnConexiones[nNumAnadidos-2][1] = nNodoIzq;
			pMuelleso[nNumAnadidos-2][1] = SpinCalculate(pCaminoAct,nNumAnadidos-2,-nNodoIzq,nNumAnadidos); //pNuevosNodos[nNumAnadidos-2]-pNuevosNodos[-nNodoIzq];
			pnConexiones[nNumAnadidos-1][2] = nNodoDer;
			pMuelleso[nNumAnadidos-1][2] = SpinCalculate(pCaminoAct,nNumAnadidos-1,-nNodoDer,nNumAnadidos); //pNuevosNodos[nNumAnadidos-1]-pNuevosNodos[-nNodoDer];
			break;
		case DIR_TORIGHT:
			pnConexiones[nNumAnadidos-2][2] = nNodoDer;
			pMuelleso[nNumAnadidos-2][2] = SpinCalculate(pCaminoAct,nNumAnadidos-2,-nNodoDer,nNumAnadidos); //pNuevosNodos[nNumAnadidos-2]-pNuevosNodos[-nNodoDer];
			pnConexiones[nNumAnadidos-1][1] = nNodoIzq;
			pMuelleso[nNumAnadidos-1][1] = SpinCalculate(pCaminoAct,nNumAnadidos-1,-nNodoIzq,nNumAnadidos); //pNuevosNodos[nNumAnadidos-1]-pNuevosNodos[-nNodoIzq];
			break;
		}
		// ahora tambien viene un codigo que depende de a que direccion hagamos las conexiones
		// pero que un cambio de la posicion podemos reutilizar
		int nRestarA=(flgDir==DIR_TOLEFT)?1:2;
		int nRestarB=(flgDir==DIR_TOLEFT)?2:1;
		// La verdad es que debido a que 2 nuevos puntos comparten las mismas coordenadas
		// Los muelles que se calculan dos veces en verdad dan el mismo resultado
		pnConexiones[-nNodoDer][1]=-(nNumAnadidos-nRestarA);
		pMuelleso[-nNodoDer][1]=pMuelleso[nNumAnadidos-nRestarB][1].Invert();
		pnConexiones[-nNodoIzq][2]=-(nNumAnadidos-nRestarB);
		pMuelleso[-nNodoIzq][2]=pMuelleso[nNumAnadidos-nRestarA][2].Invert();
	}

	if ( (flgDir==DIR_INITIALPOINT && !dirfinal) || flgDir==DIR_TOLEFT){
		nNodoDer = -(nNumAnadidos-1);
		nNodoIzq = -(nNumAnadidos-2);
	}
	else{    // por tanto flgDir == DIR_TORIGHT
		nNodoDer = -(nNumAnadidos-2);
		nNodoIzq = -(nNumAnadidos-1);
	}
}

void vtkT2Mesh::CreateFinalConection(vtkWay* pIntersecciones,int nNodoDerIni, int nNodoIzqIni, int nNodoDer, int nNodoIzq, 
								 int nNumAnadidos,INT3 *pnConexiones, POINT3 *pMuelleso){
	//Crea la Ãºltima conexiÃ³n que enlaza el primer nodo con el Ãºltimo en un corte
	//total de superficie continua
	// Calcular muelle necesita que la lista este apuntando a la ultima interseccion que se uso
	// para crear los nuevos Nodos de la T2. En este momento apunta al primero porque es una lista
	// ciclica y llegamos de un recorrido anterior a si que...
	pIntersecciones=pIntersecciones->m_nPrev;
	pnConexiones[-nNodoIzq][2] = nNodoIzqIni;
	pMuelleso[-nNodoIzq][2] = SpinCalculate(pIntersecciones,-nNodoIzq,-nNodoIzqIni,nNumAnadidos); //pNuevosNodos[-nNodoIzq] - pNuevosNodos[-nNodoIzqIni];
	pnConexiones[-nNodoDer][1] = nNodoDerIni;
	pMuelleso[-nNodoDer][1] = pMuelleso[-nNodoIzq][2];
	pnConexiones[-nNodoIzqIni][1] = nNodoIzq;
	pMuelleso[-nNodoIzqIni][1] = pMuelleso[-nNodoIzq][2].Invert();
	pnConexiones[-nNodoDerIni][2] = nNodoDer;
	pMuelleso[-nNodoDerIni][2] = pMuelleso[-nNodoIzqIni][1];
}


int vtkT2Mesh::Cut(const char nTipoCorte, const unsigned uElementoComienzo, float *ptoElementoComienzo,
				   const unsigned uElementoFinal, float *ptoElementoFinal, float *pfVector){
	//Realiza el corte provocado por un dispositivo
	vtkWay *pCaminoPrim, *pCaminoAct, *pCaminoAnt, *pCaminoIni;
	int nNumNodos;
	Point ptoNormPlano;
	Point ptoAux(pfVector[0], pfVector[1], pfVector[2]);
	Point ptoAux2;
	float fD;
	bool bFinCorte;
	int nCaraSig, nCaraAnt;
	Point ptoContSig, ptoContAnt;	// puntos de contacto siguiente y anterior (con respecto a la cara)
	int i, j; 
	bool bCortePlano; 
	int nNodoDer, nNodoIzq;
	int nNumAnadidos;
	Point *pNuevosNodos;
	Point *pNuevaTextura;
	INT3 *pnConexiones,*pnTipoConect;
	POINT3 *pMuelleso;
	bool bSalir,bCerrado;
	Point ptoNormSuplim;
	float fValor1, fValor2;
	Point ptoNormAnt, ptoNormSig;
	//	VARIABLES PARA LA RECONSTRUCCIÃ“N DE LA MALLA EN CASO DE CORTE
	int k;
	int nNodoAnt,nNodoSig, nEntradoPor, nIndConect, nNodoGrav, nNodoIni, nNodoFin;
	int nNumPtosT2;
	BOOL3 *pabMarcado;
	INT3 panAdy; 
	Point *pPtosT2, *pTexturaT2, *pPtosT2Ant;
	bool *pbInestable;
	INT3 *panConect, *panTipoConect;
	int *pnTipoPto, *pnEstadoPto;
	POINT3 *pMuelles;
	bool bErrorCorte;
	vtkDataT2Mesh*  copiaDatosT2 = vtkDataT2Mesh::New();
	//	VARIABLES PARA EL CÃ�LCULO EN CASO DE CORTE TOTAL
	int nCaraAct, nCaraIni;
	int nNumNodosIzq;              // numero de nodos a la izquierda
	int nEdge, nTipo, nTipoCara;
	Point ptoAct, ptoDer, ptoIzq, ptoIzqAnt;
	int nNodoDerIni, nNodoIzqIni;
	

	if(m_bDeformSC)
		return -10; //Intento de cÃ¡lculo de corte con una malla T2 incorrecta.
					//Hay que llamar previamente a Deform.

	nCaraSig = uElementoFinal;
	nCaraAnt = uElementoComienzo;		



	switch(nTipoCorte){
	case BESS_CUT_SURFACE	:
	case BESS_CUT_SHEARS	:
	//Reuso de variables de tipo punto.
	//ptoContAnt y ptoContSig son coordenadas absolutas de los extremos de la tijera.
	//ptoAct son las coordenadas absolutas del eje de giro de las hojas de la tijera.
	//ptoAux serÃ¡ el centro de gravedad
		nCaraIni = nCaraAct = m_panTriangles[uElementoComienzo][0];
		ptoContAnt = Point(ptoElementoComienzo[0], ptoElementoComienzo[1], 
			ptoElementoComienzo[2]);
		ptoContSig = Point(ptoElementoFinal[0], ptoElementoFinal[1], 
			ptoElementoFinal[2]);
		ptoAct = Point(pfVector[0], pfVector[1], pfVector[2]); 
		ptoAux = (ptoContAnt + ptoContSig + ptoAct) * (1.0f/3.0f);
		ptoAux2 = (ptoContAnt + ptoContSig)*(1.0f/2.0f);

	//COMIENZA EL CÃ�LCULO DE LA ECUACIÃ“N DEL PLANO QUE DEFINE LA TIJERA
		ptoNormPlano = (ptoContSig-ptoContAnt)^(ptoAct-ptoContAnt);
		fD = -(ptoNormPlano*ptoAct);
		nNumNodosIzq = 1;
	//FIN DEL CÃ�LCULO DE LA ECUACIÃ“N DEL PLANO QUE DEFINE LA TIJERA
	//FASE DE INICIALIZACIÃ“N DEL CÃ�LCULO DEL CAMINO DE CORTE
		CalculateIntersection(nCaraAct, ptoNormPlano, fD, ptoIzq, nEdge, nTipo, DIR_TOLEFT); 
		if(nTipo != TIPOIN_INTERNO)
			Re_BalanceIntersection(nCaraAct, nEdge, ptoIzq);


		//----------------------------------------------------
		// FASE 1.- CÃ�LCULO DEL CAMINO DE CORTE TOTAL
		//----------------------------------------------------

		pCaminoPrim = vtkWay::New();
		pCaminoPrim->m_ptoIntersec = ptoIzq;
		pCaminoPrim->m_nFace = nCaraAct;
		pCaminoPrim->m_nEdge = nEdge;
		pCaminoPrim->m_nType = nTipo;
		pCaminoPrim->m_nNext = NULL;
		pCaminoPrim->m_nPrev = NULL;
		nNumNodos = 1;
		pCaminoIni = pCaminoAct = pCaminoPrim;

		CalculateIntersection(nCaraAct, ptoNormPlano, fD, ptoDer, nEdge, nTipo,DIR_TORIGHT); 
		if(nTipo != 0)
			Re_BalanceIntersection(nCaraAct, nEdge, ptoDer);
		
		pCaminoAct->m_nNext = vtkWay::New();
		pCaminoAct->m_nNext->m_nPrev = pCaminoAct;
		pCaminoAnt = pCaminoAct;
		pCaminoAct = pCaminoAct->m_nNext;
		pCaminoAct->m_ptoIntersec = ptoDer;
		pCaminoAct->m_nFace = nCaraAct;
		pCaminoAct->m_nEdge = nEdge;
		pCaminoAct->m_nType = nTipo;
		pCaminoAct->m_nNext = NULL;
		nNumNodos++;

		bFinCorte = false;
		while(!bFinCorte){
			nCaraAct = ObtainNextFace(nCaraAct, nEdge);
			nTipoCara = ObtainFaceType(nCaraAct);
			if(nTipoCara == REAL_EDGE)
				if(nCaraIni != nCaraAct){
					CalculateIntersection(nCaraAct, ptoNormPlano, fD, ptoDer, nEdge, nTipo, DIR_TORIGHT);
					if(nTipo != TIPOIN_INTERNO)
						Re_BalanceIntersection(nCaraAct, nEdge, ptoDer);
			
					pCaminoAct->m_nNext = vtkWay::New();
					pCaminoAct->m_nNext->m_nPrev = pCaminoAct;
					pCaminoAct = pCaminoAct->m_nNext;
					pCaminoAct->m_ptoIntersec = ptoDer;
					pCaminoAct->m_nFace = nCaraAct;
					pCaminoAct->m_nEdge = nEdge;
					pCaminoAct->m_nType = nTipo;
					pCaminoAct->m_nNext = NULL;
					nNumNodos++;
				}
				else{
					pCaminoAct->m_nPrev->m_nNext = pCaminoPrim;
					pCaminoPrim->m_nPrev = pCaminoAct->m_nPrev;
					pCaminoAct->Delete();
					nNumNodos--;
					bFinCorte = true;
				}
			else
				bFinCorte = true;

			if(nNumNodos > m_nNumPointsT2){ 
				pCaminoAct = pCaminoPrim;
				for(i = 0; i < (nNumNodos-1); i++){
					pCaminoAct = pCaminoAct->m_nNext;
					pCaminoAct->m_nPrev->Delete();
				}
				pCaminoAct->Delete();

				return -5; //ERROR DESCONOCIDO
			}
		}

		if(nCaraIni != nCaraAct){				// Si entramos aqui es porque mirando el corte	
			nCaraAct = pCaminoPrim->m_nFace;    // total a derechas nos encontramos con un hueco
			nEdge = pCaminoPrim->m_nEdge;   // en la malla y tenemos que probar por la izquierda
			pCaminoAct = pCaminoPrim;

			bFinCorte = false;
			while(!bFinCorte){
				nCaraAct = ObtainNextFace(nCaraAct, nEdge);
				nTipoCara = ObtainFaceType(nCaraAct);
				if(nTipoCara == REAL_EDGE){
					nNumNodosIzq++;
					CalculateIntersection(nCaraAct, ptoNormPlano, fD, ptoIzq, nEdge, nTipo,DIR_TOLEFT);
					if(nTipo != REAL_EDGE)
						Re_BalanceIntersection(nCaraAct, nEdge, ptoIzq);
			
					pCaminoAct->m_nPrev = new vtkWay;
					pCaminoAct->m_nPrev->m_nNext = pCaminoAct;
					pCaminoAct = pCaminoAct->m_nPrev;
					pCaminoAct->m_ptoIntersec = ptoIzq;
					pCaminoAct->m_nFace = nCaraAct;
					pCaminoAct->m_nEdge = nEdge;
					pCaminoAct->m_nType = nTipo;
					pCaminoAct->m_nPrev = NULL;
					pCaminoPrim = pCaminoAct;
					nNumNodos++;
				}
				else
					bFinCorte = true;

				if(nNumNodos > m_nNumPointsT2){ 
					pCaminoAct = pCaminoPrim;
					for(i = 0; i < (nNumNodos-1); i++){
						pCaminoAct = pCaminoAct->m_nNext;
						pCaminoAct->m_nPrev->Delete();
					}
					pCaminoAct->Delete();
					
					return -5; //ERROR DESCONOCIDO
				}
			}
		}


		//----------------------------------------------------
		// FASE 2.- CÃ�LCULO DEL PUNTO DE INICIO DEL CORTE
		//----------------------------------------------------
		fValor2 = -1.0f;
		pCaminoAct = pCaminoPrim;

//VersiÃ³n 2
		nNodoGrav = -1;
		i = 0;
		while(nNodoGrav < 0)
		{
			if(pCaminoIni == pCaminoAct)
				nNodoGrav = i;

			pCaminoAct = pCaminoAct->m_nNext;
			i++;
		}
		if(nNodoGrav < 0)
			nNodoGrav = nNodoGrav;



		//----------------------------------------------------
		// FASE 3.- CÃ�LCULO DEL CAMINO DE CORTE REAL
		//----------------------------------------------------
		

		//Recorrido en la direcciÃ³n derecha del centro de gravedad.

		fValor2 = (ptoAux - ptoContAnt).Module() * 1.10f;
		pCaminoAct = pCaminoIni;
		bSalir = false;
		if(nNodoGrav == (nNumNodos-1))
		{
			nNodoFin = nNodoGrav;
			bSalir = true;
		}
		else
		{
			nNodoFin = nNodoGrav + 1;
			pCaminoAct = pCaminoIni->m_nNext;
		}
		while(!bSalir)
		{
			fValor1 = (ptoAux - pCaminoAct->m_ptoIntersec).Module();
			if(fValor1 <= fValor2)
				nNodoFin = nNodoFin+1;
			else
				bSalir = true;

			if(nNodoFin >= (nNumNodos-1))
			{
				nNodoFin = nNumNodos - 1;
				bSalir = true;
			}

			pCaminoAct = pCaminoAct->m_nNext;
		}


		//Recorrido en la direcciÃ³n izquierda del centro de gravedad.

		pCaminoAct = pCaminoIni;
		bSalir = false;
		if(nNodoGrav == 0)
		{
			nNodoIni = nNodoGrav;
			bSalir = true;
		}
		else
		{
			nNodoIni = nNodoGrav-1;
			pCaminoAct = pCaminoAct->m_nPrev;
		}
		while(!bSalir)
		{
			fValor1 = (ptoAux - pCaminoAct->m_ptoIntersec).Module();
			if(fValor1 <= fValor2)
				nNodoIni = nNodoIni-1;
			else
				bSalir = true;

			if(nNodoIni <= 0)
			{
				nNodoIni = 0;
				bSalir = true;
			}

			pCaminoAct = pCaminoAct->m_nPrev;
		}

		//Condiciones de ERROR y de salida del camino real de corte.
		//CondiciÃ³n de salida: que el nÃºmero de nodos sea mayor o igual nNumNodos-2
		//CondiciÃ³n de ERROR: que el nÃºmero de nodos sea 1

		if((nNodoIni <= 1) && (nNodoFin >= (nNumNodos-2)))
		{
			pCaminoAct = pCaminoPrim;
			for(i = 0; i < (nNumNodos-1); i++){
				pCaminoAct = pCaminoAct->m_nNext;
				pCaminoAct->m_nPrev->Delete();
			}
			pCaminoAct->Delete();

			Cut(BESS_CUT_TOTAL, uElementoComienzo, ptoElementoComienzo, uElementoFinal, 
				ptoElementoFinal, pfVector);
			return 0;
		}

		if((nNodoFin-nNodoIni) == 0)
		{
			pCaminoAct = pCaminoPrim;
			for(i = 0; i < (nNumNodos-1); i++){
				pCaminoAct = pCaminoAct->m_nNext;
				pCaminoAct->m_nPrev->Delete();
			}
			pCaminoAct->Delete();

			return -4;
		}


		//----------------------------------------------------
		// FASE 4.- REALIZACIÃ“N DEL CORTE
		//----------------------------------------------------

		copiaDatosT2->MakeSegurityCopy(this);

		// Ahora que tenemos el camino completo comenzamos a realizar los enganches y demas de los nuevos nodos

		pCaminoAct = pCaminoPrim;
		for(i = 0; i < nNodoIni; i++)
			pCaminoAct = pCaminoAct->m_nNext;

		i = nNodoIni;
		nNodoDer = nNodoIzq = 0;
		nNumAnadidos = 1; //La inicializaciÃ³n a 0 podrÃ­a inducir a errores
		pNuevosNodos = new Point[6*nNumNodos];
		pNuevaTextura = new Point[6*nNumNodos];
		pnConexiones = new INT3[6*nNumNodos];
		pnTipoConect = new INT3[6*nNumNodos];
		pMuelleso = new POINT3[6*nNumNodos];

		if(nNodoIni < nNumNodosIzq)
			CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos,
			         pnTipoConect, pMuelleso,DIR_INITIALPOINT, true);
		else
			CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos,
			         pnTipoConect, pMuelleso,DIR_INITIALPOINT, true, true);

		nNodoDerIni = nNodoDer; nNodoIzqIni = nNodoIzq;
		
		pCaminoAct = pCaminoAct->m_nNext;
		i++;
		while(i < nNodoFin){
			if(i < nNumNodosIzq)
				CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos, 
				             pnTipoConect, pMuelleso, DIR_TOLEFT);
			else
				CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos,
				             pnTipoConect, pMuelleso, DIR_TORIGHT);

			pCaminoAct = pCaminoAct->m_nNext;
			i++;
		}
		if(nNodoFin < nNumNodosIzq)
			CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos, 
						pnTipoConect, pMuelleso, DIR_TOLEFT, true, true);
		else
			CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos,
						pnTipoConect, pMuelleso, DIR_TORIGHT, true);
		
		break;

	case BESS_CUT_TOTAL	:
	case BESS_CLIP :
	// AQUÃ� VIENE LA FASE DE PREPARACIÃ“N
	//OJO: Se va a recalcular todo....
	//Reuso de variables de tipo punto.
	//ptoContAnt y ptoContSig son coordenadas absolutas de los extremos de la tijera.
	//ptoAct son las coordenadas absolutas del eje de giro de las hojas de la tijera.
	//ptoAux serÃ¡ el centro de gravedad
	// AQUÃ� VIENE LA FASE DE PREPARACIÃ“N
		nCaraIni = nCaraAct = m_panTriangles[uElementoComienzo][0];
		ptoContAnt = Point(ptoElementoComienzo[0], ptoElementoComienzo[1], 
			ptoElementoComienzo[2]);
		ptoContSig = Point(ptoElementoFinal[0], ptoElementoFinal[1], 
			ptoElementoFinal[2]);
		ptoAct = Point(pfVector[0], pfVector[1], pfVector[2]); 
		ptoAux = (ptoContAnt + ptoContSig + ptoAct) * (1.0f/3.0f);
		ptoAux2 = (ptoContAnt + ptoContSig)*(1.0f/2.0f);

	//FIN DE LA FASE DE PREPARACIÃ“N. COMIENZA EL CÃ“DIGO SERIO
	//COMIENZA EL CÃ�LCULO DE LA ECUACIÃ“N DEL PLANO QUE DEFINE LA TIJERA
		ptoNormPlano = (ptoContSig-ptoContAnt)^(ptoAct-ptoContAnt);
		fD = -(ptoNormPlano*ptoAct);
		nNumNodosIzq = 1;
		bCortePlano = false;





	//FIN DEL CÃ�LCULO DE LA ECUACIÃ“N DEL PLANO QUE DEFINE LA TIJERA
	//FASE DE INICIALIZACIÃ“N DEL CÃ�LCULO DEL CAMINO DE CORTE
		CalculateIntersection(nCaraAct, ptoNormPlano, fD, ptoIzq, nEdge, nTipo, DIR_TOLEFT); 
		//OJO CON LOS PROBLEMAS
		if(nTipo != TIPOIN_INTERNO)
			Re_BalanceIntersection(nCaraAct, nEdge, ptoIzq);

		pCaminoPrim = new vtkWay;
		pCaminoPrim->m_ptoIntersec = ptoIzq;
		pCaminoPrim->m_nFace = nCaraAct;
		pCaminoPrim->m_nEdge = nEdge;
		pCaminoPrim->m_nType = nTipo;
		pCaminoPrim->m_nNext = NULL;
		pCaminoPrim->m_nPrev = NULL;
		nNumNodos = 1;
		pCaminoAct = pCaminoPrim;

		CalculateIntersection(nCaraAct, ptoNormPlano, fD, ptoDer, nEdge, nTipo,DIR_TORIGHT); 
		if(nTipo != 0)
			Re_BalanceIntersection(nCaraAct, nEdge, ptoDer);
		
		pCaminoAct->m_nNext = new vtkWay;
		pCaminoAct->m_nNext->m_nPrev = pCaminoAct;
		pCaminoAnt = pCaminoAct;
		pCaminoAct = pCaminoAct->m_nNext;
		pCaminoAct->m_ptoIntersec = ptoDer;
		pCaminoAct->m_nFace = nCaraAct;
		pCaminoAct->m_nEdge = nEdge;
		pCaminoAct->m_nType = nTipo;
		pCaminoAct->m_nNext = NULL;
		nNumNodos++;

		bFinCorte = false;
		while(!bFinCorte){
			nCaraAct = ObtainNextFace(nCaraAct, nEdge);
			nTipoCara = ObtainFaceType(nCaraAct);
			if(nTipoCara == REAL_EDGE)
				if(nCaraIni != nCaraAct){
					CalculateIntersection(nCaraAct, ptoNormPlano, fD, ptoDer, nEdge, nTipo, DIR_TORIGHT);
					if(nTipo != TIPOIN_INTERNO)
						Re_BalanceIntersection(nCaraAct, nEdge, ptoDer);
			
					pCaminoAct->m_nNext = new vtkWay;
					pCaminoAct->m_nNext->m_nPrev = pCaminoAct;
					pCaminoAct = pCaminoAct->m_nNext;
					pCaminoAct->m_ptoIntersec = ptoDer;
					pCaminoAct->m_nFace = nCaraAct;
					pCaminoAct->m_nEdge = nEdge;
					pCaminoAct->m_nType = nTipo;
					pCaminoAct->m_nNext = NULL;
					nNumNodos++;
				}
				else{
					pCaminoAct->m_nPrev->m_nNext = pCaminoPrim;
					pCaminoPrim->m_nPrev = pCaminoAct->m_nPrev;
					pCaminoAct->Delete();
					nNumNodos--;
					bFinCorte = true;
				}
			else
				bFinCorte = true;

			if(nNumNodos > m_nNumPointsT2){
				pCaminoAct = pCaminoPrim;
				for(i = 0; i < (nNumNodos-1); i++){
					pCaminoAct = pCaminoAct->m_nNext;
					pCaminoAct->m_nPrev->Delete();
				}
				pCaminoAct->Delete();

				
				return -5; //ERROR DESCONOCIDO
			}
		}

		if(nCaraIni != nCaraAct){				// Si entramos aqui es porque mirando el corte	
			nCaraAct = pCaminoPrim->m_nFace;    // total a derechas nos encontramos con un hueco
			nEdge = pCaminoPrim->m_nEdge;   // en la malla y tenemos que probar por la izquierda
			pCaminoAct = pCaminoPrim;
			bCortePlano = true;

			bFinCorte = false;
			while(!bFinCorte){
				nCaraAct = ObtainNextFace(nCaraAct, nEdge);
				nTipoCara = ObtainFaceType(nCaraAct);
				if(nTipoCara == REAL_EDGE){
					nNumNodosIzq++;
					CalculateIntersection(nCaraAct, ptoNormPlano, fD, ptoIzq, nEdge, nTipo,DIR_TOLEFT);
					if(nTipo != REAL_EDGE)
						Re_BalanceIntersection(nCaraAct, nEdge, ptoIzq);
			
					pCaminoAct->m_nPrev = new vtkWay;
					pCaminoAct->m_nPrev->m_nNext = pCaminoAct;
					pCaminoAct = pCaminoAct->m_nPrev;
					pCaminoAct->m_ptoIntersec = ptoIzq;
					pCaminoAct->m_nFace = nCaraAct;
					pCaminoAct->m_nEdge = nEdge;
					pCaminoAct->m_nType = nTipo;
					pCaminoAct->m_nPrev = NULL;
					pCaminoPrim = pCaminoAct;
					nNumNodos++;
				}
				else
					bFinCorte = true;

				if(nNumNodos > m_nNumPointsT2){ 
					pCaminoAct = pCaminoPrim;
					for(i = 0; i < (nNumNodos-1); i++){
						pCaminoAct = pCaminoAct->m_nNext;
						pCaminoAct->m_nPrev->Delete();
					}
					pCaminoAct->Delete();
					
					
					return -5; //ERROR DESCONOCIDO
				}
			}
		}

		
		// Ahora que tenemos el camino completo comenzamos a realizar los enganches y demas de los nuevos nodos
		copiaDatosT2->MakeSegurityCopy(this);

		i = 0;
		nNodoDer = nNodoIzq = 0;
		nNumAnadidos = 1; //La inicializaciÃ³n a 0 podrÃ­a inducir a errores
		pNuevosNodos = new Point[6*nNumNodos];
		pNuevaTextura = new Point[6*nNumNodos];
		pnConexiones = new INT3[6*nNumNodos];
		pnTipoConect = new INT3[6*nNumNodos];
		pMuelleso = new POINT3[6*nNumNodos];
		

		pCaminoAct = pCaminoPrim;
		CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos,
			         pnTipoConect, pMuelleso,DIR_INITIALPOINT);
		nNodoDerIni = nNodoDer; nNodoIzqIni = nNodoIzq;
		
		
		
		pCaminoAct = pCaminoAct->m_nNext;
		i++;
		while(i < nNumNodos){
			if(i < nNumNodosIzq)
				CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos, 
				             pnTipoConect, pMuelleso, DIR_TOLEFT);
			else
				CreateConection(pCaminoAct, nNodoDer, nNodoIzq, pNuevosNodos, pNuevaTextura, pnConexiones, nNumAnadidos,
				             pnTipoConect, pMuelleso, DIR_TORIGHT);

			
			pCaminoAct = pCaminoAct->m_nNext;
			i++;
		}
		if(!bCortePlano)
			// Hay que hacer notar que en este momento pCaminoAct apunta al primer
			// elemento de la lista ciclica
			CreateFinalConection(pCaminoAct,nNodoDerIni, nNodoIzqIni, nNodoDer, nNodoIzq, nNumAnadidos, pnConexiones, pMuelleso);
		
		

		break;
	};// del switch
	// una vez hecho el corte y calculado el camino actualizamos la malla t2 y la 
	// triangulacion asociada

	nNumPtosT2 = m_nNumPointsT2;
	pPtosT2 = new Point[nNumPtosT2];
	pTexturaT2 = new Point[nNumPtosT2];
	pPtosT2Ant = new Point[nNumPtosT2];
	panConect = new INT3[nNumPtosT2];
	panTipoConect = new INT3[nNumPtosT2];
	pnTipoPto = new int[nNumPtosT2];
	pnEstadoPto = new int[nNumPtosT2];
	pbInestable = new bool[nNumPtosT2];
	pMuelles = new POINT3[nNumPtosT2];			// Aqui lo que hacemos es la copia
												// de lo que tenemos hasta ahora
	for(i = 0; i < nNumPtosT2; i++){			// para luego fusionarlo 
		pPtosT2[i] = m_pPointsT2[i];			// con lo que tenemos por el corte
		pTexturaT2[i] = m_pTextureT2[i];
		pPtosT2Ant[i] = m_pPrevPointT2[i];
		pnTipoPto[i] = m_pnPointType[i];
		pnEstadoPto[i] = m_pnPointState[i];
		pbInestable[i] = m_pbUnstable[i];
		for(k = 0; k < 3; k++){
			panTipoConect[i][k] = m_panConectionType[i][k];
			if(m_panConect[i][k] < 0){
				panConect[i][k] = -m_panConect[i][k] + nNumPtosT2 - 1;
				if(nTipoCorte != BESS_CLIP)
					pMuelles[i][k]=m_paSpins[i][k];
				else
					pMuelles[i][k]=pPtosT2[i]-pNuevosNodos[-m_panConect[i][k]];
			}
			else{
				panConect[i][k] = m_panConect[i][k];
				pMuelles[i][k] = m_paSpins[i][k];
			}
		}
	}

	delete[] m_pPointsT2; delete[] m_pTextureT2; delete[] m_pPrevPointT2; delete[] m_panConect;
	delete[] m_panConectionType; delete[] m_panAdjacentFaces; delete[] m_pnPointType;
	delete[] m_pnPointState; delete[] m_pNormals; delete[] m_paSpins;
	delete[] m_pbUnstable;
	this->m_pFaces->DeleteAll();

		
	m_nNumPointsT2 = nNumPtosT2 + (nNumAnadidos-1);
	m_pPointsT2 = new Point[m_nNumPointsT2];
	m_pTextureT2 = new Point[m_nNumPointsT2];
	m_pPrevPointT2 = new Point[m_nNumPointsT2];
	m_pnPointType = new int[m_nNumPointsT2];
	m_pnPointState = new int[m_nNumPointsT2];
	m_pbUnstable = new bool[m_nNumPointsT2];
	m_paSpins = new POINT3[m_nNumPointsT2];
	m_panConectionType = new INT3[m_nNumPointsT2];
	m_panConect = new INT3[m_nNumPointsT2];

	for(i = 0; i < nNumPtosT2; i++){
		m_pPointsT2[i] = pPtosT2[i];
		m_pTextureT2[i] = pTexturaT2[i];
		m_pPrevPointT2[i] = pPtosT2Ant[i];
		m_pnPointType[i] = pnTipoPto[i];
		m_pnPointState[i] = pnEstadoPto[i];
		m_pbUnstable[i] = pbInestable[i];
		for(k = 0; k < 3; k++){
			m_paSpins[i][k] = pMuelles[i][k];
			m_panConectionType[i][k] = panTipoConect[i][k];
			m_panConect[i][k] = panConect[i][k];
		}
	}
	delete[] pPtosT2;
	delete[] pTexturaT2;
	delete[] pPtosT2Ant;
	delete[] panConect;
	delete[] panTipoConect;
	delete[] pnTipoPto;
	delete[] pnEstadoPto;
	delete[] pMuelles;

	for(j = 0, i = nNumPtosT2; i < m_nNumPointsT2; i++, j++){
		m_pPrevPointT2[i] = m_pPointsT2[i] = pNuevosNodos[j+1];
		m_pTextureT2[i] = pNuevaTextura[j+1];
		m_pnPointType[i] = 0; m_pnPointState[i] = FREE_STATE;
		m_pbUnstable[i] = true;
		for(k = 0; k < 3; k++){
			m_panConectionType[i][k] = pnTipoConect[(j+1)][k];
			
			if(pnConexiones[j+1][k] < 0){
				m_panConect[i][k] = -pnConexiones[j+1][k] + nNumPtosT2 - 1;
				if (nTipoCorte==BESS_CLIP)
					m_paSpins[i][k] = m_pPointsT2[i] - pNuevosNodos[-pnConexiones[j+1][k]];
				else
					m_paSpins[i][k] = pMuelleso[j+1][k];
			}
			else{
				m_panConect[i][k] = pnConexiones[j+1][k];
				if (nTipoCorte==BESS_CLIP)
					m_paSpins[i][k] = m_pPointsT2[i] - m_pPointsT2[pnConexiones[j+1][k]];
				else
					m_paSpins[i][k] = pMuelleso[j+1][k];
			}
		}
	}
	

	bErrorCorte = false;
	pabMarcado = (BOOL3 *)new BOOL3[m_nNumPointsT2];
	for(i = 0; i < m_nNumPointsT2; i++){
		pabMarcado[i][0] = false;
		pabMarcado[i][1] = false;
		pabMarcado[i][2] = false;
	}
	this->m_pFaces->CreateNodes(3*m_nNumPointsT2);
	m_nNumFaces = 0;
	for(i = 0; (i < m_nNumPointsT2) && !bErrorCorte; i++){	
		for(j = 0; (j < 3) && !bErrorCorte; j++){
			if(!(pabMarcado[i][j])){
				m_pFaces->Item(m_nNumFaces)->numVertex = 0;
				nNodoAnt = i; nNodoSig = -1; nEntradoPor = -1; bCerrado = false;
				nIndConect = j;
				pabMarcado[nNodoAnt][nIndConect] = true;
				while(!bCerrado && !bErrorCorte){
					nNodoSig = m_panConect[nNodoAnt][nIndConect];

					if((nNodoSig < 0) || (nNodoSig >= m_nNumPointsT2) || 
						(m_nNumFaces >= 3*m_nNumPointsT2))
						bErrorCorte = true;
					else
					{
						if(m_panConect[nNodoSig][0]==nNodoAnt) nEntradoPor=0;
						else
							if(m_panConect[nNodoSig][1]==nNodoAnt) nEntradoPor=1;
							else
								if(m_panConect[nNodoSig][2]==nNodoAnt) nEntradoPor=2;
								m_pFaces->Item(m_nNumFaces)->AddVertex(nNodoSig);
								nIndConect = (nEntradoPor+2)%3;
								if(pabMarcado[nNodoSig][nIndConect])
									bCerrado = true;
								else{
									pabMarcado[nNodoSig][nIndConect] = true;
									nNodoAnt = nNodoSig;
								}
					}
				}
				m_nNumFaces++;
			}
		}
	}
	delete[] pabMarcado;

	m_pNormals = new Point[m_nNumPointsT2];
	m_panAdjacentFaces = new INT3[m_nNumPointsT2];
	for(i = 0; (i < m_nNumPointsT2) && !bErrorCorte; i++){
		if(Adjacents(i, panAdy)>0){
			m_pNormals[i] = (m_pFaces->Item(panAdy[0])->normal(m_pPointsT2) +
					m_pFaces->Item(panAdy[1])->normal(m_pPointsT2) +
					m_pFaces->Item(panAdy[2])->normal(m_pPointsT2)) * (1.0f/3.0f);
			m_panAdjacentFaces[i][0] = panAdy[0];
			m_panAdjacentFaces[i][1] = panAdy[1];
			m_panAdjacentFaces[i][2] = panAdy[2];
		}
		else{
			bErrorCorte = true;
			break;
		}
	}


	if(bErrorCorte){
		pCaminoAct = pCaminoPrim;
		for(i = 0; i < (nNumNodos-1); i++){
			pCaminoAct = pCaminoAct->m_nNext;
			pCaminoAct->m_nPrev->Delete();
		}
		
		pCaminoAct->Delete();
		delete[] pNuevosNodos;
		delete[] pNuevaTextura;
		delete[] pnConexiones;
		delete[] pnTipoConect;
		delete[] pMuelleso;

		delete[] m_pPointsT2; delete[] m_pTextureT2; delete[] m_pPrevPointT2; delete[] m_panConect;
		delete[] m_panConectionType; delete[] m_panAdjacentFaces; delete[] m_pnPointType;
		delete[] m_pnPointState; delete[] m_pNormals; m_pFaces->DeleteAll(); delete[] m_paSpins;
		delete[] m_pbUnstable;
		copiaDatosT2->Restore(this);
		
		return -5; //ERROR DESCONOCIDO
	}
	else{
		CopySpinState();
		ObtainTriangulation();
	}

	
	m_bDeformed = true;
	m_bNewVertices=true;

	pCaminoAct = pCaminoPrim;
	for(i = 0; i < (nNumNodos-1); i++){
		pCaminoAct = pCaminoAct->m_nNext;
		pCaminoAct->m_nPrev->Delete();
	}

	m_fCutStep=m_fTipsDistance=0.0f; // simpre hay que fijar estos valores antes de mandar la orden Cut

	pCaminoAct->Delete();
	delete[] pNuevosNodos;
	delete[] pNuevaTextura;
	delete[] pnConexiones;
	delete[] pnTipoConect;
	delete[] pMuelleso;


	//Ahora que ya sabemos que el corte se realizo, comprobamos si el organo contenia
	//liquidos y si el corte se hizo entre dos grapas
	if (m_bContainFluid && nTipoCorte != BESS_CLIP){
		
		copiaDatosT2->Delete();	
		return 1;
	}
	copiaDatosT2->Delete();
	return 0; //EL CORTE SE HA REALIZADO CON Ã‰XITO
}


void vtkT2Mesh::Cauterize(const unsigned uElemento)
{
	int i, j;
	int nCaraT2, nNumVtces;
	int nida, nvuelta, nact, nsig;

	if(m_bDeformSC)
		return;

	nCaraT2 = m_panTriangles[uElemento][0];
	nNumVtces = m_pFaces->Item(nCaraT2)->numVertex;
	
	for(i = 0; i < nNumVtces; i++)
	{
		nact = (*(m_pFaces->Item(nCaraT2)))[i];
		nsig = (*(m_pFaces->Item(nCaraT2)))[(i+1)%nNumVtces];

		for(j = 0; j < 3; j++)
		{
			if(m_panConect[nact][j] == nsig)
				nida = j;
			if(m_panConect[nsig][j] == nact)
				nvuelta = j;
		}

		if(m_panConectionType[nsig][nvuelta] == HOLE_EDGE)
		{
			m_panConectionType[nsig][nvuelta] = UNREAL_EDGE;
			m_panConectionType[nact][nida] = UNREAL_EDGE;
		}
		else{
			if(m_panConectionType[nsig][nvuelta] == REAL_EDGE)
				m_panConectionType[nact][nida] = HOLE_EDGE;
			else{
		  // Code Only for Debug
			/*
				FILE* fd=NULL;
				fd=fopen("cauterize.log","w");
				fprintf(fd,"ID triangulo %d ID cara %d Num Caras %d \n",uElemento,nCaraT2,nNumVtces);
				fprintf(fd,"nact %d nsig %d nvuelta %d \n",nact,nsig,nvuelta);
				fprintf(fd,"Tipo conexion nsig-nvuelta %d\n",m_panConectionType[nsig][nvuelta]);
				fclose(fd);
				exit(30);*/
			}
		}
	}
	
	ObtainTriangulation();
	m_bNewVertices=true;
}

void vtkT2Mesh::FreeInternalForceCalculation(int nIndPto,float fCompensacion){
	// Este metodo permite calcular el desplazamiento para un nodo segun
	// las tensiones de los muelles que lo unen con otros tres nodos
	Point ptoFInt(0.0f,0.0f,0.0f);  // Fuerza Interna nivel 1
	Point ptoGravedad=m_ptoGravityDirection.Unitary()*(-m_fGravity);
	int i;                          // recorrido

	if(m_bDeformSC)
		return;
	if(!m_pbUnstable[nIndPto] && !m_pbUnstable[m_panConect[nIndPto][0]] &&
		!m_pbUnstable[m_panConect[nIndPto][1]] && !m_pbUnstable[m_panConect[nIndPto][2]])
		return;

	for (i=0;i<3;i++){
		if(m_panConectionType[nIndPto][i] != UNREAL_EDGE){
			ptoFInt=ptoFInt + m_paSpins[nIndPto][i] - 
				(m_pPointsT2[nIndPto] - m_pPointsT2[m_panConect[nIndPto][i]]);

		}
	}
	///////////
	/*
	double *ActPoint = new double[3];
	double *PrevPoint = new double[3];
	ActPoint = this->DualMeshPoints->GetPoint(nIndPto);
	PrevPoint = this->PreviousDualMeshPoints->GetPoint(nIndPto);
	ActPoint[0] = ActPoint[0]+(ActPoint[0]-PrevPoint[0])*
						 (1.0f-(float)m_OpcDeform.gamma*(float)m_OpcDeform.inct)+
						 ptoFInt.x*(float)m_OpcDeform.alpha*(float)m_OpcDeform.inct*fCompensacion+
						 ptoGravedad.x*(float)m_OpcDeform.inct;

	ActPoint[1] = ActPoint[1]+(ActPoint[1]-PrevPoint[1])*
						 (1.0f-(float)m_OpcDeform.gamma*(float)m_OpcDeform.inct)+
						 ptoFInt.y*(float)m_OpcDeform.alpha*(float)m_OpcDeform.inct*fCompensacion+
						 ptoGravedad.y*(float)m_OpcDeform.inct;
	ActPoint[2] = ActPoint[2]+(ActPoint[2]-PrevPoint[2])*
						 (1.0f-(float)m_OpcDeform.gamma*(float)m_OpcDeform.inct)+
						 ptoFInt.z*(float)m_OpcDeform.alpha*(float)m_OpcDeform.inct*fCompensacion+
						 ptoGravedad.z*(float)m_OpcDeform.inct;
	this->DualMeshPoints->SetPoint(nIndPto, ActPoint);	*/
	// Aqui actualizamos la nueva posicion del nodo
	m_pPointsT2[nIndPto]=m_pPointsT2[nIndPto]+(m_pPointsT2[nIndPto]-m_pPrevPointT2[nIndPto])*
						 (1.0f-(float)m_OpcDeform.gamma*(float)m_OpcDeform.inct)+
						 ptoFInt*(float)m_OpcDeform.alpha*(float)m_OpcDeform.inct*fCompensacion+
						 ptoGravedad*(float)m_OpcDeform.inct;

	if((m_pPointsT2[nIndPto]-m_pPrevPointT2[nIndPto]).Module() > 0.005)
		m_pbUnstable[nIndPto] = true;
	else
		m_pbUnstable[nIndPto] = false;
		
}


void vtkT2Mesh::InternalForceCalculation(int nIndPto,float fCompensacion){
	// Este metodo permite calcular el desplazamiento para un nodo segun
	// las tensiones de los muelles que lo unen con otros tres nodos
	Point ptoFInt(0.0f,0.0f,0.0f);  // Fuerza Interna nivel 1
	Point ptoGravedad=m_ptoGravityDirection.Unitary()*(m_fGravity);
	int i, j;                          // recorrido
	float dismax, disact;
	Point vecdesp, acum;

	if(m_bDeformSC)
		return;

	if(m_nNumContacts == 0)
	{
		FreeInternalForceCalculation(nIndPto, fCompensacion);
		return;
	}

	if(!m_pbUnstable[nIndPto] && !m_pbUnstable[m_panConect[nIndPto][0]] &&
		!m_pbUnstable[m_panConect[nIndPto][1]] && !m_pbUnstable[m_panConect[nIndPto][2]])
		return;

	for (i=0;i<3;i++){
		if(m_panConectionType[nIndPto][i] != UNREAL_EDGE){
			ptoFInt=ptoFInt + m_paSpins[nIndPto][i] - 
				(m_pPointsT2[nIndPto] - m_pPointsT2[m_panConect[nIndPto][i]]);
		}
	}

	ptoFInt = ptoFInt * 0.2f;
	m_OpcDeform.omega = 0.3;

	for (i=0;i<3;i++){
		if(m_panConectionType[nIndPto][i] != UNREAL_EDGE){
			vecdesp = m_pPointsT2[nIndPto] - m_pPointsT2[m_panConect[nIndPto][i]];
			ptoFInt=ptoFInt + vecdesp.Unitary() * (m_paSpins[nIndPto][i].Module() - 
				vecdesp.Module());// * m_OpcDeform.elast;


		
			if(m_OpcDeform.omega > 0.0f)
				for(j = 0; j < 3; j++)
					if((m_panConect[m_panConect[nIndPto][i]][j] != nIndPto) && 
						(m_panConectionType[m_panConect[nIndPto][i]][j] != UNREAL_EDGE))
					{
						vecdesp = m_pPointsT2[nIndPto] - m_pPointsT2[m_panConect[m_panConect[nIndPto][i]][j]];
						ptoFInt = ptoFInt + vecdesp.Unitary()*
							((m_paSpins[m_panConect[nIndPto][i]][j] + m_paSpins[nIndPto][i]).Module() -
							  vecdesp.Module()) * (m_OpcDeform.omega);//*(m_OpcDeform.elast);

					}
		}
	}
	// Aqui actualizamos la nueva posicion del nodo
	ptoFInt = ptoFInt * 0.8f;
	

	m_pPointsT2[nIndPto]=m_pPointsT2[nIndPto]+(m_pPointsT2[nIndPto]-m_pPrevPointT2[nIndPto])*
						 (1.0f-(float)m_OpcDeform.gamma*(float)m_OpcDeform.inct)+
						 ptoFInt*(float)m_OpcDeform.alpha*2.0f*(float)m_OpcDeform.inct*fCompensacion+
						 ptoGravedad*(float)m_OpcDeform.inct;
	
	if((m_pPointsT2[nIndPto]-m_pPrevPointT2[nIndPto]).Module() > 0.005)
		m_pbUnstable[nIndPto] = true;
	else
		m_pbUnstable[nIndPto] = false;		

	j = 0;
	for(i = 0; i < 3; i++)
	{
		if(m_panConectionType[nIndPto][i] != UNREAL_EDGE){
			vecdesp = m_pPointsT2[nIndPto] - m_pPointsT2[m_panConect[nIndPto][i]];
			disact  = vecdesp.Module();
			dismax  = 1.1f * m_paSpins[nIndPto][i].Module();
			if(disact > dismax)
			{
				acum = acum + vecdesp.Unitary()*dismax + m_pPointsT2[m_panConect[nIndPto][i]];
				j++;
				//Esta serÃ¡ la cara de corte.... se cortarÃ¡ cuando se llame a ColisionForce

				if((m_fMaxDist < 0.0f) || (m_fMaxDist < disact))
				{
					m_fMaxDist = disact;
					m_nCutFace = Neighbour(-1, nIndPto+m_nNumFaces, m_panConect[nIndPto][i]+m_nNumFaces);
				}
			}
		}
	}
	if(j > 0)
		m_pPointsT2[nIndPto] = acum * (1.0f/(float)j);
}



void vtkT2Mesh::LinksPositionCalculation(){
	//Permite calcular la posiciÃ³n de los nodos unidos a otros nodos a travÃ©s de links
	int i, j, nNumLinks;
	unsigned int nNodoTrinicial;
	float afPos[3] = {0.0f, 0.0f, 0.0f}; 
	float afNodoIni[3], afForceIni[3];
	float afForce[] = {0.0f, 0.0f, 0.0f};
	vtkLink *pLinkado;
	Point ptoFInt(0.0f, 0.0f, 0.0f), ptoPos;

	if(m_bDeformSC)
		return;

	nNumLinks = m_lpLinks->GetCount();
	for(i = 0; i < nNumLinks; i++){
		pLinkado = m_lpLinks->Item(i);
		if(pLinkado->IsPrimary(this)){
			pLinkado->GetLinkData(this, &nNodoTrinicial);
			if(m_pnPointType[nNodoTrinicial] == POINTTYPE_DEFORMABLE){
				pLinkado->GetLinkForce(this, afForceIni);
				pLinkado->GetLinkOrigPositionCaller(this, afNodoIni);
				ptoFInt = Point(afForceIni[0], afForceIni[1], afForceIni[2]);
				ptoPos = Point(afNodoIni[0], afNodoIni[1], afNodoIni[2]);

				m_pPointsT2[nNodoTrinicial] = m_pPointsT2[nNodoTrinicial] + 
					(ptoFInt - (m_pPointsT2[nNodoTrinicial] - ptoPos)) 
					*(float)m_OpcDeform.alpha*(float)m_OpcDeform.inct*0.25f;
				for(j = 0; j < 3; j++)
					afPos[j] = m_pPointsT2[nNodoTrinicial][j];
				pLinkado->UpdateLinkInfo(this, afPos, afForce);

				if((m_pPointsT2[nNodoTrinicial]-m_pPrevPointT2[nNodoTrinicial]).Module() > 0.005)
					m_pbUnstable[nNodoTrinicial] = true;
			}
		}
		else{
			pLinkado->GetLinkData(this, &nNodoTrinicial);
			if(m_pnPointType[nNodoTrinicial] == POINTTYPE_DEFORMABLE){
				pLinkado->GetRelativePosition(this, afNodoIni);
				m_pPointsT2[nNodoTrinicial] = 
					Point(afNodoIni[0], afNodoIni[1], afNodoIni[2]);
				for (j=0;j<3;j++)
					if(m_panConectionType[nNodoTrinicial][j] != UNREAL_EDGE)
						ptoFInt=ptoFInt + m_paSpins[nNodoTrinicial][j] - 
							(m_pPointsT2[nNodoTrinicial] - 
							m_pPointsT2[m_panConect[nNodoTrinicial][j]]);
				for(j = 0; j < 3; j++)
					afForce[j] = ptoFInt[j];
				pLinkado->UpdateLinkInfo(this, afPos, afForce);

				if((m_pPointsT2[nNodoTrinicial]-m_pPrevPointT2[nNodoTrinicial]).Module() > 0.0)
					m_pbUnstable[nNodoTrinicial] = true;
				else
					m_pbUnstable[nNodoTrinicial] = false;
				m_pPrevPointT2[nNodoTrinicial] = m_pPointsT2[nNodoTrinicial];
			}
		}
	}
}




void vtkT2Mesh::TotalGrasperPositionCalculation(){
	
}




void vtkT2Mesh::Deform(int iteracion){
	//Calcula nNumIter iteraciones en funciÃ³n de la deformaciÃ³n indicada
	int i, j;
	vtkDataContact *pContactoAct=m_pFirstContact;
	bool bHayPerdidas=false;
	Point ptoGravedad = m_ptoGravityDirection.Unitary()*(-m_fGravity);
	Point ptoDespl, ptoDesplAux;
	Point ptoNormal;
	Point ptoAux;
	float afNuevaposcaras[3];
	float fDireccionMovimiento;
	Point ptoPrueba;
	int nNumLinks,k;               //Variables que permiten la actualizaciÃ³n de los linkados
	unsigned int nNodoLinkado;
	vtkLink *pLinkado=NULL;
	unsigned char *nColisiones = new unsigned char[m_nNumPointsT2];
	Point *ptoRestMov = new Point[m_nNumPointsT2];

	for(i = 0; i < m_nNumPointsT2; i++)
	{
		nColisiones[i] = 0;
	}

	if(m_bDeformSC)
	{
		ReObtainTriangulation();
		m_bDeformSC = false;
	}


	
	nNumLinks = m_lpLinks->GetCount();
	for(i = 0; i < nNumLinks; i++){
		pLinkado = m_lpLinks->Item(i);
		pLinkado->GetLinkData(this, &nNodoLinkado); 
		if(pLinkado->IsPrimary(this))
			if(!pLinkado->IsChanged())
				m_pnPointState[nNodoLinkado] = LINKEDPRIMARY_STATE;
		else
			if(pLinkado->IsChanged())
				m_pnPointState[nNodoLinkado] = LINKEDSECUNDARYARMONIC_STATE;
			else
				m_pnPointState[nNodoLinkado] = LINKEDSECUNDARY_STATE;
	}	

	if(iteracion == 0)
	{

		for(i = 0; i < m_nNumPointsT2; i++)
		{
			this->CenterDisplacementX[i] = 0; // Se inicia una nueva cuenta de desplazamiento de los centros de cada cara
			this->CenterDisplacementY[i] = 0;
			this->CenterDisplacementZ[i] = 0;
		}

		for(i = 0; i < m_nNumContacts; i++){
			vtkContactPoint* pContacti = m_lpContacts->Item(i);
			pContactoAct->m_bTirar = pContacti->GetPullPermit();
			pContactoAct->m_bShift = pContacti->GetShiftValue();
			if ((m_pnPointType[pContactoAct->m_nVtceContacto] == POINTTYPE_DEFORMABLE) && 
				(m_pnPointState[pContactoAct->m_nVtceContacto] != LINKEDSECUNDARY_STATE) &&
				(m_pnPointState[pContactoAct->m_nVtceContacto] != LINKEDSECUNDARYARMONIC_STATE))
			{
				afNuevaposcaras[0] = pContacti->GetCoordX();
				afNuevaposcaras[1] = pContacti->GetCoordY();
				afNuevaposcaras[2] = pContacti->GetCoordZ();
				ptoAux = Point(afNuevaposcaras[0], afNuevaposcaras[1], afNuevaposcaras[2]);
				
				m_pPrevPointT2[pContactoAct->m_nVtceContacto] = m_pPointsT2[pContactoAct->m_nVtceContacto] = ptoAux;

				m_pbUnstable[pContactoAct->m_nVtceContacto] = true;
				
				pContactoAct->m_ptoPos = ptoAux;
			}
			pContactoAct = pContactoAct->m_nNext;
		}

	}


	/* CÃ³digo Paralelizado */

	// Pongo un semaforo a cada thread para sincronizar las finalizaciones de los threads---------------
	for(i=0;i<numprocs;i++)
		{
		#ifdef _WIN32
		hRunSemaphore[i] = CreateSemaphore( NULL, 0, 1, NULL );
		#else
		sem_init(&hRunSemaphore[i],0,0);
		#endif
		
		}
	//--------------------------------------------------------------------------------------------------	
		
	//Lanzamos tantos threads como procesadores tengamos -----------------------------------------------
		vtkMultiThreader *ThreadData=vtkMultiThreader::New();
		ThreadData->SetNumberOfThreads(numprocs);
		ThreadData->SetSingleMethod(CodigoThread,this);
		ThreadData->SingleMethodExecute();


	//Esperamos a que terminen los threads -------------------------------------------------------------
	for(k=0; k<=numprocs-1; k++)
		#ifdef _WIN32
		WaitForSingleObject(hRunSemaphore[k], INFINITE);
		#else
		sem_wait(&hRunSemaphore[k]);
		#endif
	//--------------------------------------------------------------------------------------------------
	
	//Fin CÃ³digo paralelizado --------------------------------------------------------------------------

	/* FCÃ³digo Paralelizado */


	if(iteracion == (m_nNumIter-1))
	{
		pContactoAct = m_pFirstContact;
		for(i=0; i < m_nNumContacts; i++)
		{
			j = pContactoAct->m_nVtceContacto;
			
			if((pContactoAct->m_ptoRestMov).Module() < 0.001)
			{
				m_pPrevPointT2[j] = m_pPointsT2[j] = pContactoAct->m_ptoPos;
				
				nColisiones[j] = 2;
			}
			else
			if(nColisiones[j] < 2)
			{
				ptoAux = m_pPointsT2[j] - m_pPrevPointT2[j];
				
				fDireccionMovimiento = ptoAux * (pContactoAct->m_ptoRestMov).Normalize();
				
				if(fDireccionMovimiento > 0.0f)
				{
					if(nColisiones[j] < 1)
					{
						ptoAux = pContactoAct->m_ptoRestMov * fDireccionMovimiento;
						m_pPrevPointT2[j] = m_pPointsT2[j];
						m_pPointsT2[j] = m_pPointsT2[j] - ptoAux;
						ptoRestMov[j] = pContactoAct->m_ptoRestMov;
						nColisiones[j]++;
					}
					else
						if(nColisiones[j] < 2)
						{
							ptoAux = pContactoAct->m_ptoRestMov - ptoRestMov[j];
							if(ptoAux.Module() > 0.01f)
							{
								m_pPrevPointT2[j] = m_pPointsT2[j] = pContactoAct->m_ptoPos;
								nColisiones[j]++;
							}
						}
				}
			}
				
			pContactoAct = pContactoAct->m_nNext;
		}

		ColisionForce();
		
		ReObtainTriangulation();
		m_bDeformed = true;
	}

	delete nColisiones;
	delete ptoRestMov;
}

void vtkT2Mesh::RemoveRemovedConstraints(){

	return;
}

void vtkT2Mesh::ColisionForce(){
	//Calcula la fuerza que se opone a la deformaciÃ³n causada por las herramientas
	int i, j, k;               
	int nIndPto;
	vtkDataContact *pContactoAct;
	Point ptoFint, ptoAux;
	float fAlfa=(float)m_OpcDeform.alpha, fCompensacion;
	float afFuerzaResistencia[3];
	Point*	pPuntosSCT2;		//Puntos que forman la T2 con los contactos eliminados.
	Point*	pPtosAntSCT2;	//PosiciÃ³n de los puntos de la T2 en la iteraciÃ³n anterior con los contactos eliminados
	Point ptoGravedad=m_ptoGravityDirection.Unitary()*(-m_fGravity);

//	Variables necesarias para el desgarro
	float fFuerza;
	int nFace;
	float fLimite = 4.0f;
	Point ptoInicio, ptoFin;
	float afInicio[3], afFin[3], afReferencia[3];


	pPuntosSCT2 = (Point *)new Point[m_nNumPointsT2];
	pPtosAntSCT2 = (Point *)new Point[m_nNumPointsT2];
	for(i = 0; i < m_nNumPointsT2; i++)
	{
		pPuntosSCT2[i] = m_pPointsT2[i];
		pPtosAntSCT2[i] = m_pPrevPointT2[i];
	}
	for(j = 0; j < m_nNumIter; j++){	
		for(i = 0; i < m_nNumPointsT2; i++){
			if(m_pbUnstable[i] || m_pbUnstable[m_panConect[i][0]] ||
				m_pbUnstable[m_panConect[i][1]] || m_pbUnstable[m_panConect[i][2]])
			{
				if((m_pnPointType[i] == POINTTYPE_DEFORMABLE) && (m_pnPointState[i] != CLIPPED_STATE) && 
					(m_pnPointState[i] != LINKEDSECUNDARY_STATE) && (m_pnPointState[i] != LINKEDSECUNDARYARMONIC_STATE))
				{
					if (m_panConectionType[i][0]==UNREAL_EDGE ||
						m_panConectionType[i][1]==UNREAL_EDGE ||
						m_panConectionType[i][2]==UNREAL_EDGE )
						fCompensacion = 0.66f;
					else
						fCompensacion=1.0f;
					
					ptoAux = pPuntosSCT2[i];
					ptoFint = Point(0.0f, 0.0f, 0.0f, 1.0f);
					for (k=0;k<3;k++){
						if(m_panConectionType[i][k] != UNREAL_EDGE){
							ptoFint=ptoFint + m_paSpins[i][k] - 
								(pPuntosSCT2[i] - pPuntosSCT2[m_panConect[i][k]]);
							
						}
					}
					// Aqui actualizamos la nueva posicion del nodo
					pPuntosSCT2[i]=pPuntosSCT2[i]+(pPuntosSCT2[i]-pPtosAntSCT2[i])*
						(1.0f-(float)m_OpcDeform.gamma*(float)m_OpcDeform.inct)+
						ptoFint*(float)m_OpcDeform.alpha*(float)m_OpcDeform.inct*fCompensacion+
						ptoGravedad*(float)m_OpcDeform.inct;
					pPtosAntSCT2[i] = ptoAux;
				}
			}
		}
	}


	pContactoAct = m_pFirstContact;
	for(i = 0; i < m_nNumContacts; i++){
		vtkContactPoint* pContact = m_lpContacts->Item( i );

		if(m_pnPointType[pContactoAct->m_nVtceContacto] != POINTTYPE_DEFORMABLE)
			fAlfa = 10000;
		else{
			nIndPto = pContactoAct->m_nVtceContacto;
			ptoFint = Point(0.0f, 0.0f, 0.0f, 1.0f);
			ptoFint=pPuntosSCT2[nIndPto] - m_pPointsT2[nIndPto];
		}
		afFuerzaResistencia[0] = ptoFint.x;
		afFuerzaResistencia[1] = ptoFint.y;
		afFuerzaResistencia[2] = ptoFint.z;

		pContact->ForceUpdate(afFuerzaResistencia);

		/* ********************** */
		/* DESGARRO */

		if(m_bCrushed)
			if(((fFuerza = ptoFint.Module()) > m_fThresholdTear) &&
				(m_fThresholdTear > 0.0f)  && (m_nCutFace > 0))	// DESGARRO: VALOR LÃ�MITE PROVISIONAL 
			{
				

				nFace = m_nCutFace;
				ptoInicio = m_pTrPoints[m_panTriangles[nFace][0]] * 0.33f +
					m_pTrPoints[m_panTriangles[nFace][1]] * 0.33f +
					m_pTrPoints[m_panTriangles[nFace][2]] * 0.33f;
				ptoFin = m_pTrPoints[m_panTriangles[nFace][1]] * 0.5f +
					m_pTrPoints[m_panTriangles[nFace][2]] * 0.5f;
				for(k = 0; k < 3; k++)
				{
					afInicio[k] = ptoInicio[k];
					afFin[k] = ptoFin[k];
				}
				
				pContact->GetReferencePoint(afReferencia);
				this->Cut(BESS_CUT_SHEARS, nFace, afInicio, nFace, afFin, afReferencia);

				m_nCutFace = -1;
				m_fMaxDist = -1.0f;
			}
		/* ********************** */
		pContactoAct = pContactoAct->m_nNext;
	}

	delete[] pPuntosSCT2;
	delete[] pPtosAntSCT2;
}


void vtkT2Mesh::ObtainTriangulation(){
	//Obtiene la triangulaciÃ³n dual a la malla simple nTipo 2 actual
	int i=0,j=0, k=0, nCont=0, nValorInd;
	int nNumVtces;
	bool bEsHueco;
	int nTotDescuentos=0;
	Point *pTexCentral;
	// PUNTOS CLAVE DE TRIANGULO PARA EL CÃ�LCULO DE LOS NODOS-COLISIÃ“N
	// D es el centro del triÃ¡ngulo y A-B-C nodos 0-1-2 del triÃ¡ngulo
	Point A[3], D, ptoCalculado; //A[0] es A, A[1] es B, A[2] es C
	//Variables para la obtenciÃ³n de los nodos que se han movido
	//entre iteraciones sucesivas.
	int nInestables;


	//Elmentos que se han movido entre iteraciones sucesivas 
	//(Se supone que se han movido debido a que son inestables)
	nInestables = 0;
	for(i = 0; i < m_nNumPointsT2; i++)
		if(m_pbUnstable[i]) nInestables++;

	if(m_nMovedElements != 0)
	{
		m_nMovedElements = 0;
		delete m_piMovedElements;
	}
	if(nInestables > 0)
		m_piMovedElements = (int *)new int[6*nInestables];
	//FIN de reserva de memoria para el almacenamiento de los nodos
	//que se han movido.

	delete[] m_pTrPoints;
	delete[] m_panTriangles;
	if(m_bExistMesh == true)
	{
		  delete[] m_pnEmptyFaces;
		  delete[] m_pnVertexesCoherence;
	}
	
	m_nNumPointsTr = m_nNumPointsT2+m_nNumFaces;
	m_nNumTriang = 6 * m_nNumPointsT2;

	float vertex[3];
	m_fMaxX=FLT_MIN;
	m_fMaxY=FLT_MIN;
	m_fMaxZ=FLT_MIN;
	m_vCenter[0] = 0.0f;
	m_vCenter[1] = 0.0f;
	m_vCenter[2] = 0.0f;



	m_pnEmptyFaces = new int[m_nNumFaces];
	m_pnVertexesCoherence = new int[m_nNumPointsT2];
	m_pTrPoints = new Point[m_nNumPointsTr];
	m_panTriangles = new INT3[m_nNumTriang];

	pTexCentral = new Point[m_nNumFaces];
	
	for (i=0; i<m_nNumFaces;i++)	{
		m_pnEmptyFaces[i] = nTotDescuentos;
		m_pTrPoints[i] = m_pFaces->Item(i)->Center(m_pPointsT2);
		pTexCentral[i] = m_pFaces->Item(i)->Center(m_pTextureT2);

		for(j = 0; j < 3; j++)
			if(m_panConect[m_pFaces->Item(i)->Vertexes[0]][j] == m_pFaces->Item(i)->Vertexes[1])
				if(m_panConectionType[m_pFaces->Item(i)->Vertexes[0]][j] != REAL_EDGE)
					nTotDescuentos++;

		if(m_pnEmptyFaces[i] != nTotDescuentos)
			m_pnEmptyFaces[i] = nTotDescuentos;
		else{
			nValorInd = i - nTotDescuentos;
			m_afCurrentCoord[nValorInd*3+0] = m_pTrPoints[i].x;
			m_afCurrentCoord[nValorInd*3+1] = m_pTrPoints[i].y;
			m_afCurrentCoord[nValorInd*3+2] = m_pTrPoints[i].z;
			
			vertex[0] = m_pTrPoints[i].x;
			vertex[1] = m_pTrPoints[i].y;
			vertex[2] = m_pTrPoints[i].z;

			m_vCenter[0] += vertex[0];
			m_vCenter[1] += vertex[1];
			m_vCenter[2] += vertex[2];
				
			if (vertex[0] <0 ) vertex[0]*=-1;
			if (vertex[1] <0 ) vertex[1]*=-1;
			if (vertex[2] <0 ) vertex[2]*=-1;

			if (vertex[0] > m_fMaxX ) m_fMaxX=vertex[0];	
			if (vertex[1] > m_fMaxY ) m_fMaxY=vertex[1];
			if (vertex[2] > m_fMaxZ ) m_fMaxZ=vertex[2];
			
		}
	}
	for (i=m_nNumFaces; i<m_nNumPointsTr; i++){
		m_pTrPoints[i]=m_pPointsT2[i-m_nNumFaces];

		k = 0; m_pnVertexesCoherence[i-m_nNumFaces] = nTotDescuentos;
		for(j = 0; j < 3; j++)
			if(m_panConectionType[i-m_nNumFaces][j] == UNREAL_EDGE)
				k++;
		if(k == 3)
			nTotDescuentos++;
		if(m_pnVertexesCoherence[i-m_nNumFaces] != nTotDescuentos)
			m_pnVertexesCoherence[i-m_nNumFaces] = nTotDescuentos;
		else
		{
			nValorInd = i - nTotDescuentos;
			m_afCurrentCoord[nValorInd*3+0] = m_pTrPoints[i].x;
			m_afCurrentCoord[nValorInd*3+1] = m_pTrPoints[i].y;
			m_afCurrentCoord[nValorInd*3+2] = m_pTrPoints[i].z;
		}
	}
	for (i=0; i<m_nNumFaces; i++){
		nNumVtces = m_pFaces->Item(i)->numVertex; 
		bEsHueco = false;
		for(j = 0; j < 3; j++)
			if(m_panConect[m_pFaces->Item(i)->Vertexes[0]][j] == m_pFaces->Item(i)->Vertexes[1])
				if(m_panConectionType[m_pFaces->Item(i)->Vertexes[0]][j] != REAL_EDGE)
					bEsHueco = true;
		if(!bEsHueco)
			for (j=0; j<nNumVtces; j++){
		    //Recorremos los vÃ©rtices de la cara
				m_panTriangles[nCont][0] = i;
				m_panTriangles[nCont][1] = m_pFaces->Item(i)->Vertexes[j]+m_nNumFaces;
				m_panTriangles[nCont][2] = m_pFaces->Item(i)->Vertexes[(j+1)%nNumVtces]+m_nNumFaces;

				//ALMACENAMIENTO en la lista de elementos inestables de aquellos que tienen, al menos
				//un vÃ©rtice inestable.
				if(m_pbUnstable[m_pFaces->Item(i)->Vertexes[j]] || 
					m_pbUnstable[m_pFaces->Item(i)->Vertexes[(j+1)%nNumVtces]])
				{
					m_piMovedElements[m_nMovedElements] = nCont;
					m_nMovedElements++;
				}

				m_afTextureCoord[(nCont*3 + 0)*3 + 0] = pTexCentral[i].x;
				m_afTextureCoord[(nCont*3 + 0)*3 + 1] = pTexCentral[i].y;
				m_afTextureCoord[(nCont*3 + 0)*3 + 2] = pTexCentral[i].z;

				m_afTextureCoord[(nCont*3 + 1)*3 + 0] = 
					m_pTextureT2[m_pFaces->Item(i)->Vertexes[j]].x;
				m_afTextureCoord[(nCont*3 + 1)*3 + 1] = 
					m_pTextureT2[m_pFaces->Item(i)->Vertexes[j]].y;
				m_afTextureCoord[(nCont*3 + 1)*3 + 2] = 
					m_pTextureT2[m_pFaces->Item(i)->Vertexes[j]].z;
				m_afTextureCoord[(nCont*3 + 2)*3 + 0] = 
					m_pTextureT2[m_pFaces->Item(i)->Vertexes[(j+1)%nNumVtces]].x;
				m_afTextureCoord[(nCont*3 + 2)*3 + 1] = 
					m_pTextureT2[m_pFaces->Item(i)->Vertexes[(j+1)%nNumVtces]].y;
				m_afTextureCoord[(nCont*3 + 2)*3 + 2] = 
					m_pTextureT2[m_pFaces->Item(i)->Vertexes[(j+1)%nNumVtces]].z;

				m_auNodePtr[nCont*3+0] = i - m_pnEmptyFaces[i];
				m_auNodePtr[nCont*3+1] = m_pFaces->Item(i)->Vertexes[j]+m_nNumFaces - 
					m_pnVertexesCoherence[m_pFaces->Item(i)->Vertexes[j]];
				m_auNodePtr[nCont*3+2] = m_pFaces->Item(i)->Vertexes[(j+1)%nNumVtces]+m_nNumFaces - 
					m_pnVertexesCoherence[m_pFaces->Item(i)->Vertexes[(j+1)%nNumVtces]];
				nCont++;
			}
	}
	m_uNNodes = m_nNumPointsTr - nTotDescuentos;
	m_uNEl = nCont;
	m_nNumTriang = nCont;
	m_uNCollisions = m_nNumPointsT2;

	for(i = 0; i < m_nNumPointsT2; i++)
	{
		m_afCollisionCoordAnt[i*3+0] = m_afCollisionCoord[i*3+0] = m_pPointsT2[i].x;
		m_afCollisionCoordAnt[i*3+1] = m_afCollisionCoord[i*3+1] = m_pPointsT2[i].y;
		m_afCollisionCoordAnt[i*3+2] = m_afCollisionCoord[i*3+2] = m_pPointsT2[i].z;
	}

	delete[] pTexCentral;

	//AquÃ­ se crea la lista de nodos (vÃ©rtices) que han sido -posiblemente- movidos o creados
	//despuÃ©s de la Ãºltima iteraciÃ³n
	bool bNoEsta;

	if(m_MovedMoved != 0)
	{
		m_MovedMoved = 0;
		delete[] m_piMovedMoved;
		m_piMovedMoved = NULL;
	}
	if(m_nMovedElements > 0)
		m_piMovedMoved = (int *)new int[3*m_nMovedElements];

	for(i = 0; i < m_nMovedElements; i++)
	{
		for(j = 0; j < 3; j++)
		{
			bNoEsta = true;
			for(k = 0; (k < m_MovedMoved) && bNoEsta; k++) 
				if(m_piMovedMoved[k] == m_auNodePtr[m_piMovedElements[i]*3 + j])
					bNoEsta = false;

			if(bNoEsta)
			{
				m_piMovedMoved[m_MovedMoved] = m_auNodePtr[m_piMovedElements[i]*3 + j];
				m_MovedMoved++;
			}
		}
	}
}

void vtkT2Mesh::ReObtainTriangulation(){
	//Reobtiene la triangulaciÃ³n dual a la malla simple nTipo 2 actual
	//i.e., la nueva posiciÃ³n de los nodos de la malla dual
	int i=0, j=0 , k=0 ,  nCont=0;
	int nValorInd;
	int nValorAct=0;
	int nNumVtces;
	bool bEsHueco;
	int numpos = m_nNumPointsT2*3;
	//Variables para la obtenciÃ³n de los nodos que se han movido
	//entre iteraciones sucesivas.
	int nInestables;

	//Elmentos que se han movido entre iteraciones sucesivas 
	//(Se supone que se han movido debido a que son inestables)
	nInestables = 0;
	for(i = 0; i < m_nNumPointsT2; i++)
		if(m_pbUnstable[i]) nInestables++;

	if(m_nMovedElements != 0)
	{
		m_nMovedElements = 0;
		delete m_piMovedElements;
	}
	if(nInestables > 0)
		m_piMovedElements = (int *)new int[6*nInestables];
	//FIN de reserva de memoria para el almacenamiento de los nodos
	//que se han movido.
	
	for (i=0;i<numpos;i++) m_afCollisionCoordAnt[i] = m_afCollisionCoord[i];
//	Point pTexCentral;

	for (i=0; i<m_nNumFaces;i++){
		m_pTrPoints[i] = m_pFaces->Item(i)->Center(m_pPointsT2);
//		pTexCentral = m_pFaces[i].Center(m_pTextureT2);

		if(nValorAct != m_pnEmptyFaces[i]) //Detecta la llegada de un vÃ©rtice que no es Ãºtil en la triangulaciÃ³n
			nValorAct = m_pnEmptyFaces[i];
		else{
			nValorInd = i - nValorAct;
			m_afCurrentCoord[nValorInd*3+0] = m_pTrPoints[i].x;
			m_afCurrentCoord[nValorInd*3+1] = m_pTrPoints[i].y;
			m_afCurrentCoord[nValorInd*3+2] = m_pTrPoints[i].z;

		}
	}
	for (i=m_nNumFaces, j = 0; i<m_nNumPointsTr; i++, j++){	
		m_pTrPoints[i] = m_pPointsT2[i-m_nNumFaces];

		if(nValorAct != m_pnVertexesCoherence[j])
			nValorAct = m_pnVertexesCoherence[j];
		else
		{
			nValorInd = i - nValorAct;
			m_afCurrentCoord[nValorInd*3+0] = m_pTrPoints[i].x;
			m_afCurrentCoord[nValorInd*3+1] = m_pTrPoints[i].y;
			m_afCurrentCoord[nValorInd*3+2] = m_pTrPoints[i].z;
		}
	}

	for (i=0; i<m_nNumFaces; i++){
		nNumVtces = m_pFaces->Item(i)->numVertex; 
		bEsHueco = false;
		for(j = 0; j < 3; j++)
			if(m_panConect[m_pFaces->Item(i)->Vertexes[0]][j] == m_pFaces->Item(i)->Vertexes[1])
				if(m_panConectionType[m_pFaces->Item(i)->Vertexes[0]][j] != REAL_EDGE)
					bEsHueco = true;
		if(!bEsHueco)
			for (j=0; j<nNumVtces; j++){

				//ALMACENAMIENTO en la lista de elementos inestables de aquellos que tienen, al menos
				//un vÃ©rtice inestable.
				if(m_pbUnstable[m_pFaces->Item(i)->Vertexes[j]] || 
					m_pbUnstable[m_pFaces->Item(i)->Vertexes[(j+1)%nNumVtces]])
				{
					m_piMovedElements[m_nMovedElements] = nCont;
					m_nMovedElements++;
				}

				nCont++;
			}
	}
	
	m_uNCollisions = m_nNumPointsT2;

	for(i = 0; i < m_nNumPointsT2; i++)
	{
		m_afCollisionCoord[i*3+0] = m_pPointsT2[i].x;
		m_afCollisionCoord[i*3+1] = m_pPointsT2[i].y;
		m_afCollisionCoord[i*3+2] = m_pPointsT2[i].z;
	}
	
	//AquÃ­ se crea la lista de nodos (vÃ©rtices) que han sido -posiblemente- movidos despuÃ©s
	//de la Ãºltima iteraciÃ³n
	bool bNoEsta;

	if(m_MovedMoved != 0)
	{
		m_MovedMoved = 0;
		delete[] m_piMovedMoved;
		m_piMovedMoved=NULL;
	}
	if(m_nMovedElements > 0)
		m_piMovedMoved = (int *)new int[3*m_nMovedElements];

	for(i = 0; i < m_nMovedElements; i++)
	{
		for(j = 0; j < 3; j++)
		{
			bNoEsta = true;
			for(k = 0; (k < m_MovedMoved) && bNoEsta; k++) 
				if(m_piMovedMoved[k] == m_auNodePtr[m_piMovedElements[i]*3 + j])
					bNoEsta = false;

			if(bNoEsta)
			{
				m_piMovedMoved[m_MovedMoved] = m_auNodePtr[m_piMovedElements[i]*3 + j];
				m_MovedMoved++;
			}
		}
	}
}


void vtkT2Mesh::ContactLost( vtkContactPoint* c_pContact ){
	//Elimina un contacto de la lista de contactos
	int i, j;
	int nRestriccion, nVerticeContacto;
	vtkDataContact *pContactoAct, *pContactoAux;
	bool bPermiteTirar, bPinzaEliminada;
	//Variables necesarias para la eliminaciÃ³n de transformaciones de links
	vtkLink *pLinkado;
	int nNumLinks;
	int nConexion;
	unsigned int nNodoLinkado;

	nRestriccion = vtkOrgan::ContactID(c_pContact);
    vtkOrgan::ContactLost( c_pContact );

	pContactoAct = m_pFirstContact;
	if(m_nNumContacts == 1){
		nVerticeContacto = m_pFirstContact->m_nVtceContacto;
		bPermiteTirar = m_pFirstContact->m_bTirar;
		pContactoAux = m_pFirstContact;
		m_pFirstContact = m_pLastContact = NULL;
	}
	else{
		if(nRestriccion == 0){
			nVerticeContacto = m_pFirstContact->m_nVtceContacto;
			bPermiteTirar = m_pFirstContact->m_bTirar;
			m_pFirstContact = m_pFirstContact->m_nNext;
			pContactoAux = pContactoAct;
			m_pFirstContact->m_nPrev = NULL;
		}
		else
			if(nRestriccion == (m_nNumContacts - 1)){
				nVerticeContacto = m_pLastContact->m_nVtceContacto;
				bPermiteTirar = m_pLastContact->m_bTirar;
				m_pLastContact = m_pLastContact->m_nPrev;
				pContactoAux = m_pLastContact->m_nNext;
				m_pLastContact->m_nNext = NULL;
			}
			else{
				for(i = 0; i < nRestriccion; i++) 
					pContactoAct = pContactoAct->m_nNext;
				nVerticeContacto = pContactoAct->m_nVtceContacto;
				bPermiteTirar = pContactoAct->m_bTirar;
	  			pContactoAux = pContactoAct;
				pContactoAct = pContactoAct->m_nNext;
				(pContactoAux->m_nPrev)->m_nNext = pContactoAct;
				pContactoAct->m_nPrev = pContactoAux->m_nPrev;
			}
	}
	
	

	bPinzaEliminada = false;

	if(!m_lpLinks->IsEmpty()){
		nNumLinks = m_lpLinks->GetCount();
		for(i = 0; i < nNumLinks; i++){
			pLinkado = m_lpLinks->Item(i);
			pLinkado->GetLinkData(this, &nNodoLinkado); 
			if((int)nNodoLinkado == pContactoAux->m_nVtceContacto)
				if((m_pnPointState[pContactoAux->m_nVtceContacto] == LINKEDPRIMARY_STATE) &&
					pLinkado->IsChanged()){
					pLinkado->ChangePriority();
					m_pnPointState[pContactoAux->m_nVtceContacto] = LINKEDSECUNDARY_STATE;
				}
		}
		for(i = 0; i < nNumLinks; i++){
			pLinkado = m_lpLinks->Item(i);
			pLinkado->GetLinkData(this, &nNodoLinkado); 
			for(j = 0; j < 3; j++)
				if(m_panConect[pContactoAux->m_nVtceContacto][j] == (int)nNodoLinkado){
					nConexion = m_panConect[pContactoAux->m_nVtceContacto][j];
					if((m_pnPointState[nConexion] == LINKEDPRIMARYARMONIC_STATE) &&
						(m_pnPointState[m_panConect[nConexion][0]] != LINKEDPRIMARY_STATE) &&
						(m_pnPointState[m_panConect[nConexion][1]] != LINKEDPRIMARY_STATE) &&
						(m_pnPointState[m_panConect[nConexion][2]] != LINKEDPRIMARY_STATE) &&
						pLinkado->IsChanged())
					{
						pLinkado->ChangePriority();
						m_pnPointState[nConexion] = LINKEDSECUNDARY_STATE;
					}
				}
		}
	}

	pContactoAux->Delete();
    m_nNumContacts = m_nNumContacts - 1;
}

void vtkT2Mesh::SetAlphaParameter(float valor) 
{
	m_OpcDeform.alpha=valor;
}
void vtkT2Mesh::SetGammaParameter(float valor)
{
	m_OpcDeform.gamma=valor;
}
void vtkT2Mesh::SetOmmegaParameter(float valor)
{
	m_OpcDeform.omega=valor;
}

void vtkT2Mesh::PrintSelf(ostream &os, vtkIndent indent) {
	this->Superclass::PrintSelf(os,indent);
	os << indent << "Alpha Parameter: " << this->m_OpcDeform.alpha << "\n";
	os << indent << "Gamma Parameter: " << this->m_OpcDeform.gamma << "\n";
	os << indent << "Ommega Parameter: " << this->m_OpcDeform.omega << "\n";
	os << indent << "Gravedad: " << this->m_fGravity << "\n";

	os << indent << "Direccion de Gravedad: " << this->m_cOrientOfGravity << endl;
	os << indent << "Hay Malla?: " << this->m_bExistMesh << endl;
}
