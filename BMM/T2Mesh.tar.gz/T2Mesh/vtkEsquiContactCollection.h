/*=========================================================================*/
// .NAME vtkEsquiContactCollectionCollection - a list of deformable organs
// .SECTION Description
// vtkEsquiContactCollectionCollection represents and provides methods to manipulate a list of
// vtkEsquiContactCollection (i.e., vtkTool and subclasses). The list is unsorted and duplicate
// entries are not prevented.

// .SECTION see also
// vtkCollection vtkEsquiContactCollection

#ifndef __vtkEsquiContactCollection_h
#define __vtkEsquiContactCollection_h

#include "vtkEsquiCollection.h"
#include "vtkesquiT2MeshWin32Header.h"
class vtkContactPoint;

//!  A list of Contacts
/*! 
   vtkEsquiContactCollection represents and provides methods to manipulate a list of
   Contacts (i.e., vtkContact and subclasses). The list is unsorted and duplicate
   entries are not prevented.

   \sa vtkCollection, vtkContact
*/
class VTK_ESQUI_T2MESH_EXPORT vtkEsquiContactCollection: public vtkEsquiCollection
{
 public:
  static vtkEsquiContactCollection *New();
  vtkTypeRevisionMacro(vtkEsquiContactCollection,vtkEsquiCollection);
  virtual void PrintSelf(ostream& os, vtkIndent indent);

  // Description:
  // Add a Organ to the list.
  //! Add a Contact to the list.
  vtkIdType Append(vtkContactPoint *object);
  //! Returns the Contact on i position.
  vtkContactPoint *Item(vtkIdType i);
  //! Returns the first Contact.
  vtkContactPoint *GetFirst();
  //! Returns the position of contact.
  vtkIdType Find(vtkContactPoint *object);
  //! Returns the position of contact.
  vtkIdType IndexOf(vtkContactPoint *object);

protected:
  vtkEsquiContactCollection() {};
  ~vtkEsquiContactCollection() {};

private:
  vtkEsquiContactCollection(const vtkEsquiContactCollection&);  // Not implemented.
  void operator=(const vtkEsquiContactCollection&);		  // Not implemented.
};


#endif
