/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkmyCommonWin32Header.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
// .NAME vtkmyCommonWin32Header - manage Windows system differences
// .SECTION Description
// The vtkmyCommonWin32Header captures some system differences between Unix
// and Windows operating systems. 

#ifndef __vtkesquiT2MeshWin32Header_h
#define __vtkesquiT2MeshWin32Header_h

#include "vtkESQUIConfigure.h"

#if defined(_WIN32)
  #if defined(vtkesquiT2Mesh_EXPORTS)
    #define VTK_ESQUI_T2MESH_EXPORT __declspec(dllexport)
  #else
	#undef VTK_ESQUI_T2MESH_EXPORT
	#define VTK_ESQUI_T2MESH_EXPORT __declspec( dllimport ) 
  #endif

#else
  #define VTK_ESQUI_T2MESH_EXPORT
#endif

#endif
