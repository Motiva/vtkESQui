#include "vtkPolyDataReader.h"
#include "vtkesquiT2MeshWin32Header.h"

class vtkEsquiPolyData;
class vtkT2Mesh;
// Clase para la lectura de los modelos deformables
/* 
	\sa vtkPolyDataReader

*/
//! Class to read the deformable models
class VTK_ESQUI_T2MESH_EXPORT vtkEsquiPolyDataReader: public vtkPolyDataReader 
{
public:
	static vtkEsquiPolyDataReader *New();
	vtkTypeRevisionMacro(vtkEsquiPolyDataReader,vtkPolyDataReader);
	const char* GetClassName() {return "vtkEsquiPolyDataReader";}
	void PrintSelf(ostream &os, vtkIndent indent);
	
	void SetName(char *Name);
	const char* GetName();
	// Devuelve el modelo deformable leido
	//! Return the read deformable model
	vtkT2Mesh* GetOrgan();
private:
	vtkEsquiPolyDataReader(const vtkEsquiPolyDataReader &);
	void operator = (const vtkEsquiPolyDataReader &);

protected:
	vtkEsquiPolyDataReader() {};
	~vtkEsquiPolyDataReader() {};
	char *Name;

};
