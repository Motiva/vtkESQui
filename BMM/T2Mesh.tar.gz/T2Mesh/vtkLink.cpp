///////////////////////////////////////////////////////////////////////////////////
//
// Este fichero contiene la implementacion de los metodos de la clase vtkLink
//
///////////////////////////////////////////////////////////////////////////////////

#include "vtkLink.h"
#include "vtkObjectFactory.h"
#include "vtkOrgan.h"

vtkCxxRevisionMacro(vtkLink, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkLink);
void vtkLink::PrintSelf(ostream& os,vtkIndent indent) {
	this->Superclass::PrintSelf(os,indent);
}

void vtkLink::SetLinkData(vtkOrgan* pPrimary,UINT nPId,float* afPPoint,float* afPForce,
						vtkOrgan* pSecondary,UINT nSId,float* afSPoint,float* afSForce){
	
	assert( pPrimary!=NULL && pSecondary!=NULL);
	m_pPrimary=pPrimary;
	m_nPId=nPId;
	m_afPPoint[0]=afPPoint[0];
	m_afPPoint[1]=afPPoint[1];
	m_afPPoint[2]=afPPoint[2];
	m_afPPointOrig[0]=afPPoint[0];
	m_afPPointOrig[1]=afPPoint[1];
	m_afPPointOrig[2]=afPPoint[2];
	m_afPForce[0]=afPForce[0];
	m_afPForce[1]=afPForce[1];
	m_afPForce[2]=afPForce[2];
		
	m_pSecondary=pSecondary;
	m_nSId=nSId;
	m_afSPoint[0]=afSPoint[0];
	m_afSPoint[1]=afSPoint[1];
	m_afSPoint[2]=afSPoint[2];
	m_afSPointOrig[0]=afSPoint[0];
	m_afSPointOrig[1]=afSPoint[1];
	m_afSPointOrig[2]=afSPoint[2];
	m_afSForce[0]=afSForce[0];
	m_afSForce[1]=afSForce[1];
	m_afSForce[2]=afSForce[2];

	m_afIniDispl[0]=m_afSPoint[0]-m_afPDispl[0];
	m_afIniDispl[1]=m_afSPoint[1]-m_afPDispl[1];
	m_afIniDispl[2]=m_afSPoint[2]-m_afPDispl[2];

	m_afPDispl[0]=m_afPDispl[1]=m_afPDispl[2]=0.0f;
	m_afSDispl[0]=m_afSDispl[1]=m_afSDispl[2]=0.0f;
	m_bEnabled=true;
	m_bChanged=false;
	m_nRef=2;
}

void vtkLink::SetLinkData(vtkOrgan* pCaller,UINT nId,float* afPoint,float* afForce){

	if (pCaller==m_pPrimary){
		m_nPId=nId;
		if (afPoint!=NULL){
			m_afPPoint[0]=afPoint[0];
			m_afPPoint[1]=afPoint[1];
			m_afPPoint[2]=afPoint[2];
			m_afPPointOrig[0]=afPoint[0];
			m_afPPointOrig[1]=afPoint[1];
			m_afPPointOrig[2]=afPoint[2];
		}
		if (afForce!=NULL){
			m_afPForce[0]=afForce[0];
			m_afPForce[1]=afForce[1];
			m_afPForce[2]=afForce[2];
		}
	}
	else{
		m_nSId=nId;
		if (afPoint!=NULL){
			m_afSPoint[0]=afPoint[0];
			m_afSPoint[1]=afPoint[1];
			m_afSPoint[2]=afPoint[2];
			m_afSPointOrig[0]=afPoint[0];
			m_afSPointOrig[1]=afPoint[1];
			m_afSPointOrig[2]=afPoint[2];
		}
		if (afForce!=NULL){
			m_afSForce[0]=afForce[0];
			m_afSForce[1]=afForce[1];
			m_afSForce[2]=afForce[2];
		}
	}
	m_afIniDispl[0]=m_afSPoint[0]-m_afPPoint[0];
	m_afIniDispl[1]=m_afSPoint[1]-m_afPPoint[1];
	m_afIniDispl[2]=m_afSPoint[2]-m_afPPoint[2];
}

void vtkLink::GetLinkData(vtkOrgan* pCaller,UINT* pId,float* afPoint,float* afForce) const{

	if (pCaller==m_pPrimary){
		*pId=m_nPId;
		if (afPoint!=NULL){
			afPoint[0]=m_afPPoint[0];
			afPoint[1]=m_afPPoint[1];
			afPoint[2]=m_afPPoint[2];
		}
		if (afForce!=NULL){
			afForce[0]=m_afPForce[0];
			afForce[1]=m_afPForce[1];
			afForce[2]=m_afPForce[2];
		}
	}
	else{
		*pId=m_nSId;
		if (afPoint!=NULL){
			afPoint[0]=m_afSPoint[0];
			afPoint[1]=m_afSPoint[1];
			afPoint[2]=m_afSPoint[2];
		}
		if (afForce!=NULL){
			afForce[0]=m_afSForce[0];
			afForce[1]=m_afSForce[1];
			afForce[2]=m_afSForce[2];
		}
	}
}

void vtkLink::UpdateLinkInfo(const vtkOrgan* pCaller,float* afPosition, float* afForce){
	int i;

	if (pCaller==m_pPrimary){
		for (i=0;i<3;i++){
			m_afPDispl[i]=afPosition[i]-m_afPPointOrig[i];
			m_afPPoint[i]=afPosition[i];
			m_afPForce[i]=afForce[i];
		}
	}
	else{
		if (pCaller==m_pSecondary){
			for (i=0;i<3;i++){
				m_afSDispl[i]=afPosition[i]-m_afSPointOrig[i];
				m_afSPoint[i]=afPosition[i];
				m_afSForce[i]=afForce[i];
			}
		}
	}
}

void vtkLink::GetLinkShift(const vtkOrgan* pCaller,float* afShift) const{

	afShift[0]=afShift[1]=afShift[2]=0.0f;
	if (m_bEnabled){
		if (pCaller==m_pPrimary){
			afShift[0]=m_afSDispl[0];
			afShift[1]=m_afSDispl[1];
			afShift[2]=m_afSDispl[2];
		}
		else
			if (pCaller==m_pSecondary){
				afShift[0]=m_afPDispl[0];
				afShift[1]=m_afPDispl[1];
				afShift[2]=m_afPDispl[2];
			}
	}
}

void vtkLink::GetLinkForce(const vtkOrgan* pCaller, float* afForce) const{
	
	if (pCaller==m_pPrimary){
		afForce[0]=m_afSForce[0];
		afForce[1]=m_afSForce[1];
		afForce[2]=m_afSForce[2];
	}
	else 
		if (pCaller==m_pSecondary){
			afForce[0]=m_afPForce[0];
			afForce[1]=m_afPForce[1];
			afForce[2]=m_afPForce[2];
		}
}

void vtkLink::GetLinkPosition(const vtkOrgan* pCaller, float* afPosition) const{
	
	if (pCaller==m_pPrimary){
		afPosition[0]=m_afSPoint[0];
		afPosition[1]=m_afSPoint[1];
		afPosition[2]=m_afSPoint[2];
	}
	else 
		if (pCaller==m_pSecondary){
			afPosition[0]=m_afPPoint[0];
			afPosition[1]=m_afPPoint[1];
			afPosition[2]=m_afPPoint[2];
		}
}

void vtkLink::GetLinkOrigPositionCaller(const vtkOrgan* pCaller, float* afPosition) const{
	
	if (pCaller==m_pSecondary){
		afPosition[0]=m_afSPointOrig[0];
		afPosition[1]=m_afSPointOrig[1];
		afPosition[2]=m_afSPointOrig[2];
	}
	else 
		if (pCaller==m_pPrimary){
			afPosition[0]=m_afPPointOrig[0];
			afPosition[1]=m_afPPointOrig[1];
			afPosition[2]=m_afPPointOrig[2];
		}
}

void vtkLink::GetRelativePosition(const vtkOrgan* pCaller, float* afPosition) const{

	if (pCaller==m_pPrimary){
		switch (m_fgUpdateType){
		case UM_POSITION:
			afPosition[0]=m_afSPoint[0];
			afPosition[1]=m_afSPoint[1];
			afPosition[2]=m_afSPoint[2];
			break;
		case UM_SHIFT:
			afPosition[0]=m_afSPoint[0]-m_afIniDispl[0];
		    afPosition[1]=m_afSPoint[1]-m_afIniDispl[1];
		    afPosition[2]=m_afSPoint[2]-m_afIniDispl[2];
			break;
		}
	}
	else 
		if (pCaller==m_pSecondary){
			switch (m_fgUpdateType){
			case UM_POSITION:
				afPosition[0]=m_afPPoint[0];
				afPosition[1]=m_afPPoint[1];
				afPosition[2]=m_afPPoint[2];
				break;
			case UM_SHIFT:
				afPosition[0]=m_afPPoint[0]+m_afIniDispl[0];
				afPosition[1]=m_afPPoint[1]+m_afIniDispl[1];
				afPosition[2]=m_afPPoint[2]+m_afIniDispl[2];
				break;
			}
		}
}
	
void vtkLink::ChangePriority(){
	vtkOrgan* pOrgan=NULL;
	UINT    nId;
	float   afPoint[3];
	int i;
	// Lo que hace este metodo es intercambiar toda la informacion de forma que
	// el primario pasa a ser secundario y el secundario a primario
	pOrgan=m_pPrimary;
	m_pPrimary=m_pSecondary;
	m_pSecondary=pOrgan;

	nId=m_nPId;
	m_nPId=m_nSId;
	m_nSId=nId;

	for (i=0;i<3;i++){
		// cambio de las coordenadas actuales
		afPoint[i]=m_afPPoint[i];
		m_afPPoint[i]=m_afSPoint[i];
		m_afSPoint[i]=afPoint[i];

		// cambio del ultimo valor calculado para el desplazamiento
		afPoint[i]=m_afPDispl[i];
		m_afPDispl[i]=m_afSDispl[i];
		m_afSDispl[i]=afPoint[i];
	}
	// por ultimo invertimos el vector desplazamiento inicial entre la posicion
	// del nodo primario y la del secundario
	m_afIniDispl[0]=-m_afIniDispl[0];
	m_afIniDispl[1]=-m_afIniDispl[1];
	m_afIniDispl[2]=-m_afIniDispl[2];

	m_bChanged=!m_bChanged;
}

bool vtkLink::IsPrimary(const vtkOrgan* pCaller) const{
	
	if (pCaller==m_pPrimary)
		return true;
	else
		return false;
}

void vtkLink::UnRef(){

	m_nRef--;
	if (m_nRef<=0)
		this->Delete();
}
