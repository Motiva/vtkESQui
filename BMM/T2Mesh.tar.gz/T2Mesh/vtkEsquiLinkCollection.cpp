#include "vtkEsquiLinkCollection.h"

#include "vtkObjectFactory.h"
#include "vtkLink.h"

vtkCxxRevisionMacro(vtkEsquiLinkCollection, "$Revision: 0.1 $");
vtkStandardNewMacro(vtkEsquiLinkCollection);

vtkIdType vtkEsquiLinkCollection::Append(vtkLink *a) {
	this->vtkEsquiCollection::InsertObject((vtkObject *) a);
	return (this->GetNumberOfItems() -1);
}
vtkLink* vtkEsquiLinkCollection::Item(vtkIdType Posicion) {
	return static_cast <vtkLink *> (this->vtkCollection::GetItemAsObject((int) Posicion));
}
vtkLink* vtkEsquiLinkCollection::GetFirst() {
	if (this->GetNumberOfItems()!=0) {
		return this->Item(0);
	}else {
		return NULL;
	}
}
void vtkEsquiLinkCollection::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
}
vtkIdType vtkEsquiLinkCollection::Find(vtkLink *object) {
	return this->Superclass::Find((vtkObject*) object);
}
vtkIdType vtkEsquiLinkCollection::IndexOf(vtkLink *object) {
	return this->Superclass::IndexOf((vtkObject*) object);
}
