/*
--------------------
Program: ESQUI
Info and Bugs: {marf,rsantana}@ctm.ulpgc.es 
-------------------------------------------

Copyright (c) 2006, Center for Technology in Medicine, University of Las Palmas
de Gran Canaria (Canary Islands, Spain).
All rights reserved.

This program is free software; you can redistribute it and/or modify it under 
the terms of the Creative Commons' "by-attribution" license 
(http://creativecommons.org/licenses/by/2.5).

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1) Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2) Redistributions in binary form must reproduce the above copyright 
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
=============================================================================*/
//////////////////////////////////////////////////////////////////////////////////////////////
//
// Este fichero contiene la declaracion de tipos usados por vtkT2Mesh como son los objetos
// para manejar caminos de corte o grapas
//
//////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _J17042001TIPOSMALLAT2_
#define _J17042001TIPOSMALLAT2_

#include "vtkesquiT2MeshWin32Header.h"
#include "vtkAlgebra.h"
#include "vtkFace.h"
#include "vtkObject.h"


// Constantes para indicar el tipo de una interseccion en un camino de corte
//! Constants to indicate the type of an intersection in a way of cut
#define TIPOIN_INTERNO	0
#define TIPOIN_INICIAL	1
#define TIPOIN_FINAL	2
#define TIPOIN_ENARISTA	3

// Constantes de estado de los puntos de la malla
//! Constants of state in the points of the mesh

// Indica que el nodo actual se encuentra libre 
//! Indicates that the actual node is free
#define FREE_STATE				0 
// Indica que el nodo actual se encuentra atrapado por una grapa
//! Indicates that the actual node is grasped by a clip
#define CLIPPED_STATE				5 
// Indica que el nodo actual se encuentra unido a otro y ademas actua como primario
//! Indicates that the actual node is linked to other and acts as master node
#define LINKEDPRIMARY_STATE		6 
// Indica que el nodo actual se encuentra unido a otro y ademas actua como primario armonico debido a una colision proxima
//! Indicates that the actual node is linked to other and acts as harmonic master due to a close collision 
#define LINKEDPRIMARYARMONIC_STATE		7 
// Indica que el nodo actual se encuentra unido a otro y ademas actua como secundario
//! Indicates that the actual node es linked to other and acts as slave 
#define LINKEDSECUNDARY_STATE	8 
// Indica que el nodo actual se encuentra unido a otro y ademas actua como secundario armonico debido a una colision proxima
//! Indicate that the actual node is linked to other and acts as harmonic secundary 
#define LINKEDSECUNDARYARMONIC_STATE		9 

//Tipos de los puntos de la T2-mesh
//! Types of the points of the T2-Mesh
#define POINTTYPE_DEFORMABLE	0
#define POINTTYPE_FIXED		1

// Tipos de aristas de la cara
//! Types of the edges of the faces
#define UNREAL_EDGE		0
#define REAL_EDGE			1
#define HOLE_EDGE		2

// Para indicar direccion a la hora de establecer conexiones o continuar con el camino de corte
//! Indicate the direction to set connections or to continue the way of cut
#define DIR_INITIALPOINT	0
#define DIR_TOLEFT	1
#define DIR_TORIGHT	2



class vtkClip;
class vtkT2Mesh;

typedef int INT3[3];
typedef float FLOAT3[3];
typedef BOOL BOOL3[3];
typedef Point POINT3[3];
/////////////////////////////////////////////////////////////////////////////////
// Para almacenar el valor de los parametros que intervienen en la deformacion
//! Store the value of the parameters that act in the deformation
struct OpDeformation{
	double alpha;
	double gamma;
	// Este factor pondera la importancia del segundo bucle de calculo de fuerzas
	//! The "omega" factor set the importance of the second iteration in the force calculation
	double omega;  
	double inct;
	double cutlimit;
};

/////////////////////////////////////////////////////////////////////////////////
// Datos sobre los contactos
//! Data about the contacts
class VTK_ESQUI_T2MESH_EXPORT vtkDataContact: public vtkObject
{
public:
	int		m_nVtceContacto;
	int		m_nVtceContMultRes;
	int		m_nCaraContacto;
	Point	m_ptoPos, m_ptoPosXi;
	Point	m_ptoRestMov;
	bool	m_bTirar;
	bool    m_bShift;
	vtkDataContact *m_nNext;
	vtkDataContact *m_nPrev;

	vtkDataContact(){ m_nNext=m_nPrev=NULL; }
};

//////////////////////////////////////////////////////////////////////////////////
// Para realizar un corte primero hay que calcular el camino que seguira el mismo	
//! Calculate the way of a cut
class VTK_ESQUI_T2MESH_EXPORT vtkWay: public vtkObject
{
public:
	static vtkWay *New();
	const char *GetClassName() {return "vtkWay";}
	vtkTypeRevisionMacro(vtkWay,vtkObject);
	// Coordenadas de la interseccion
	//! Intersection coordenates
	Point m_ptoIntersec;   
	// Indice de la cara
	//! Index of the face
	int m_nFace;           
	// Identificador de la arista dentro del triangulo que no cara de la T2
	//! Identifiyng tag of the edge inside of the triangle that is not face of the T2
	int m_nEdge;         
	// 0 nodo interno, 1 nodo en vÃ©rtice inicial, 2 nodo en vÃ©rtice final,3 nodo en arista
	//! Node type
	/*!	
		0-> Internal node
		1-> Node in initial vertex
		2-> Node in final vertex
		3-> Node in edge
	*/
	int m_nType;	       
		
	vtkWay *m_nNext;
	vtkWay *m_nPrev;
};

///////////////////////////////////////////////////////////////////////////////////
// Informacion para los nodos
//! information for the nodes

class VTK_ESQUI_T2MESH_EXPORT vtkNode:public vtkObject 
{
public:
	// Coordenada del nodo
	//! Coordinate of the node
	Point m_PointT2;        
	// Indice de los nodos a los que esta conectado
	//! Index of the nodes to which is connected
	int m_anConect[3];      
	// Tipo de las conexiones anteriores
	//! Type of the previous connections
	int m_anTypeConect[3];  
	// Tipo de nodo ( Deformable, fijo ...)
	//! Node type
	int m_anTypePoint;       
	// Estado del punto (Grapado, Libre,...)
	//! State of the point
	int m_anStatePoint;     

	void FixPoint(Point& pto){ m_PointT2=pto; }
	void FixTypePoint(int nTipo){ m_anTypePoint=nTipo; }
	void FixStatePoint(int nEstado){ m_anStatePoint=nEstado;}
	void FixConnetion(int nInd,int nConex){ m_anConect[nInd]=nConex; }
	void FixTypeConnetion(int nInd,int nTipo){ m_anTypeConect[nInd]=nTipo; }
	
	Point ObtainPoint() const{ return m_PointT2; }
	int ObtainTypePoint() const{ return m_anTypePoint; }
	int ObtainStatePoint() const{ return m_anStatePoint; }
	int ObtainConnection(int nInd) const{ return m_anConect[nInd]; }
	int ObtainTypeConnection(int nInd) const {return m_anTypeConect[nInd]; }
};

///////////////////////////////////////////////////////////////////////////////////
// Datos sobre un Nodo de la malla T2 que es limite
//! Data about a node of the T2-Mesh that is limit
class VTK_ESQUI_T2MESH_EXPORT vtkNodeLimT2:public vtkNode 
{
public:
	 int m_nFace;
	 int m_nEdge; 
	 Point	m_ptoTexture;
	 vtkNodeLimT2 *m_nNext;

	 void FixFace(int nFace){ m_nFace=nFace; }
	 void FixEdge(int nEdge){ m_nEdge=nEdge; }
	 void FixNext(vtkNodeLimT2* pSig){ m_nNext=pSig; }

	 int ObtainFace() const { return m_nFace;}
	 int ObtainEdge() const{ return m_nEdge;}
	 vtkNodeLimT2* ObtainNext() const{return m_nNext; }
};

///////////////////////////////////////////////////////////////////////////////////
// Datos de los nodos de la malla T2
//! Data about the nodes of the T2-Mesh
class VTK_ESQUI_T2MESH_EXPORT vtkNodeT2:public vtkNode 
{
public:
	// Coordenadas anteriores del nodo
	//! Previous coordinates of the node
	Point  m_PointT2Prev;	
	// Array con los vectores diferencias entre posiciones de los nodos conectados	                    
	//! Array that contains the vector with the differences between the positions of the connected nodes

	POINT3 m_aSpins;	

	void FixPrevPoint(Point& pto){ m_PointT2Prev=pto; }
	void FixSpin(int nInd,Point& ptoValor){ m_aSpins[nInd]=ptoValor;}

	Point ObtainPreviousPoint() const { return m_PointT2Prev; }
	Point ObtainSpin(int nInd) const { return m_aSpins[nInd]; }

	void operator= (vtkNodeT2& node);
};

///////////////////////////////////////////////////////////////////////////////////

// Para almacenar los datos basicos de una T2-Mesh
//! Store de basic data of an T2-Mesh
class vtkEsquiFaceCollection;
class VTK_ESQUI_T2MESH_EXPORT vtkDataT2Mesh: public vtkObject 
{
public:
	static vtkDataT2Mesh* New();
	vtkTypeRevisionMacro(vtkDataT2Mesh,vtkObject);
	const char* GetClassName() {return "vtkDataT2Mesh";}
	int		m_nCopyNumPointsT2;
	Point	*m_pCopyPointsT2;
	Point	*m_pCopyTextureT2;
	Point	*m_pCopyPreviousPointT2;
	INT3	*m_panCopyConect;
	INT3	*m_panCopyTypeConect;
	int		*m_pnCopyPointType;
	int		*m_pnCopyStatePoint;
	POINT3	*m_pCopySpins;
	Point	*m_pCopyNormals;
	INT3	*m_panCopyAdjacents;
	vtkEsquiFaceCollection	*m_pCopyFaces;
	bool	*m_pbCopyInestable;
	int		m_nCopyNumFaces;
	bool    m_bLiberateMemory;
	bool	m_bValidMemory;

	vtkDataT2Mesh();
	~vtkDataT2Mesh();
	void LiberateMemory();
	void MakeSegurityCopy(vtkT2Mesh* pFont);
	void Restore(vtkT2Mesh* pAssing);
};

#endif
