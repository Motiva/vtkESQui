/// vtkDeformableModel
/// --------------

#ifndef __vtkModeloDeformable_h
#define __vtkModeloDeformable_h

#include "vtkAABB.h"
#include "vtkObject.h"
//#include "vtkIdType.h"
#include "vtkSystemIncludes.h"
#include "vtkIdList.h"
#include "Macros.h"
#include "vtkesquiT2MeshWin32Header.h"
class vtkAABB;

//! Class which have the needed info of deformable model to collision detection
class VTK_ESQUI_T2MESH_EXPORT vtkDeformableModel: public vtkObject
{

public:

	vtkTypeRevisionMacro(vtkDeformableModel, vtkObject);
	static vtkDeformableModel *New();
	const char *GetClassName() {return "vtkDeformableModel";};

	//! Get the number of points
	vtkIdType GetNumberOfVertexes();
	//! Get the number of facets
	vtkIdType GetNumberOfFaces();
	//! Get the number of moved verts
	vtkIdType GetNumberOfMovedVertexes();
	
	float* GetVertex(vtkIdType Index);
	void PrintSelf(ostream& os, vtkIndent indent);
//BTX	
	//! Number Of Points
	unsigned VertexesNumber;
	//! Number of facets
	unsigned FacesNumber;
	//!Number of moved verts
	unsigned MovedVertexesNumber;
	float CenterOfVertexes[3];

	//! Index of moved verts on each cycle
	int* idVerticesMovidos;		// Indices de los vertices movidos en cada ciclo
	//! Model coords
	float* Vertexes;			// Coordenadas de los vertices del modelo (xyz xyz xyz)
	//! Index to verts which makes the facets of a model. (v1Cara1v2Cara1v3Cara1 v1Cara2v2Cara2v3Cara3 ...)
	int* Faces;					// Indices a vertices que forman las caras del modelo 
	//! Coords of verts on previous cycle
	float* PrevVertexes;   // Coordenadas de los verrtices en el paso anterior.
	//! Boundig box for deformable model
	vtkAABB  Box;				// Caja de inclusion del modelo deformable (para eliminar casos)
//ETX
private:
	vtkDeformableModel (const vtkDeformableModel &); //Not Implemented
	void operator =(const vtkDeformableModel &); //Not Implemented
protected:
	vtkDeformableModel() {};
	~vtkDeformableModel();

};
#endif
